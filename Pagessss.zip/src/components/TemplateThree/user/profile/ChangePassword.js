import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin } from "antd";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { config } from "../../../../config";
import { ProfileAPI } from "../../../../apis/ProfileAPI";

import useHttp from "../../../../hooks/useHttp";

const { TabPane } = Tabs;
const { Option } = Select;

export default function ChangePassword(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  // console.log(AuthReducer);
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState("STEP1");
  const [isICICI, setIsICICI] = useState(true);
  let navigate = useNavigate();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,
      spin: false,
    }
  );

  const hookChangePassword = useHttp(ProfileAPI.changePassword);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const onFinish = (value) => {
    let changePasswordPayload = {
      requestType: "CHANGEPASSWORD",
      userId: AuthReducer.userID,
      oldPassword: value.oldPassword,
      newPassword: value.newPassword,
      twofa: "N",
    };
    setState({ spin: true });
    hookChangePassword.sendRequest(changePasswordPayload, function (data) {
      setState({ spin: false });
      if (data.status == "S") {
        console.log(data.responseData);
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            // navigate('/signin');
            window.location.href = "/signin";
          }
        });
        // setBankListData(decodeData.responseData);
        // setState({ transactionLists: decodeData.responseData });
      } else {
        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        } else {
          notification.error({ message: data.errorMessage });
        }
      }
    });
  };

  return (
    <div className="ChangePassword bg_gradient container mt-md-5 mt-sm-5">
      <div className="ChangePassword-Inside-Container T3_container">
        <Spin spinning={state.spin}>
          {!state.showConfirmBankAccountDetails && (
            <Row>
              <Col lg={8} md={10}>
                <div>
                  <h4 className="title mb-md-4 mb-sm-4">Change Password</h4>
                  <Form form={form} onFinish={onFinish}>
                    <Row className="justify-content-center">
                      <Col md={12}>
                        <div className="">
                          <label className="form-label">Current Password</label>
                          <Form.Item
                            className="form-item"
                            name="oldPassword"
                            rules={[
                              {
                                required: true,
                                message: "Enter Current Password.",
                              },
                            ]}
                          >
                            <Input.Password
                              size="large"
                              placeholder="Current Password"
                            />
                          </Form.Item>
                        </div>
                      </Col>

                      <Col md={12}>
                        <div className="">
                          <label className="form-label">New Password</label>
                          <Form.Item
                            className="form-item"
                            name="newPassword"
                            rules={[
                              {
                                required: true,
                                message: "Please enter your New Password.",
                              },
                              {
                                min: 10,
                                message:
                                  "Password must be 10 or more characters with a mix of both uppercase and lowercase letter, number & symbol.",
                              },
                            ]}
                          >
                            <Input.Password
                              size="large"
                              placeholder="Enter your New Password"
                            />
                          </Form.Item>
                        </div>
                      </Col>
                      <Col md={12}>
                        <div className="">
                          <label className="form-label">
                            Confirm New Password
                          </label>
                          <Form.Item
                            className="form-item"
                            name="ConfirmNewPassword"
                            rules={[
                              {
                                required: true,
                                message: "Please enter Confirm New Password.",
                              },
                              ({ getFieldValue }) => ({
                                validator(rule, value) {
                                  if (
                                    !value ||
                                    getFieldValue("newPassword") === value
                                  ) {
                                    return Promise.resolve();
                                  }
                                  return Promise.reject(
                                    "Confirm password does not match with set password. Please enter correct values in the fields."
                                  );
                                },
                              }),
                            ]}
                          >
                            <Input.Password
                              size="large"
                              placeholder="Confirm New Password"
                            />
                          </Form.Item>
                        </div>
                      </Col>

                      <Col md={12}>
                        <div className="d-flex justify-content-end">
                          <Link
                            to={"/"}
                            className="btn btn-secondary btn-sm me-3 my-3"
                          >
                            Back
                          </Link>
                          <button
                            className="btn btn-primary text-white btn-sm my-3"
                            type="submit"
                            // onClick={() => setIsICICI(true)}
                          >
                            Submit
                          </button>
                        </div>
                      </Col>
                    </Row>
                  </Form>
                </div>
              </Col>
            </Row>
          )}
        </Spin>
      </div>
    </div>
  );
}
