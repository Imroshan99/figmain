import { Form, Input, Button, Select, notification } from "antd";
import { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import useHttp from "../../../../hooks/useHttp";

export default function RecipientRequestNickNameForm({
  record,
  nickNameHandler,
}) {
  const [form] = Form.useForm();
  const [nickName, setNickName] = useState("");
  const [validateStatus, setValidateStatus] = useState("");
  const AuthReducer = useSelector((state) => state);

  const hookCheckRecvNickName = useHttp(ReceiverAPI.checkRecvNickName);
  // console.log('nick', record.nickName)
  useEffect(() => {
    form.setFieldsValue({
      nickName : record.nickName
    })
    if(nickName != record.nickName){
      setValidateStatus('')
    }
  }, [record.nickName]);

  useEffect(() => {
    const timeOutId = setTimeout(() => {
      if (nickName) {
        checkRecvNickNameHandler();
      }
    }, 500);
    return () => clearTimeout(timeOutId);
  }, [nickName]);

  const checkRecvNickNameHandler = () => {
    const payload = {
      requestType: "RECVNICKNAME",
      userId: AuthReducer.userID,
      nickName: nickName,
    };
    hookCheckRecvNickName.sendRequest(payload, (res) => {
      if (res.status === "S") {
        setValidateStatus("success");
        nickNameHandler(nickName, record.recordToken);
      } else {
        setValidateStatus("error");
        notification.error({ message: res.errorMessage });
        form.setFields([
          {
            name: "nickName",
            errors: [res.errorMessage],
          },
        ]);
      }
    });
  };

  return (
    <Form
      form={form}
      initialValues={{
        nickName: record.nickName,
      }}
    >
      {/* {record.nickName} */}
      <Form.Item
        name="nickName"
        validateStatus={validateStatus}
        hasFeedback
        rules={[
          {
            required: true,
          },
          {
            min: 3,
            message: "Nick Name should be between 3 and 40 characters",
          },
          {
            max: 40,
            message: "Nick Name should be between 3 and 40 characters",
          },
          {
            pattern: /^[a-zA-Z0-9]+$/,
            message: "No Special Chars",
          },
        ]}
      >
        <Input
          onChange={(e) => {
            setNickName(e.target.value);
          }}
        />
      </Form.Item>
    </Form>
  );
}
