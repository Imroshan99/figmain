import React, { useEffect, useReducer, useState } from "react";
import Swal from "sweetalert2";
import { Form, Checkbox, Row, Col, Spin } from "antd";
import { Link } from "@mui/material";
import { useSelector } from "react-redux";
import TCModal from "../../../../containers/ModalBox/TCModal";
import { EditOutlined } from "@ant-design/icons";
import bulb from "../../../../assets/images/svg/bulb.svg";
import arrow from "../../../../assets/images/svg/arrow.svg";

export default function TransactionConfirm(props) {
  const AuthReducer = useSelector((state) => state);
  const [form] = Form.useForm();
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      tcModalVisible: false,
    }
  );
  // console.log(props)
  const onClickSendMoney = () => {
    if (props.state.isSelectedBankTransfer) {
      if (props.state._isScheduleTransaction == true) {
        props.bookScheduleTransaction();
      } else {
        props.bookTransaction();
      }
    } else {
      Swal.fire({
        text: "You will now be redirected to a third party payment gateway using PGP encryption to protect the privacy of your details. Once you have successfully completed the transfer of funds you will receive a transaction notice indicating the status of the debit from your account and a reference number will be generated and displayed to you.",
        // showDenyButton: true,
        showCancelButton: true,
        denyButtonText: `Cancel`,
        confirmButtonText: "Confirm",
        confirmButtonColor: "#2dbe60",
      }).then((result) => {
        /* Read more about isConfirmed, isDenied below */
        if (result.isConfirmed) {
          if (props.state._isScheduleTransaction == true) {
            props.bookScheduleTransaction();
          } else {
            props.bookTransaction();
          }
        } else if (result.isDenied) {
          Swal.fire("Changes are not saved", "", "info");
        }
      });
    }
  };

  const handleTcModal = () => {
    setState({ tcModalVisible: true });
  };

  return (
    <div className="Transaction-Confirm mt-md-5 mt-sm-5">
      <Spin spinning={props.state.spin3}>
        <h4 className="title">Confirm Transaction Details</h4>
        <Row className="d-flex gap-1">
          <Col className="d-flex align-items-center">
            <img src={bulb}></img>
          </Col>
          <Col>
            <p className="m-0">Exchange Rate for 24 hours:</p>
          </Col>
        </Row>
        <Row style={{ marginTop: "-0.5rem" }} className="d-flex gap-1">
          <Col>
            <img style={{ visibility: "hidden" }} src={bulb}></img>
          </Col>
          <Col>
            <p style={{ fontWeight: "600" }}>
              1 {AuthReducer.sendCurrencyCode} = {props.state.displayExRate}
              {AuthReducer.recvCurrencyCode}
            </p>
          </Col>
        </Row>
        <div className="details-container">
          <div className="d-flex justify-content-between">
            <p>Recipient</p>
            <p className="right-title">{props.state.receiverName}</p>
          </div>
          <div
            style={{ marginBottom: "20px" }}
            className="d-flex justify-content-between"
          >
            <p>Source Account</p>
            <p className="right-title">{props.state.accountNo}</p>
          </div>
          <div className="d-flex justify-content-between">
            <p>Amount Sent</p>
            <div className="d-flex gap-1">
              <p style={{ fontSize: "10px" }} className="right-title">
                {AuthReducer.sendCurrencyCode}
              </p>
              <p className="right-title">{props.state.sendAmount}</p>
            </div>
          </div>
          <div className="d-flex justify-content-between">
            <p>Amount Received</p>
            <div className="d-flex gap-1">
              <p style={{ fontSize: "10px" }} className="right-title">
                {AuthReducer.recvCurrencyCode}
              </p>
              <p className="right-title"> {props.state.recvAmount}</p>
            </div>
          </div>
          <div
            style={{ marginBottom: "20px" }}
            className="d-flex justify-content-between"
          >
            <p>Transfer Fees</p>
            <div className="d-flex gap-1">
              <p style={{ fontSize: "10px" }} className="right-title">
                {AuthReducer.sendCurrencyCode}
              </p>
              <p className="right-title">{props.state.totalFee}</p>
            </div>
          </div>
          <div
            style={{ marginBottom: "20px" }}
            className="d-flex justify-content-between"
          >
            <p>Total</p>
            <div className="d-flex gap-1">
              <p
                style={{ fontWeight: "700", fontSize: "10px" }}
                className="right-title"
              >
                {AuthReducer.sendCurrencyCode}
              </p>
              <p style={{ fontWeight: "700" }} className="right-title">
                {props.state.amountPayable}
              </p>
            </div>
          </div>
          <div className="d-flex gap-1">
            <p>Transaction Note: </p>
            <p style={{ fontWeight: "600" }}> {props.state.purposeName}</p>
          </div>
        </div>
        <Form onFinish={onClickSendMoney}>
          <div>
            <Form.Item
              className="form-item"
              name="readTermsConditions"
              valuePropName="checked"
              rules={[
                {
                  validator: (_, value) =>
                    value
                      ? Promise.resolve()
                      : Promise.reject(
                          new Error("Please confirm terms and conditions.")
                        ),
                },
              ]}
            >
              <Checkbox>
                I acknowledge that I have read, understood and I agree to the{" "}
                <a href="/terms-and-conditions" target="_blank">
                  Terms &amp; Conditions
                </a>
                .
              </Checkbox>
            </Form.Item>
          </div>
          <div className="cont-button-container" style={{ marginTop: "20px" }}>
            {/* <button
              className="btn btn-primary text-white btn-sm px-5"
              onClick={() => props.setState({ isStep: 1 })}
            >
              Cancel
            </button> */}
            <Spin spinning={props.state.exRateToken === "" ? true : false} style={{ width: "297px" }}>
              <button
                className="cont-button my-2"
                style={{ padding: 0, border: 0 }}
                htmlType="submit"
              >
                <div
                  style={{ padding: "1rem", width: "100%" }}
                  className="d-flex justify-content-between"
                >
                  <img style={{ visibility: "hidden" }} src={arrow}></img>
                  Confirm
                  <img src={arrow}></img>
                </div>
              </button>
            </Spin>
          </div>
        </Form>
      </Spin>
    </div>
  );
}
