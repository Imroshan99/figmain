import { Link, useLocation } from "react-router-dom";
import React, { useState, Fragment, useEffect, useReducer } from "react";
import {
  Collapse,
  Row,
  Col,
  Input,
  Space,
  Modal,
  Radio,
  Button,
  Divider,
  notification,
  Select,
  Spin,
} from "antd";
// import GBp from "../../../../assets/images/Gbp.png";
// import inr from "../../../../assets/images/inr.png";
import moment from "moment";
import { useSelector } from "react-redux";
import { flags } from "../../../../services/utility/flags";
import useHttp from "../../../../hooks/useHttp";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { Alert } from "@mui/material";
import bulb from "../../../../assets/images/svg/bulb.svg";
import exchange from "../../../../assets/images/svg/exchange.svg";
import arrow from "../../../../assets/images/svg/arrow.svg";

export default function NewTransaction(props) {
  const { Panel } = Collapse;
  const { Option } = Select;
  const location=useLocation();
  const AuthReducer = useSelector((state) => state);

  const hookRecipientRequestLists = useHttp(ReceiverAPI.recipientRequestLists);
  const hookRecipientRequestApprove = useHttp(
    ReceiverAPI.recipientRequestApprove
  );

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      recipientRequestLists: [],
      amountError: false,
    }
  );
  useEffect(()=>{
    if(location?.state?.fromPage==="RECIPIENT_REQUEST_LIST"){
      props.setState({sendAmount:location.state.sendAmount});
      if(props.state.sendAmount){
        continueClickHandler();
      }
    }
  },[props.state.sendAmount])
  useEffect(() => {
    if (props.state.approveRequest) {
      props.setState({ approveRequest: false });
      if (props.state.sendAmount >= 1) {
        if (props.state.groupId == "KCB") {
          props.userRiskProfile();
          // alert(props.state.groupId)
          props.getAchAccountLists();
        } else {
          // props.setState({ isStep: 2 });
          props.userRiskProfile();
          props.getBankAccountLists();
        }

        props.getReceiverLists();
        props.getPaymentOption();

        props.getSourceOFFundLists();
      } else {
        notification.error({
          message: "Please enter valid amount",
        });
      }
    }
  }, [props.state.approveRequest]);

  useEffect(() => {
    const timeOutId = setTimeout(() => {
      if (props.state.sendAmount >= 1) {
        props.onCallComputeExchangeRates(
          "SENDMONEY",
          props.state.isDenefit,
          props.state.promoCode,
          props.state.sendAmount
        );
      } else {
        //  alert('Please enter valid amount')
        // setState({
        //   amountError : true
        // })
      }
    }, 500);
    return () => clearTimeout(timeOutId);
  }, [props.state.sendAmount]);

  useEffect(() => {
    recipientRequestListsHandler();
  }, []);

  const recipientRequestApproveHandler = (record, flag) => {
    // console.log("table record : ", record.nickName);
    props.setState({ spin: true });
    const newNickName = record.nickName;
    const payload = {
      requestType: "RECREQAPPROVE",
      userId: AuthReducer.userID,
      rmId: record.rmId,
      aprroveFlag: flag,
      recordToken: record.recordToken,
      nickName: newNickName,
    };
    hookRecipientRequestApprove.sendRequest(payload, (res) => {
      props.setState({ spin: false });
      if (res.status === "S") {
        notification.success({ message: res.message });
        recipientRequestListsHandler();
        props.setState({ sendAmount: record.sendAmount });
        props.setState({ approveRequest: true });
        props.setState({ approveRequestNickname: record.nickName });
        // if (flag === "Y") {
        //   navigate("/new-transaction", {
        //     state: {
        //       fromPage: "RECIPIENT_REQUEST_LIST",
        //       sendAmount: record.sendAmount,
        //     },
        //   });
        // } else {
        //   recipientRequestListsHandler();
        // }
      }
    });
    // console.log('record state : ', state.recipientRequestLists);
  };

  const recipientRequestListsHandler = () => {
    const payload = {
      requestType: "RECREQLIST",
      userId: AuthReducer.userID,
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
      favouriteFlag: "",
    };
    hookRecipientRequestLists.sendRequest(payload, (res) => {
      if (res.status === "S") {
        setState({
          recipientRequestLists: res.responseData,
        });
      } else {
        if (!res.responseData) {
          setState({
            recipientRequestLists: [],
          });
        }
      }
    });
  };

  //  console.log(AuthReducer)
  const continueClickHandler=()=>{
    if (props.state.sendAmount >= 1) {
      if (props.state.groupId == "KCB") {
        props.userRiskProfile();
        // alert(props.state.groupId)
        props.getAchAccountLists();
      } else {
        // props.setState({ isStep: 2 });
        props.userRiskProfile();
        props.getBankAccountLists();
      }

      props.getReceiverLists();
      props.getPaymentOption();

      props.getSourceOFFundLists();
    } else {
      notification.error({
        message: "Please enter valid amount",
      });
    }
  }

  return (
    <Fragment>
      <div className="newTransaction mt-md-5 mt-sm-5">
        <div className="T3_container">
          <Spin spinning={props.state.spin}>
            <Row className="align-items-center">
              <Col>
                {state.recipientRequestLists.length !== 0 && (
                  <>
                    {state.recipientRequestLists.length === 1 ? (
                      state.recipientRequestLists.map((v, i) => {
                        return (
                          <Alert
                            severity="info"
                            className="mb-2"
                            key={`request__list__${i}`}
                          >
                            You have new request from {v.recvFirstName}{" "}
                            {v.recvLastName} -{" "}
                            <Link to="/recipient-request-list">Click here</Link>
                            {/* <button
                              className="btn btn-sm btn-primary text-white"
                              onClick={() => {
                                recipientRequestApproveHandler(v, "Y");
                              }}
                            >
                              Approve
                            </button>
                            <button
                              onClick={() => {
                                recipientRequestApproveHandler(v, "N");
                              }}
                              className="btn btn-sm btn-danger text-white"
                            >
                              Deny
                            </button> */}
                          </Alert>
                        );
                      })
                    ) : (
                      <Alert severity="info" className="mb-2">
                        You have multiple new request for money{" "}
                        <Link to="/recipient-request-list">Click here</Link>
                      </Alert>
                    )}
                  </>
                )}
              </Col>
            </Row>
            {/* <Collapse accordion>
          <Panel header="Recent Transactions" key="1">
            {props.state.transactionLists.map((list, i) => {
              return (
                <div className="row mb-3" key={i}>
                  <div className="col-12 col-md-6">
                    <h6 className="text-uppercase">{list.receiverName}</h6>
                    <small>
                      <span>{`${list.amount}`} on </span>
                      <span>
                        {moment(list.bookingDate).format("DD/MM/YYYY")}
                      </span>
                    </small>
                  </div>
                  <div className="col-12 col-md-6 text-end ">
                    <Link
                      className="btn btn-primary text-white btn-sm me-2"
                      to={{
                        pathname: "/repeat-transaction",
                      }}
                      state={{ rgtn: list.rgtn, txnRefNo: list.txnRefNo }}
                    >
                      Repeat
                    </Link>

                    <Link
                      className="btn btn-primary text-white btn-sm"
                      to={{
                        pathname: "/track-money-transfer",
                      }}
                      state={{ rgtn: list.rgtn }}
                    >
                      Track
                    </Link>
                  </div>
                </div>
              );
            })}
          </Panel>
          <Panel header="Recent Favourite" key="2">
            {props.state.favouriteTransactionLists.map((list, i) => {
              return (
                <Row justify="space-between" key={i}>
                  <Col span={12} className="d-block">
                    <h6 className="text-uppercase">{list.receiverName}</h6>
                    <small>
                      <span>{`${list.amount}`} on </span>
                      <span>
                        {moment(list.bookingDate).format("DD/MM/YYYY")}
                      </span>
                    </small>
                  </Col>
                  <Col span={12} className="text-end ">
                    <Link
                      className="btn btn-primary text-white btn-sm m-2"
                      to={{
                        pathname: "/repeat-transaction",
                      }}
                      state={{ rgtn: list.rgtn, txnRefNo: list.txnRefNo }}
                    >
                      Repeat
                    </Link>

                    <Link
                      className="btn btn-primary text-white btn-sm"
                      to={{
                        pathname: "/track-money-transfer",
                      }}
                      state={{ rgtn: list.rgtn }}
                    >
                      Track
                    </Link>
                  </Col>
                </Row>
              );
            })}
          </Panel>
        </Collapse> */}
            <h4 className="title">Send Money</h4>
            <h5 className="sub-title mb-4">
              Confirm amount and rates below and continue
            </h5>
            <div>
              <Row className="d-flex gap-1">
                <Col className="d-flex align-items-center">
                  <img src={bulb}></img>
                </Col>
                <Col>
                  <p className="m-0">Exchange Rate for 24 hours:</p>
                </Col>
              </Row>
              <Row style={{ marginTop: "-0.5rem" }} className="d-flex gap-1">
                <Col>
                  <img style={{ visibility: "hidden" }} src={bulb}></img>
                </Col>
                <Col>
                  <p style={{ fontWeight: "600" }}>
                    {AuthReducer.sendCurrencyCode} 1 ={" "}
                    {AuthReducer.recvCurrencyCode} {props.state.displayExRate}
                  </p>
                </Col>
              </Row>
            </div>
            <div className="input-container d-flex gap-3">
              <div className="d-flex flex-column">
                <label className="form-label">Send Amount</label>
                <div className="input">
                  <Input
                    type="number"
                    step="0.01"
                    min={0}
                    value={props.state.sendAmount}
                    onChange={(e) => {
                      props.setState({ sendAmount: e.target.value });
                      if (e.target.value === "0" || e.target.value === "") {
                        setState({
                          amountError: true,
                        });
                      } else {
                        setState({
                          amountError: false,
                        });
                      }
                    }}
                    onBlur={() =>
                      props.onCallComputeExchangeRates(
                        "SENDMONEY",
                        props.state.isDenefit,
                        props.state.promoCode,
                        props.state.sendAmount
                      )
                    }
                  />
                  <Select
                    className="select"
                    defaultValue={"usd"}
                    style={{ display: "flex", alignItems: "center" }}
                  >
                    <Option value="usd">USD</Option>
                  </Select>
                </div>
                {state.amountError && (
                  <span role="alert" className="ant-form-item-explain-error">
                    Please enter valid amount
                  </span>
                )}
              </div>
              <img
                onClick={() => {
                  props.setIsModalVisible(true);
                }}
                style={{ marginTop: "30px", cursor: "pointer" }}
                src={exchange}
              ></img>
              <div className="d-flex flex-column">
                <label className="form-label">Receive Amount</label>
                <div className="input">
                  <Input
                    type="number"
                    step="0.01"
                    min={0}
                    readOnly
                    value={props.state.recvAmount}
                    // onChange={(e) => props.setState({ recvAmount: e.target.value })}
                    onChange={(e) => {
                      props.setState({ recvAmount: e.target.value });
                      if (e.target.value === "0" || e.target.value === "") {
                        setState({
                          amountError: true,
                        });
                      } else {
                        setState({
                          amountError: false,
                        });
                      }
                    }}
                    onBlur={() =>
                      props.onCallComputeExchangeRates(
                        "SENDMONEY",
                        props.state.isDenefit,
                        props.state.promoCode,
                        props.state.recvAmount,
                        "REVERSE"
                      )
                    }
                  />
                  <Select
                    className="select"
                    defaultValue={"kes"}
                    style={{ display: "flex", alignItems: "center" }}
                  >
                    <Option value="kes">KES</Option>
                  </Select>
                </div>
              </div>
            </div>
            <div
              className="cont-button"
              disabled={props.state.recvAmount == 0}
              onClick={continueClickHandler}
            >
              <img style={{ visibility: "hidden" }} src={arrow}></img>
              Continue
              <img src={arrow}></img>
            </div>
            <div className="underline-p-container">
              <p className="underline-p">Legal Disclaimer</p>
            </div>
          </Spin>
        </div>
      </div>
    </Fragment>
  );
}