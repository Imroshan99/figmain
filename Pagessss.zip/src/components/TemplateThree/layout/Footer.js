import { Link } from "react-router-dom";
import FB from "../../../assets/images/svg/fb.svg";
import YT from "../../../assets/images/svg/yt.svg";
import Twitter from "../../../assets/images/svg/twitter.svg";
import Insta from "../../../assets/images/svg/insta.svg";
import LinkedIn from "../../../assets/images/svg/linkedin.svg";
import WA from "../../../assets/images/svg/wa.svg";

const Footer = (props) => {
  return (
    <footer>
      <div className="footer container">
        <div className="row">
          <div className="col">
            <p className="para2">
              We value your privacy. While using this website we would like to
              use cookies and similar technologies to collect data. Collecting
              this data helps us improve your experience on this site, analyze
              site usage and personalize message content
            </p>
            <p className="footer-sub-title">Process by Golden Money Transfer</p>
          </div>
          <div className="col d-flex flex-row-reverse d-none d-sm-block">
            {/* <p className="m-0 text-end">
              Processed by Golden Money Transfer, Inc.
            </p> */}
          </div>
        </div>
        <div className="row">
          <div
            style={{ height: "1.3rem" }}
            className="col-md-5 order-last order-md-first my-4 my-md-0 d-flex gap-3 align-items-center"
          >
            <a
              rel="noreferrer"
              target="_blank"
              href="https://www.facebook.com/kcbgroup/"
            >
              <img alt="Facebook" src={FB}></img>
            </a>
            <a
              rel="noreferrer"
              target="_blank"
              href="https://www.instagram.com/accounts/login/?next=/kcbgroup/"
            >
              <img alt="Instagram" src={Insta}></img>
            </a>
            <a
              rel="noreferrer"
              target="_blank"
              href="https://twitter.com/KCBGroup"
            >
              <img alt="Twitter" src={Twitter}></img>
            </a>
            <a
              rel="noreferrer"
              target="_blank"
              href="https://www.youtube.com/channel/UC3REin1loCe8bxtZJClwZ2A"
            >
              <img alt="Youtube" src={YT}></img>
            </a>
            <a
              rel="noreferrer"
              target="_blank"
              href="https://ke.linkedin.com/company/kcb-group-plc"
            >
              <img alt="LinkedIn" src={LinkedIn}></img>
            </a>
            <a
              rel="noreferrer"
              target="_blank"
              href="https://api.whatsapp.com/send/?phone=254711087087&text&type=phone number&app absent=0"
            >
              <img alt="WhatsApp" src={WA}></img>
            </a>
          </div>
          <div className="col md-5 mt-4 mt-md-0">
            <ul>
              <li className="footer-sub-title">Customer Service</li>
              <li className="para1 mt-4">
                <Link
                  className="para1"
                  target="_blank"
                  rel="noopener noreferrer"
                  to="/faq"
                >
                  FAQs
                </Link>
              </li>
              <li className="para1">
                <a className="para1" href="mailto:info@ke.kcbgroup.com">
                  info@ke.kcbgroup.com
                </a>
              </li>
              <a
                rel="noreferrer"
                target="_blank"
                href="https://ke.kcbgroup.com/terms-condition"
              >
                <li className="para1 mt-4">Terms &amp; Conditions</li>
              </a>
              <a
                rel="noreferrer"
                target="_blank"
                href="https://ke.kcbgroup.com/terms-condition"
              >
                <li className="para1">Privacy Policy</li>
              </a>
              <a
                rel="noreferrer"
                target="_blank"
                href="https://ke.kcbgroup.com/images/Final_KCB_Customer_Promise_A1Poster_compressed.pdf"
              >
                <li className="para1">Customer Promise</li>
              </a>
            </ul>
          </div>
          <div className="col-md-2 mt-4 mt-md-0">
            <ul>
              <li className="footer-sub-title">Services</li>
              <li className="para1 mt-4">
                <Link
                  className="para1"
                  to={
                    props.appState.isLoggedIn ? "/new-transaction" : "/signin"
                  }
                >
                  Send Money
                </Link>
              </li>
              <li className="para1">
                <Link className="para1" to={"/request-money"}>
                  Request Money
                </Link>
              </li>
              <li className="para1">
                <Link
                  className="para1"
                  to={
                    props.appState.isLoggedIn ? "/transaction-list" : "/track-transfer"
                  }
                >
                  Track Transfer
                </Link>
              </li>
            </ul>
          </div>
        </div>
        <div className="row">
          <div
            style={{ height: "1.3rem" }}
            className="col-md-5 order-last order-md-first my-4 my-md-0 d-flex gap-3 align-items-center"
          >           
          </div>
          <div className="col md-5 mt-4 mt-md-0">
            <ul>
              <li className="para1 mt-0">
                <a
                  className="para1"
                  target="_blank"
                  rel="noopener noreferrer"
                  href="https://gmtsend.com/state-license-list"
                >
                  GMT License List
                </a>
              </li>
              <li className="para1 mt-0">
                <a
                  className="para1"
                  target="_blank"
                  rel="noopener noreferrer"
                  href="https://gmtsend.com/compliance-statement"
                >
                  GMT Compliance Statement
                </a>
              </li>
              <li className="para1 mt-0">
                <a
                  className="para1"
                  target="_blank"
                  rel="noopener noreferrer"
                  href="https://gmtsend.com/privacy-policy"
                >
                  GMT Privacy Policy
                </a>
              </li>
              <li className="para1 mt-0">
                <a
                  className="para1"
                  target="_blank"
                  rel="noopener noreferrer"
                  href="https://gmtsend.com/terms-of-use"
                >
                  GMT Terms of Use
                </a>
              </li>
            </ul>
          </div>
          <div className="col-md-2 mt-4 mt-md-0">
          </div>
        </div>
        <div className="row">
          <div className="fw-300 copyright">
            Copyright KCB Group 2022. All rights reserved
          </div>
        </div>
      </div>
    </footer>
  );
};

export default Footer;
