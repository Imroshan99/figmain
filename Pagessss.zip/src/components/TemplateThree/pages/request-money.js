import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin } from "antd";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";

import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";

import { ProfileAPI } from "../../../apis/ProfileAPI";
import { config } from "../../../config";

import { GuestAPI } from "../../../apis/GuestAPI";
import { ReceiverAPI } from "../../../apis/ReceiverAPI";
import useHttp from "../../../hooks/useHttp";
// import TestDemo from "./TestDemo";
// const TestDemo = React.lazy(() => import('./TestDemo'))

const { TabPane } = Tabs;
const { Option } = Select;

export default function RequestMoney(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  // console.log(AuthReducer);
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState("STEP1");
  const [isICICI, setIsICICI] = useState(true);
  let navigate = useNavigate();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      userFullName: AuthReducer.userFullName,

      phoneCodes: [],
      deliveryOptionsList: [],
      deliveryOption: "",

      bankNames: [],
      isSameBank: "N",
      bankBranchStates: [],
      bankBranchCities: [],
      bankBranchNames: [],
      accountTypes: [],
      recvCountryList: [],
      bankBranchCode: "",

      updateBankBranch: "",
      updateBankCity: "",
      updateBankState: "",
      updateBankCode: "",
      bankName: "",
    }
  );

  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetDeliveryOptions = useHttp(GuestAPI.getDeliveryOptions);
  const hookGetBankList = useHttp(GuestAPI.getBankListData);
  const hookGetBankBranchState = useHttp(GuestAPI.getBankBranchState);
  const hookGetBankBranchCity = useHttp(GuestAPI.getBankBranchCity);
  const hookGetBankBranchNames = useHttp(GuestAPI.getBankBranchNames);
  const hookRequestMoney = useHttp(ReceiverAPI.requestMoney);
  const hookRecvCountryList = useHttp(GuestAPI.receiverCountryList);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCoutryCodes();
    getDeliveryOptions();
    getBankList();
    recvCountryList();
    onChangeBankBranchState("");
    onChangeBankBranchCity("");
  }, []);

  const recvCountryList = async () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: AuthReducer.sendCountryCode,
      sendCurrency: AuthReducer.sendCurrencyCode,
    };

    hookRecvCountryList.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ recvCountryList: data.responseData });
      }
    });
  };

  const getCoutryCodes = async () => {
    const payloadGetCoutryCodes = {
      requestType: "COUNTRYPHONECODE",
    };

    hookGetCountryPhoenCodes.sendRequest(
      payloadGetCoutryCodes,
      function (data) {
        if (data.status === "S") {
          setState({ phoneCodes: data.responseData });
        }
      }
    );
  };

  const getDeliveryOptions = async () => {
    const payload = {
      requestType: "RECVMODE",
      countryCode: AuthReducer.recvCountryCode,
    };
    hookGetDeliveryOptions.sendRequest(payload, function (res) {
      if (res.status === "S") {
        setState({ deliveryOptionsList: res.responseData });
      }
    });
  };

  const getBankList = async () => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.recvCountryCode,
    };
    setLoader(true);
    hookGetBankList.sendRequest(payload, function (res) {
      if (res.status === "S") {
        setState({ bankNames: res.responseData });
      }
      setLoader(false);
    });
  };

  const onChangeBankBranchState = async (branhcCode) => {
    if (branhcCode !== "") {
      let bankDetails = state.bankNames.filter(
        (item) => item.bankCode === branhcCode
      );
      setState({
        bankBranchCode: branhcCode,
        isSameBank: bankDetails[0]?.isSameBank,
      });
    }

    const payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.recvCountryCode,
    };
    setLoader(true);
    hookGetBankBranchState.sendRequest(payload, function (res) {
      if (res.status === "S") {
        setState({ bankBranchStates: res.responseData });
      }
      setLoader(false);
    });
  };

  const onChangeBankBranchCity = async (stateCode) => {
    const payload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.recvCountryCode,
      stateCode: stateCode,
    };
    setLoader(true);
    hookGetBankBranchCity.sendRequest(payload, (res) => {
      setLoader(false);
      if (res.status === "S") {
        setState({ bankBranchCities: res.responseData });
      }
    });
  };

  const onChangeBankBranchName = async (cityCode) => {
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: AuthReducer.recvCountryCode,
      bankCode: state.bankBranchCode,
      bankName: "",
      stateCode: "",
      cityCode: cityCode,
      keyword: "",
    };

    setLoader(true);
    hookGetBankBranchNames.sendRequest(payload, (res) => {
      setLoader(false);
      if (res.status === "S") {
        setState({
          bankBranchNames: res.responseData,
          updateBankBranch: res.responseData[0].branchName,
          updateBankCity: res.responseData[0].bankCity,
          updateBankState: res.responseData[0].bankState,
          updateBankCode: res.responseData[0].branchCode,
        });
      }
    });
  };

  const onChangeBankBranchNameSelect = (value) => {
    form.setFieldsValue({
      branchCode: value,
    });
  };

  const onChangeDeliveryOptionHandler = (value) => {
    let bankName = "";
    if (value === "VOOMA") {
      bankName = "Vooma Wallet";
    }
    if (value === "MPESA") {
      bankName = "MPesa Wallet";
    }
    setState({
      deliveryOption: value,
      bankName: bankName,
    });
    setState({
      deliveryOption: value,
      bankName: bankName,
    });
  };

  const onFinish = async (value) => {
    let formDataPayload = {
      requestType: "RECEIVERADD",
      nickName: value.nickName,
      recvFirstName: value.firstName,
      recvMiddleName: "",
      recvLastName: value.lastName,
      dob: "",
      receiverType: "INDIVIDUAL",
      accountNo: value.accountNo,
      relationship: "SELF",
      gender: "M",
      address1: value.address,
      address2: value.address,
      state: value.state,
      stateOther: "",
      city: value.city,
      cityOther: "",
      zipcode: value.pincode,
      emailId: "",
      mobileCountryCode: value.mobileCountryCode,
      mobileNo: value.mobileNumber,
      altPhone: value.phoneNumber,
      fax: "",
      recvModeCode: value.deliveryOption,
      accountHolderName: value.senderFirstName + " " + value.senderLastName,

      bankBranch: state.updateBankBranch,
      bankCity: state.updateBankCity,
      bankState: state.updateBankState,
      bankCode: state.updateBankCode,
      isSameBank: state.isSameBank,

      // accountType: value.accountType,
      accountType: "S",
      bankName: state.bankName === "" ? value.bankName : state.bankName,
      purpose: "SAVINGS",
      purposeCode: "P1301",
      remark: "",

      nearestLogisticCity: "",
      sendAmount: value.amount,
      sendCountryCode: "US",
      sendCurrencyCode: value.currency,
      sendFirstName: value.senderFirstName,
      sendLastName: value.senderLastName,
      sendMobilePhoneCode: value.mobileCountryCode,
      sendMobileNo: value.senderMobileNumber,
      countryCode: "KE",
      currencyCode: "KES",
      uniqueIdentifierType: "",
      uniqueIdentifierValue: "",
      senderLoginid: value.senderEmailID,
      recvLoginid: value.emailID,
    };
    setLoader(true);
    hookRequestMoney.sendRequest(formDataPayload, (res) => {
      if (res.status == "S") {
        Swal.fire({
          title: "Success",
          text: "Request sent successfully",
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            // navigate('/signin');
            window.location.href = "/signin";
          }
        });
      } else {
        notification.error({ message: res.errorMessage });
      }
      setLoader(false);
    });
  };

  const onFailed = ({ errorFields }) => {
    form.scrollToField(errorFields[0].name);
  };

  return (
    <div className="request-money bg_gradient container mt-md-5 mt-sm-5">
      <div className="request-money-inside-container T3_container">
        <Spin spinning={loading}>
          {!state.showConfirmBankAccountDetails && (
            <Row className="justify-content-center">
              <Col lg={12} md={12}>
                <div className="card p-3 mb-4">
                  {/* <TestDemo/> */}
                  <Form
                    form={form}
                    onFinish={onFinish}
                    onFinishFailed={onFailed}
                    initialValues={{
                      amount: 1000,
                      currency: "USD",
                      mobileCountryCode: "1",
                      country: AuthReducer.recvCountryCode,
                    }}
                  >
                    <Row className="justify-content-center flex-column">
                      <Col>
                        <h4 className="title mb-4">Request Money</h4>
                        <Row className="justify-content-center">
                          <Col md={12}>
                            <h4 className="sub-title mb-4">
                              Sender &amp; Transcation Details{" "}
                              {/* {hookGetCountryPhoenCodes.isLoading
                            ? "true"
                            : "false"} */}
                            </h4>
                          </Col>
                          <Col md={12}>
                            <Row className="justify-content-center">
                              <Col md={6}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Amount
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="amount"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Amount.",
                                    },
                                    {
                                      pattern: /^[0-9\b]+$/,
                                      message: "Only Numbers allowed",
                                    },
                                    ({ getFieldValue }) => ({
                                      validator(rule, value) {
                                        if (!value) {
                                          return Promise.reject();
                                        }
                                        if (parseInt(value) <= 0) {
                                          return Promise.reject(
                                            "Amount should be greater than 0"
                                          );
                                        }
                                        return Promise.resolve();
                                      },
                                    }),
                                  ]}
                                >
                                  <Input
                                    size="large"
                                    placeholder="Enter Amount"
                                  />
                                </Form.Item>
                              </Col>
                              <Col md={6}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Currency
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="currency"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Please select Currency",
                                    },
                                  ]}
                                >
                                  <Select
                                    showSearch
                                    className="w-100"
                                    placeholder="Select Currency"
                                    size="large"
                                  >
                                    <Option key="ac1" value="USD">
                                      USD
                                    </Option>
                                  </Select>
                                </Form.Item>
                              </Col>
                            </Row>
                          </Col>
                          <Col md={6}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Sender First
                              Name
                            </label>
                            <Form.Item
                              className="form-item"
                              name="senderFirstName"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Sender First Name.",
                                },
                                {
                                  min: 3,
                                  message:
                                    "First Name should be between 3 and 50 characters long",
                                },
                                {
                                  max: 50,
                                  message:
                                    "First Name should be between 3 and 50 characters long",
                                },
                                {
                                  pattern: /^[a-zA-Z]+$/,
                                  message: "Please enter valid first name",
                                },
                              ]}
                            >
                              <Input
                                size="large"
                                placeholder="Sender First Name"
                              />
                            </Form.Item>
                          </Col>

                          <Col md={6}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Sender Last Name
                            </label>
                            <Form.Item
                              className="form-item"
                              name="senderLastName"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Sender Last Name.",
                                },
                                {
                                  min: 3,
                                  message:
                                    "Last Name should be between 3 and 50 characters long",
                                },
                                {
                                  max: 50,
                                  message:
                                    "Last Name should be between 3 and 50 characters long",
                                },
                                {
                                  pattern: /^[a-zA-Z]+$/,
                                  message: "Please enter valid last name",
                                },
                              ]}
                            >
                              <Input
                                size="large"
                                placeholder="Sender Last Name"
                              />
                            </Form.Item>
                          </Col>
                          <Col md={12}>
                            <Row className="justify-content-center">
                              <Col md={3}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Country Code
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="mobileCountryCode"
                                  rules={[
                                    {
                                      required: true,
                                      message:
                                        "Please select your Country Code.",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Country Code"
                                  >
                                    {state.phoneCodes.map((phoneCode, i) => {
                                      return (
                                        <Option
                                          key={i}
                                          value={phoneCode.countryPhoneCode}
                                        >{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>
                                      );
                                    })}
                                  </Select>
                                </Form.Item>
                              </Col>
                              <Col md={9}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Sender
                                  Mobile Name
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="senderMobileNumber"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Sender Mobile Number.",
                                    },
                                    {
                                      min: 10,
                                      max: 10,
                                      message:
                                        "Mobile number must be 10 digit.",
                                    },
                                    {
                                      pattern: /^[0-9\b]+$/,
                                      message: "Only Numbers allowed",
                                    },
                                  ]}
                                >
                                  <Input
                                    size="large"
                                    placeholder="Sender Mobile Number"
                                  />
                                </Form.Item>
                              </Col>
                            </Row>
                          </Col>

                          <Col md={12}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Sender Email ID
                            </label>
                            <Form.Item
                              className="form-item"
                              name="senderEmailID"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Sender Email ID.",
                                },
                                {
                                  type: "email",
                                  message: "Please input valid Email ID.",
                                },
                              ]}
                            >
                              <Input
                                size="large"
                                placeholder="Sender Email ID"
                              />
                            </Form.Item>
                          </Col>

                          <Col md={12}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Message
                            </label>
                            <Form.Item
                              className="form-item"
                              name="senderMessage"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Message.",
                                },
                                {
                                  min: 3,
                                  message:
                                    "Message should be between 3 and 50 characters long",
                                },
                                {
                                  max: 50,
                                  message:
                                    "Message should be between 3 and 50 characters long",
                                },
                              ]}
                            >
                              <Input size="large" placeholder="Message" />
                            </Form.Item>
                          </Col>
                          <Col md={12}>
                            <h5 className="mb-3">Your Bank Details</h5>
                          </Col>
                          <Col md={12}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Delivery Option
                            </label>
                            <Form.Item
                              className="form-item"
                              name="deliveryOption"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Delivery Option.",
                                },
                              ]}
                            >
                              <Select
                                size="large"
                                className="w-100"
                                placeholder="Select Delivery Options"
                                onChange={onChangeDeliveryOptionHandler}
                              >
                                {state.deliveryOptionsList.map(
                                  (deliveryOption, i) => {
                                    return (
                                      <Option
                                        key={i}
                                        value={deliveryOption.recvModeCode}
                                      >{`(${deliveryOption.recvMode}) ${deliveryOption.recvModeCode}`}</Option>
                                    );
                                  }
                                )}
                              </Select>
                            </Form.Item>
                          </Col>
                          {state.deliveryOption === "VOOMA" ||
                          state.deliveryOption === "MPESA" ? (
                            <>
                              <Col md={6}>
                                <div className="">
                                  <label className="form-label">
                                    <span className="red_ast">*</span>Wallet
                                    Mobile Number
                                  </label>
                                  <Form.Item
                                    className="form-item"
                                    name="accountNo"
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please input your Mobile Number.",
                                      },
                                      {
                                        min: 8,
                                        max: 16,
                                        message:
                                          "Mobile Number should be between 8 to 16 digits",
                                      },
                                      {
                                        pattern: /^[0-9\b]+$/,
                                        message: "Only Numbers allowed",
                                      },
                                      // {
                                      //   min: 12,
                                      //   max: 12,
                                      //   message: "Account number must be 12 digit.",
                                      // },
                                    ]}
                                  >
                                    <Input.Password
                                      size="large"
                                      placeholder="Enter your Wallet Mobile Number"
                                      onPaste={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                      onCopy={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                      visibilityToggle={false}
                                    />
                                  </Form.Item>
                                </div>
                              </Col>
                              <Col md={6}>
                                <div className="">
                                  <label className="form-label">
                                    <span className="red_ast">*</span>Confirm
                                    Wallet Mobile Number
                                  </label>
                                  <Form.Item
                                    className="form-item"
                                    name="accConNum"
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please input your Confirm  Mobile Number.",
                                      },
                                      {
                                        min: 8,
                                        max: 16,
                                        message:
                                          "Mobile Number should be between 8 to 16 digits",
                                      },
                                      {
                                        pattern: /^[0-9\b]+$/,
                                        message: "Only Numbers allowed",
                                      },
                                      ({ getFieldValue }) => ({
                                        validator(rule, value) {
                                          if (
                                            !value ||
                                            getFieldValue("accountNo") === value
                                          ) {
                                            return Promise.resolve();
                                          }
                                          return Promise.reject(
                                            "The two account number that you entered do not match!"
                                          );
                                        },
                                      }),
                                    ]}
                                  >
                                    <Input
                                      size="large"
                                      placeholder="Enter your Confirm Wallet Mobile Number"
                                      onPaste={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                      onCopy={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                    />
                                  </Form.Item>
                                </div>
                              </Col>
                            </>
                          ) : (
                            ""
                          )}
                          {state.deliveryOption === "DC" && (
                            <>
                              <Col md={4}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Bank Name
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="bankName"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Bank Name.",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Bank Name"
                                    onChange={onChangeBankBranchState}
                                  >
                                    {state.bankNames.map((bankName, i) => {
                                      return (
                                        <Option
                                          key={i}
                                          value={bankName.bankCode}
                                        >{`${bankName.bankName}`}</Option>
                                      );
                                    })}
                                  </Select>
                                </Form.Item>
                              </Col>

                              <Col md={4}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Bank Branch
                                  State
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="bankBranchState"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Bank Branch State.",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Bank Branch State"
                                    onChange={onChangeBankBranchCity}
                                  >
                                    {state.bankBranchStates.map(
                                      (bankBranchState, i) => {
                                        return (
                                          <Option
                                            key={i}
                                            value={bankBranchState.state}
                                          >
                                            {bankBranchState.state}
                                          </Option>
                                        );
                                      }
                                    )}
                                  </Select>
                                </Form.Item>
                              </Col>

                              <Col md={4}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Bank Branch
                                  City
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="bankBranchCity"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Bank Branch City.",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Bank Branch City"
                                    onChange={onChangeBankBranchName}
                                  >
                                    {state.bankBranchCities.map(
                                      (bankBranchCity, i) => {
                                        return (
                                          <Option
                                            key={i}
                                            value={bankBranchCity.city}
                                          >
                                            {bankBranchCity.city}
                                          </Option>
                                        );
                                      }
                                    )}
                                  </Select>
                                </Form.Item>
                              </Col>

                              <Col md={6}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Bank Branch
                                  Name
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="bankBranchName"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Bank Branch Name.",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Bank Branch Name"
                                    onChange={onChangeBankBranchNameSelect}
                                  >
                                    {state.bankBranchNames.map(
                                      (bankBranchName, i) => {
                                        return (
                                          <Option
                                            key={i}
                                            value={bankBranchName.branchCode}
                                          >
                                            {bankBranchName.branchName}
                                          </Option>
                                        );
                                      }
                                    )}
                                  </Select>
                                </Form.Item>
                              </Col>

                              <Col md={6}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Branch Code
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="branchCode"
                                >
                                  <Input
                                    size="large"
                                    placeholder="Branch Code"
                                    readOnly={true}
                                  />
                                </Form.Item>
                              </Col>

                              <Col md={6}>
                                <div className="">
                                  <label className="form-label">
                                    <span className="red_ast">*</span>Account
                                    Number
                                  </label>
                                  <Form.Item
                                    className="form-item"
                                    name="accountNo"
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please input your Account Number.",
                                      },
                                      {
                                        min: 8,
                                        message:
                                          "Account Number should be between 8 and 16 digits",
                                      },
                                      {
                                        max: 16,
                                        message:
                                          "Account Number should be between 8 and 16 digits",
                                      },
                                      {
                                        pattern: /^[0-9\b]+$/,
                                        message: "Only Numbers allowed",
                                      },
                                    ]}
                                  >
                                    <Input.Password
                                      size="large"
                                      placeholder="Enter your Account Number"
                                    />
                                  </Form.Item>
                                </div>
                              </Col>
                              <Col md={6}>
                                <div className="">
                                  <label className="form-label">
                                    <span className="red_ast">*</span>Confirm
                                    Account Number
                                  </label>
                                  <Form.Item
                                    className="form-item"
                                    name="accConNum"
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please input your Confirm Account Number.",
                                      },
                                      {
                                        pattern: /^[0-9\b]+$/,
                                        message: "Only Numbers allowed",
                                      },
                                      ({ getFieldValue }) => ({
                                        validator(rule, value) {
                                          if (
                                            !value ||
                                            getFieldValue("accountNo") === value
                                          ) {
                                            return Promise.resolve();
                                          }
                                          return Promise.reject(
                                            "The two account number that you entered do not match!"
                                          );
                                        },
                                      }),
                                    ]}
                                  >
                                    <Input
                                      size="large"
                                      placeholder="Enter your Confirm Account Number"
                                    />
                                  </Form.Item>
                                </div>
                              </Col>
                            </>
                          )}

                          {/* {state.deliveryOption === "VOOMA" && (
                            <>
                              <Col md={6}>
                                <div className="">
                                  <label className="form-label">
                                    <span className="red_ast">*</span>Mobile
                                    Number (VOOMA Wallet)
                                  </label>
                                  <Form.Item
                                    className="form-item"
                                    name="accountNo"
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please input your Mobile Number.",
                                      },
                                      {
                                        min: 9,
                                        max: 12,
                                        message:
                                          "Mobile Number should be between 9 to 12 digits",
                                      },
                                      {
                                        pattern: /^[0-9\b]+$/,
                                        message: "Only Numbers allowed",
                                      },
                                      // {
                                      //   min: 12,
                                      //   max: 12,
                                      //   message: "Account number must be 12 digit.",
                                      // },
                                    ]}
                                  >
                                    <Input.Password
                                      size="large"
                                      placeholder="Enter your Mobile Number (VOOMA Wallet)"
                                      maxLength={12}
                                      onPaste={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                      onCopy={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                      visibilityToggle={false}
                                    />
                                  </Form.Item>
                                </div>
                              </Col>
                              <Col md={6}>
                                <div className="">
                                  <label className="form-label">
                                    <span className="red_ast">*</span>Confirm
                                    Mobile Number (VOOMA Wallet)
                                  </label>
                                  <Form.Item
                                    className="form-item"
                                    name="accConNum"
                                    rules={[
                                      {
                                        required: true,
                                        message:
                                          "Please input your Confirm Mobile Number.",
                                      },
                                      {
                                        min: 9,
                                        max: 12,
                                        message:
                                          "Mobile Number should be between 9 to 12 digits",
                                      },
                                      {
                                        pattern: /^[0-9\b]+$/,
                                        message: "Only Numbers allowed",
                                      },
                                      ({ getFieldValue }) => ({
                                        validator(rule, value) {
                                          if (
                                            !value ||
                                            getFieldValue("accountNo") === value
                                          ) {
                                            return Promise.resolve();
                                          }
                                          return Promise.reject(
                                            "The two account number that you entered do not match!"
                                          );
                                        },
                                      }),
                                    ]}
                                  >
                                    <Input
                                      size="large"
                                      placeholder="Enter your Confirm Mobile Number (VOOMA Wallet)"
                                      maxLength={12}
                                      onPaste={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                      onCopy={(e) => {
                                        e.preventDefault();
                                        return false;
                                      }}
                                    />
                                  </Form.Item>
                                </div>
                              </Col>
                            </>
                          )} */}

                          {/* <Col md={12}>
                            <div className="">
                              <label className="form-label">Account Type</label>
                              <Form.Item
                                className="form-item"
                                name="accountType"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please select Account Type",
                                  },
                                ]}
                              >
                                <Select
                                  showSearch
                                  className="w-100"
                                  placeholder="Select Account Type"
                                  size="large"
                                >
                                  <Option key="ac1" value="S">
                                    Saving
                                  </Option>
                                  <Option key="ac2" value="C">
                                    Current / Checking
                                  </Option>
                                </Select>
                              </Form.Item>
                            </div>
                          </Col> */}
                        </Row>
                      </Col>

                      <Col>
                        <Row className="justify-content-center">
                          <Col md={12}>
                            <h4 className="sub-title mt-5 mb-4">
                              Your Personal Details
                            </h4>
                          </Col>
                          <Col md={12}>
                            <Row className="justify-content-center">
                              <Col md={6}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>First Name
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="firstName"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter First Name.",
                                    },
                                    {
                                      min: 3,
                                      message:
                                        "First Name should be between 3 and 50 characters long",
                                    },
                                    {
                                      max: 50,
                                      message:
                                        "First Name should be between 3 and 50 characters long",
                                    },
                                    {
                                      pattern: /^[a-zA-Z]+$/,
                                      message: "Please enter valid first name",
                                    },
                                  ]}
                                >
                                  <Input
                                    size="large"
                                    placeholder="Enter First Name"
                                  />
                                </Form.Item>
                              </Col>
                              <Col md={6}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Last Name
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="lastName"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Last Name.",
                                    },
                                    {
                                      min: 3,
                                      message:
                                        "Last Name should be between 3 and 50 characters long",
                                    },
                                    {
                                      max: 50,
                                      message:
                                        "Last Name should be between 3 and 50 characters long",
                                    },
                                    {
                                      pattern: /^[a-zA-Z]+$/,
                                      message: "Please enter valid last name",
                                    },
                                  ]}
                                >
                                  <Input
                                    size="large"
                                    placeholder="Enter Last Name"
                                  />
                                </Form.Item>
                              </Col>
                            </Row>
                          </Col>
                          <Col md={12}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Nick Name
                            </label>
                            <Form.Item
                              className="form-item"
                              name="nickName"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter NickName.",
                                },
                                {
                                  min: 3,
                                  message:
                                    "Nick Name should be between 3 and 40 characters",
                                },
                                {
                                  max: 40,
                                  message:
                                    "Nick Name should be between 3 and 40 characters",
                                },
                                {
                                  pattern: /^[a-zA-Z0-9]+$/,
                                  message: "No Special Chars",
                                },
                              ]}
                            >
                              <Input size="large" placeholder="Nick Name" />
                            </Form.Item>
                          </Col>

                          <Col md={12}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Address
                            </label>
                            <Form.Item
                              className="form-item"
                              name="address"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Address.",
                                },
                                {
                                  min: 3,
                                  max: 100,
                                  message:
                                    "Address should be between 3 and 100 characters",
                                },
                              ]}
                            >
                              <Input.TextArea
                                size="large"
                                placeholder="Address"
                              />
                            </Form.Item>
                          </Col>

                          <Col md={3}>
                            <label className="form-label">
                              <span className="red_ast">*</span>State
                            </label>
                            <Form.Item
                              className="form-item"
                              name="state"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter State.",
                                },
                              ]}
                            >
                              <Select
                                size="large"
                                className="w-100"
                                placeholder="Select State"
                                onChange={onChangeBankBranchCity}
                              >
                                {state.bankBranchStates.map(
                                  (bankBranchState, i) => {
                                    return (
                                      <Option
                                        key={i}
                                        value={bankBranchState.state}
                                      >
                                        {bankBranchState.state}
                                      </Option>
                                    );
                                  }
                                )}
                              </Select>
                            </Form.Item>
                          </Col>

                          <Col md={3}>
                            <label className="form-label">
                              <span className="red_ast">*</span>City
                            </label>
                            <Form.Item
                              className="form-item"
                              name="city"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter City.",
                                },
                              ]}
                            >
                              <Select
                                size="large"
                                className="w-100"
                                placeholder="Select City"
                              >
                                {state.bankBranchCities.map(
                                  (bankBranchCity, i) => {
                                    return (
                                      <Option
                                        key={i}
                                        value={bankBranchCity.city}
                                      >
                                        {bankBranchCity.city}
                                      </Option>
                                    );
                                  }
                                )}
                              </Select>
                            </Form.Item>
                          </Col>

                          <Col md={3}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Pincode
                            </label>
                            <Form.Item
                              className="form-item"
                              name="pincode"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Pincode Code.",
                                },
                                {
                                  min: 5,
                                  message: "Minimum 5 Digits",
                                },
                                {
                                  max: 5,
                                  message: "Maximum 5 Digits",
                                },
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only Numbers allowed",
                                },
                              ]}
                            >
                              <Input size="large" placeholder="Pincode" />
                            </Form.Item>
                          </Col>

                          <Col md={3}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Country
                            </label>
                            <Form.Item
                              className="form-item"
                              name="country"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Country.",
                                },
                              ]}
                            >
                              <Select
                                size="large"
                                className="w-100"
                                placeholder="Select Country"
                              >
                                {state.recvCountryList.map((v, i) => {
                                  return (
                                    <Option key={i} value={v.recvCountry}>
                                      {v.countryName}
                                    </Option>
                                  );
                                })}
                              </Select>
                            </Form.Item>
                          </Col>

                          <Col md={12}>
                            <label className="form-label">
                              <span className="red_ast">*</span>Email ID
                            </label>
                            <Form.Item
                              className="form-item"
                              name="emailID"
                              rules={[
                                {
                                  required: true,
                                  message: "Enter Email ID.",
                                },
                                {
                                  type: "email",
                                  message: "Please enter valid email.",
                                },
                              ]}
                            >
                              <Input size="large" placeholder="Email ID" />
                            </Form.Item>
                          </Col>

                          <Col md={12}>
                            <Row className="justify-content-center">
                              <Col md={3}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Country Code
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="countryMobileCode"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Country Code",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Country Code"
                                  >
                                    {state.phoneCodes.map((phoneCode, i) => {
                                      return (
                                        <Option
                                          key={i}
                                          value={phoneCode.countryPhoneCode}
                                        >{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>
                                      );
                                    })}
                                  </Select>
                                </Form.Item>
                              </Col>
                              <Col md={9}>
                                <label className="form-label">
                                  <span className="red_ast">*</span>Mobile
                                  Number
                                </label>
                                <Form.Item
                                  className="form-item"
                                  name="mobileNumber"
                                  rules={[
                                    {
                                      required: true,
                                      message: "Enter Sender Mobile Number.",
                                    },
                                    {
                                      min: 10,
                                      max: 10,
                                      message:
                                        "Mobile number must be 10 digit.",
                                    },
                                    {
                                      pattern: /^[0-9\b]+$/,
                                      message: "Only Numbers allowed",
                                    },
                                  ]}
                                >
                                  <Input
                                    size="large"
                                    placeholder="Sender Mobile Number"
                                  />
                                </Form.Item>
                              </Col>
                            </Row>
                          </Col>
                          <Col md={12}>
                            <label className="form-label">Phone No</label>
                            <Form.Item
                              className="form-item"
                              name="phoneNumber"
                              rules={[
                                {
                                  pattern: /^[0-9\b]+$/,
                                  message: "Only Numbers allowed",
                                },
                              ]}
                            >
                              <Input size="large" placeholder="Phone No" />
                            </Form.Item>
                          </Col>
                        </Row>
                      </Col>

                      <Col md={12}>
                        <div className="d-flex justify-content-end">
                          <Link
                            to={"/"}
                            className="btn btn-secondary btn-sm me-3 my-3"
                          >
                            Back
                          </Link>
                          <button
                            className="btn btn-primary text-white btn-sm my-3"
                            type="submit"
                            // onClick={() => setIsICICI(true)}
                          >
                            Continue
                          </button>
                        </div>
                      </Col>
                    </Row>
                  </Form>
                </div>
              </Col>
            </Row>
          )}
        </Spin>
      </div>
    </div>
  );
}
