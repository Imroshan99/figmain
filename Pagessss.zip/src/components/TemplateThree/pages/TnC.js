export default function TnC() {
  return (
    <div className="bg_gradient container mt-md-4 mt-sm-4">
      <div className="T3_container ">
        
        <div className="title pt-0 pt-md-4">
          Terms and Conditions
        </div>
        <div className="fw-700 my-3">
          Golden Money Transfer User Agreement
        </div>
        
        <p>
          BY CONSENTING TO THIS USER AGREEMENT, YOU AGREE TO ARBITRATE ANY
          DISPUTE BETWEEN YOU AND GOLDEN MONEY TRANSFER, INC. RELATED TO THIS
          AGREEMENT. YOU FURTHER AGREE TO WAIVE ANY RIGHT TO PARTICIPATE IN ANY
          CLASS ACTION RELATED TO THIS AGREEMENT. PLEASE READ THIS AGREEMENT
          CAREFULLY BEFORE UTILIZING THE GMT SERVICES.
        </p>
        <p>Last updated: June 24h, 2021.</p>
        <p>
          This <em>Golden Money Transfer User Agreement</em> (this
          &ldquo;Agreement&rdquo;) is effective as of June 24th, 2021, under
          which you may use the services provided by GOLDEN MONEY TRANSFER, INC.
          (&ldquo;GMT&rdquo;).
        </p>
        <p>
          This Agreement is a legally binding agreement between you and GMT, and
          shall apply to your use of the GMT international money transmission
          service made available through the GMT App or website (the
          &ldquo;Service/s&rdquo;).&nbsp;
        </p>
        <p>In this Agreement,</p>
        <ol>
          <li>
            "you" or "your" means any person ("Users") using the Service;
            <br />
            "we" or "us" or "our" means GMT, a licensed money transfer company
            approved by 32 states in the United States of America.
          </li>
          <li>
            &ldquo;partner&rdquo; or &ldquo;partners&rdquo; means any
            third-party service provider engaged by GMT for facilitating the
            provision of the service/s, including but not limited to any
            correspondent agents of GMT.
          </li>
          <li>
            Any term otherwise not defined in this Agreement shall have the
            meaning generally applied to such terms in the particular context
            wherein they are used.
          </li>
        </ol>
        <p>
          &nbsp;BY ACCESSING AND / OR USING THE SERVICE OR ANY PORTION THEREOF
          AND / OR ANY FACILITIES YOU AGREE TO THIS AGREEMENT AND THE ATTACHED
          PRIVACY POLICY. FURTHER, BY AGREEING TO THIS AGREEMENT YOU AGREE THAT
          ANY DISPUTE BETWEEN YOU AND GMT BE RESOLVED BY BINDING ARBITRATION IN
          LIEU OF COURT TRIAL. IF YOU DO NOT AGREE TO THE TERMS OF THIS
          AGREEMENT, YOU MAY NOT ACTIVATE OR USE THE SERVICES.
        </p>
        <p>
          <strong>I. REPRESENTATION</strong>
        </p>
        <ol>
          <li>
            The Service is provided by GMT. By using the Service, you consent to
            becoming a customer of GMT and further consent to GMT processing and
            retaining your personal and financial data to provide the Service to
            you and to comply with applicable law.
          </li>
          <li>
            Once you authorize your transaction, your funds will be controlled
            at all times by GMT.
          </li>
        </ol>
        <p>
          <strong>II.&nbsp;YOUR CONSENT</strong>
        </p>
        <p>
          By utilizing the Service you accept this Agreement, you enter into a
          legal and contractual relationship with GMT in order to send funds to
          your beneficiary. You, in your capacity as a remittance sender, hereby
          appoint your beneficiary as your agent for the purpose of receiving
          funds in connection with the Service. You consent to abide by this
          Agreement and Privacy Policy of GMT at all times in relation to the
          use of the Service. GMT will verify your identity before allowing you
          to send money. You may contact GMT customer support using the contact
          details listed below:
        </p>
        <p>
          Golden Money Transfer, Inc.
          <br />
          739 Fourth Ave #204,
          <br />
          San Diego, California 92101, USA,
          <br />
          email at
          <a href="mailto:info@gmtnorthamerica.com">info@gmtnorthamerica.com</a>
          or call <a href="tel:1-888-702-5656">1-888-702-5656</a>
        </p>
        
        <p>
          <strong>III. ELIGIBLE USERS</strong>
        </p>
        <p>
          In order to access and use the website and avail yourself of any
          Service you must be an individual of at least 18 years of age who can
          enter into legally binding contracts under applicable law. If you do
          not qualify, you may not access or use the Service.
        </p>
        <p>
          <strong>IV. PAYMENT</strong>
        </p>
        <ol>
          <li>
            You agree to pay us the transaction amount for every transaction
            that you place in the Service. Additional charges may apply. Payment
            is due at the time your transaction is submitted for processing. You
            agree to reimburse us all fees if you submit a Transaction that
            results in being charged for non-sufficient fund fees, chargeback
            fees, or other similar fees.
          </li>
          <li>
            You can find a list of all fees on the Long Form Disclosure and a
            summary fee disclosure required by the Consumer Financial Protection
            Bureau on the Short Form Disclosure. For clarity, the fees
            applicable to you on the Pricing Page form part of this Customer
            Agreement and are subject to change.
          </li>
          <li>
            You are responsible for any taxes which may be applicable to
            payments you make or receive, and it is your responsibility to
            collect, report and pay the correct tax to the appropriate tax
            authority.
          </li>
          <li>
            &nbsp;By making any transaction with the Service, you authorize GMT
            and/or its agents to debit the amount (including transaction fees
            and any other applicable fees) from your account.
          </li>
          <li>
            In case if you fail to make payment and your transaction is already
            delivered to your Beneficiary, we have the right to take all
            possible actions to recover the payment, to the extent permitted by
            law. Your failure to fully pay amounts that you owe us is a material
            breach of this Agreement and you will be liable for our costs
            associated with recovery and collection in addition to the amount
            owed, including without limitation attorneys&rsquo; fees and
            expenses, costs of any arbitration or court proceeding, collection
            agency fees, and any applicable interest.
          </li>
        </ol>
        <p>
          <strong>V. PAYOUT AND DELIVERY</strong>
        </p>
        <ol>
          <li>
            All Payouts of your remittance funds to the beneficiary will be made
            by GMT through its partners or it&rsquo;s Correspondent Agents in
            the destination country defined by you at the time of creation of
            transaction. You authorize us to make all such Payouts, and are
            solely responsible for any consequence that may come forth upon
            credit of the payment by us into the account of the beneficiary as
            determined at the time of entering the transaction.
          </li>
          <li>
            Your beneficiary will be required to provide us with the copy of
            their Identity (Government Issued ID Card) before receiving funds in
            their bank account. You give us permission to contact your
            beneficiary and store all such data as necessary to provide the
            Service and to comply with applicable law.
          </li>
          <li>
            You represent that the Beneficiary determined by you accepts the
            agency appointed by you as per the terms of this User Agreement to
            receive the funds transferred using the service.
          </li>
          <li>
            You are required to verify that the bank account information of the
            beneficiary is correct prior to submitting your Transaction. We are
            not responsible for detecting inaccuracies related to beneficiary
            bank account information you submit to us. If the bank account
            information and bank details of the beneficiary are incorrect, the
            funds may be credited to the wrong bank or beneficiary and may not
            be recovered. We or our partners shall not be liable for such wrong
            delivery of funds.
          </li>
        </ol>
        <p>
          <strong>VI. OTHER TERMS</strong>
        </p>
        <ol>
          <li>
            We shall not be under any duty to assess the prudence or otherwise
            of any instruction or transaction given or entered into by you.
          </li>
          <li>
            We reserve the right to hold and/or reject any transaction requested
            by you via the Service at our sole discretion and without any
            obligation to disclose such reason to you.
          </li>
          <li>
            We shall be entitled, in our sole and absolute discretion, to refuse
            to comply with all or any of your instructions without assigning any
            reason.
          </li>
          <li>
            We shall have the right to, and you hereby authorize us to, verify
            any information provided by you. As a standard know-your-customer
            (&ldquo;KYC&rdquo;) check we may be required to verify your identity
            details.
          </li>
          <li>
            We represent, and you agree that, we may make money while converting
            your U.S. dollars into the local currency of the destination country
            where the beneficiary determined by you at the time of creation of
            transaction resides in, in addition to the transaction fee.
          </li>
          <li>
            You are not entitled to any interest or any other income that may
            arise on your monies which are held by GMT.
          </li>
        </ol>
        <p>
          <strong>VII. ACCEPTABLE USE POLICY</strong>
        </p>
        <ol>
          <li>
            You may not use the Services to engage in the following categories
            of activity ("Prohibited Uses"). The specific types of use listed
            below are representative, but not exhaustive. If you are uncertain
            as to whether or not your use of the Services involves a Prohibited
            Use, or have questions about how these requirements apply to you,
            please contact us at info@gmtnorthamerica.com. By using GMT
            services, you confirm that you will not use them to do any of the
            following:
          </li>
          <li>
            Prohibited Jurisdictions: Activity which would enable access to the
            Services from any Prohibited Jurisdiction.
          </li>
          <li>
            Unlawful Activity: Activity which would violate, or assist in
            violation of, any law, statute, ordinance, or regulation, sanctions
            programs administered in the countries where GMT conducts business,
            including the U.S. Department of Treasury's Office of Foreign Assets
            Control (OFAC"), or which would involve proceeds of any unlawful
            activity; publish, distribute or disseminate any unlawful material
            or information;
          </li>
          <li>
            Abuse Other Users : Interfere with another individual's or entity's
            access to or use of any Services; defame, abuse, extort, harass,
            stalk, threaten or otherwise violate or infringe the legal rights
            (such as rights of privacy, publicity and intellectual property) of
            others; incite, threaten, facilitate, promote, or encourage hate,
            racial intolerance, or violent acts against others; harvest or
            otherwise collect information through the Services about others,
            including email addresses, without proper consent;
          </li>
          <li>
            Fraud : Activity which operates to defraud GMT, GMT&acute;s users,
            or any other person; provide any false, inaccurate, or misleading
            information to GMT;
          </li>
          <li>
            Gambling : Lotteries; bidding fee auctions; sports forecasting or
            odds making; fantasy sports leagues with cash prizes; Internet
            gaming; contests; sweepstakes; games of chance; an
          </li>
          <li>
            Intellectual Property Infringement : Engage in transactions or post,
            upload, publish, submit or transmit any User Content involving items
            that infringe or violate any copyright, trademark, trade secret,
            moral rights, right of publicity or privacy or any other proprietary
            right under the law, including sales, distribution, or access to
            counterfeit music, movies, software, or other licensed materials
            without appropriate authorization from the rights holder; use of GMT
            intellectual property, name, or logo, including any Mark, without
            written consent from GMT, or in a manner that otherwise harms GMT or
            the GMT brand; any action that implies an untrue endorsement by or
            affiliation with GMT; or
          </li>
          <li>
            Encouraging or Enabling Others to Commit any Prohibited Use:
            Activity that may encourage or enable any other individual to do any
            of the foregoing.
          </li>
        </ol>
        <p>
          <strong>VIII. ERROR RESOLUTION </strong>
        </p>
        <ol>
          <li>
            You have the right to dispute errors in your transaction. If you
            think there is an error, contact GMT within 180 days at
            1-888-702-5656 or&nbsp;
            <a href="https://www.gmtnorthamerica.com/contact-us/">
              https://www.gmtnorthamerica.com/contact-us/
            </a>
            .You can also contact us for a written explanation of your rights.
            You can cancel for a full refund within 30 minutes of payment unless
            the funds have been picked up or deposited. For questions or
            complaints about Golden Money Transfer, Inc., contact&nbsp;
            <a href="mailto:info@gmtnorthamerica.com">
              info@gmtnorthamerica.com
            </a>
            .
          </li>
          <li>
            To resolve an error or file a complaint, please contact GMT Customer
            Service before contacting the state licensing division as indicated
            on the list below with a complaint:
            <p>
              Golden Money Transfer, Inc.&nbsp;
              <br />
              Phone: 1-888-702-5656
              <br />
              Written Mail:
              <br />
              Golden Money Transfer, Inc.
              <br />
              Attn: Manager, Customer service
              <br />
              739 4th Avenue, Suite 204
              <br />
              San Diego, CA 92101
              <br />
              Email:&nbsp;
              <a href="mailto:info@gmtnorthamerica.com">
                info@gmtnorthamerica.com
              </a>
            </p>
            <p>
              Consumer Financial Protection Bureau
              <br />
              Phone: 855-411-2372
              <br />
              855-729-2372 (TTY/TTD)
              <br />
              <a href="http://www.consumerfinance.gov">
                www.consumerfinance.gov
              </a>
            </p>
          </li>
        </ol>
        <p>
          <strong>IX. SYSTEM MAINTENANCE</strong>
        </p>
        <p>
          The Service may be temporarily unavailable from time to time during
          routine system maintenance and updates. During times when the Service
          is unavailable due to system maintenance, GMT will queue your
          transaction and send once the Service is available, which may result
          in longer transaction times. You agree to relieve us from any
          liability or losses that may be associated with such maintenance or
          updates.
        </p>
        <p>
          <strong>&nbsp;X.&nbsp;DISCLAIMERS</strong>
        </p>
        <p>
          THE SERVICE IS PROVIDED "AS IS" AND &ldquo;AS AVAILABLE&rdquo;,
          WITHOUT ANY REPRESENTATION OF WARRANTY, WHETHER EXPRESS, IMPLIED OR
          STATUTORY. USE OF THE SERVICES IS AT YOUR OWN RISK. WE AND OUR
          RESPECTIVE OFFICERS, DIRECTORS, AGENTS, EMPLOYEES, PARTNERS AND
          SUPPLIERS SPECIFICALLY DISCLAIM ANY IMPLIED WARRANTIES OF
          MERCHANTABILITY, FITNESS FOR A PARTICULAR PURPOSE AND NON-
          INFRINGEMENT. WE DO NOT REPRESENT OR WARRANT THAT THE SERVICES WILL
          MEET YOUR REQUIREMENTS, BE CONTINUOUS, UNINTERRUPTED, SECURE, TIMELY,
          OR ERROR-FREE, OR THAT DEFECTS WILL BE CORRECTED. NO ADVICE OR
          INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED BY YOU FROM US WILL
          CREATE ANY WARRANTY NOT EXPRESSLY STATED HEREIN. WE SHALL NOT BE
          RESPONSIBLE FOR ANY SERVICE INTERRUPTIONS OR SYSTEM FAILURES THAT MAY
          AFFECT THE PROCESSING, COMPLETION OR SETTLEMENT OF TRANSACTIONS. THIS
          DISCLAIMER OF WARRANTY SECTION SHALL APPLY TO THE FULLEST EXTENT
          PERMITTED BY LAW IN THE APPLICABLE JURISDICTION. FUNDS ASSOCIATED WITH
          USER ACCOUNTS USING THIS SERVICE ARE HELD WITH GMT ONCE TRANSFERRED TO
          GMT.
        </p>
        <p>
          <strong>&nbsp;XI.&nbsp;</strong>
          <strong>FORCE MAJEURE </strong>
        </p>
        <p>
          You understand and agree we will not be held responsible for losses or
          damages resulting from suspension of the Service due to extraordinary
          events or circumstances beyond our control. In the event of a force
          majeure event, we may suspend access to the Service.
        </p>
        <p>
          <strong>&nbsp;XII.&nbsp;</strong>
          <strong>ASSIGNMENT, AMENDMENTS AND WAIVERS</strong>
        </p>
        <ol>
          <li>
            You may not transfer or assign any rights or obligations you have
            under this Agreement. We reserve the right to transfer or assign any
            rights or obligations under this Agreement at any time without your
            consent.
          </li>
          <li>
            We may amend this Agreement at any time by posting a revised version
            on GMT&acute;s website or within the GMT app. All amendments will be
            effective immediately after they are posted.
          </li>
          <li>
            No provision of this Agreement shall be deemed waived by us, unless
            such waiver is in writing and signed by us. Our failure to enforce
            at any time any of the provisions of the Agreement, or the failure
            to require at any time performance by us of any of the provisions of
            the Agreement, shall in no way be construed to be a present or
            future waiver of such provisions, nor in any way affect the ability
            of a party to enforce each and every such provision thereafter.
          </li>
        </ol>
        <p>
          <strong>&nbsp;XIII.&nbsp;</strong>
          <strong>INDEMNIFICATION</strong>
        </p>
        <ol>
          <li>
            You shall indemnify, defend, and hold GMT, and its partners harmless
            from and against any and all claims, damages, liabilities, costs and
            expenses (referred to collectively herein as &ldquo;Indemnity
            Claim(s)&rdquo;), including reasonable attorneys&rsquo; fees,
            arising out of your failure to perform, or cause to be performed,
            your obligations under this Agreement.
          </li>
          <li>
            Indemnification privileges shall survive the termination of this
            agreement.
          </li>
        </ol>
        <p>
          <strong>&nbsp;XIV.&nbsp;</strong>
          <strong>LIMITATION OF LIABILITY</strong>
        </p>
        <p>Neither party will be liable for:</p>
        <ol>
          <li>
            any loss or damage due to causes beyond its control, including but
            not limited to earthquake, war, fire, flood, terrorism, power
            failure, acts of God or other catastrophes.
          </li>
          <li>
            any special, consequential, indirect or similar damages under or in
            connection with this Agreement including but not limited to loss of
            profits even if a party has been advised of the possibility of such
            damages.
          </li>
          <li>
            GMT shall not be liable for your funds once transferred by GMT
            pursuant to your instructions, as all such funds are then held and
            controlled exclusively by GMT.
          </li>
          <li>
            Our and our Partner&rsquo;s liability towards you related to your
            use of the Service, at any point of time, shall not exceed the
            amount of transaction initiated by you using the Service.
          </li>
        </ol>
        <p>
          <strong>&nbsp;XV.&nbsp;GOVERNING LAW AND ARBITRATION</strong>
        </p>
        <ol>
          <li>
            This User Agreement is formed under and shall be interpreted in
            accordance with the laws of the State of California.
          </li>
          <li>
            This User Agreement is governed by all applicable state and federal
            laws and regulations, except to the extent that this Agreement can
            and does vary from such laws. If any of the terms of this User
            Agreement cannot be legally enforced, they will be considered
            modified to the extent necessary to comply with applicable law. If
            such modification is not possible, the relevant provision or
            part-provision shall be deemed deleted. Any modification to or
            deletion of a provision or part-provision under this clause shall
            not affect the validity or enforceability of the rest of this User
            Agreement.
          </li>
          <li>
            If a dispute arises between you and GMT, our goal is to learn about
            and address your concerns. If we are unable to do so to your
            satisfaction, we will provide you with a neutral and cost effective
            means of resolving the dispute quickly. Disputes between you and GMT
            regarding the Service may be reported to Customer Service by
            telephone at 1-888-702-5656; by fax at 619-702-7378; or by mail at
            Golden Money Transfer, Inc., Attn: Customer Service, 739 4
            <sup>th</sup> Avenue, Suite 204, San Diego, CA 92101, USA.
          </li>
          <li>
            Customers agree that any and all claims, disputes or controversies
            that arise out of or are based on the Service, or User Agreement, or
            involving claims of fraud or misrepresentation, or otherwise, will
            be resolved by binding arbitration by the American Arbitration
            Association. This agreement to arbitrate will apply no matter by
            whom or against whom the claim is made. Any arbitration hearing, if
            one is held, will take place in San Diego, California. This
            arbitration agreement is made pursuant to a transaction involving
            interstate commerce and will be governed by the Federal Arbitration
            Act, 9 U.S.C. Sections 1-16. You agree to submit to the personal
            jurisdiction of the courts located within San Diego County,
            California for the purpose of litigating all such claims or
            disputes. This arbitration agreement will survive the termination of
            this User Agreement and the surrender, termination or discontinuance
            of the Service.
          </li>
          <li>
            To the extent permitted by law, Customer agrees not to bring, join
            or participate in any class action with regard to any claim, dispute
            or controversy Customer may have against GMT, its employees,
            officers, directors or agents.
          </li>
          <li>
            For any claim, excluding those made for injunctive or other
            equitable relief, where the total amount of the award sought is less
            $1,000 USD, the party requesting the relief may elect to resolve the
            dispute in a cost-effective arbitration. If a party chooses
            arbitration, that party will initiate such arbitration through an
            established alternative dispute resolution provider mutually agreed
            upon by the parties. The chosen provider and the parties must comply
            with the following rules: a) the arbitration shall be conducted by
            telephone, online and/or be solely based on written submissions, the
            specific manner shall be chosen by the party initiating the
            arbitration; b) the arbitration shall not involve any personal
            appearance by the parties or witnesses unless otherwise mutually
            agreed by the parties; and c) any judgment on the award rendered by
            the arbitrator may be entered in any court of competent
            jurisdiction.
          </li>
          <li>
            All claims you bring against GMT must be resolved in accordance with
            the Indemnification and Limitation of Liability sections of this
            User Agreement. GMT may recover attorneys&rsquo; fees and costs up
            to $1,000 USD.
          </li>
        </ol>
        <p>
          <strong>
            &nbsp;XVI.&nbsp;REFUND AND CANCELLATION OF REMITTANCE PAYMENT
          </strong>
        </p>
        <ol>
          <li>
            All refunds of your monies shall be made by GMT as per its Terms and
            Conditions.
          </li>
          <li>
            You may cancel your Transaction for a full refund within 30 minutes
            of creating your Transaction, unless the funds have already been
            paid out to the Beneficiary. After 30 minutes, a refund will not be
            provided unless your Transaction was not processed according to your
            instructions or we were unable to pay out the Transaction. To
            request a refund, please contact Customer Service at the details
            provided below.
          </li>
          <li>
            Refunds will be credited to the same Mode of payment used to pay for
            the Transaction. Refunds are only made in U.S. Dollars. Refund
            amounts will not be adjusted to account for changes in the value of
            the U.S. Dollar or foreign currency from the time your Transaction
            was submitted.
          </li>
          <li>
            The amount of funds that is returned to you shall be the amount
            after deducting any service charges and other expenses incurred
            while refunding the funds.
          </li>
          <li>
            If we determine to refund remittance payment funds to you, these
            funds may be returned to you at the exchange rates established by us
            on the date of return. This amount may be different than the
            original amount that was sent. We shall not be liable to you for any
            loss occurred due to cancellation or refund of a remittance payment.
          </li>
        </ol>
        <p>
          <strong>&nbsp;XVII.STATE SPECIFIC INFORMATION </strong>
        </p>
        <p>
          Golden Money Transfer, Inc is a license money transmitter in various
          states and territories of the United States of America.&nbsp; If you
          are a resident of certain states, you may have additional rights under
          such state&rsquo;s laws.&nbsp; Please see applicable state legal
          information along with state regulators at the end of this document.
        </p>
        <p>
          <strong>&nbsp;XVIII.&nbsp;TERMINATION AND SURVIVAL</strong>
        </p>
        <ol>
          <li>
            We may restrict your access to the Service, for any reason,
            including:
          </li>
          <li>
            Discontinuance of use of this service shall not be deemed
            termination of this agreement. You may terminate this agreement by
            contacting us using the contact details listed below. We reserve the
            right to terminate the agreement without giving any prior notice to
            you.
          </li>
          <li>
            This agreement shall be effective from the date you agree to it as
            set out above and shall be applicable so long you use the service.
            <ul>
              <li>&nbsp;your violation of this Agreement,</li>
              <li>
                your violation of the terms of services of any of the partners,
              </li>
              <li>
                Service use inactivity or our assessment that you pose an
                unacceptable risk to our network, based on our confidential risk
                and security criteria.
              </li>
            </ul>
          </li>
        </ol>
        <p>
          Termination of your account or termination of this agreement does not
          relieve you of your liability for any losses incurred by us owing to
          your conduct during your use of the Service.
        </p>
        <p>
          <strong>&nbsp;XIX.&nbsp;NOTICES</strong>
        </p>
        <ol>
          <li>
            We may give notice to you by e-mail, letter, telephone or any other
            means as deemed fit to the e-mail address/address/telephone number
            registered in our system. Notices under this Agreement may be given
            by you in writing by delivering them by hand or by sending them by
            post to the address mentioned in this Agreement. We may, but shall
            not be bound to, act upon notices and instructions given by you via
            e-mail, letter, telephone or any other means as we may deem fit.
          </li>
          <li>
            In addition, we may (but shall not be bound to) also publish notices
            of general nature, which are applicable to all Customers in a
            newspaper or on its website including the GMT app or website. Such
            notices will have the same effect as a notice served individually to
            each Visitor, User or Customer (including you).
          </li>
          <li>
            Documents which may be sent by electronic communication between you
            and us may be in the form of an electronic mail, an electronic mail
            attachment, or in the form of an available download from the GMT app
            or website. We shall be deemed to have duly communicated and
            delivered any communication or document to you if such communication
            or document is sent via electronic mail (e-mail) to the registered
            e-mail address. We shall also be entitled to act on the basis of any
            instructions received or purported to be received by us from you by
            e-mail or other electronic means or via the internet. We shall also
            be entitled (but not bound) to act upon fax instructions and
            communications.
          </li>
        </ol>
        <p>
          <strong>Contact Us:</strong>
        </p>
        <p>
          <strong>Golden Money Transfer</strong>
        </p>
        <p>
          739 Fourth Ave #204, San Diego, CA 92101
          <br />
          Tel: 1-888-702-5656
          <br />
          Email:
          <a href="mailto:info@gmtnorthamerica.com">info@gmtnorthamerica.com</a>
        </p>
        <p>
          <strong>STATE REGULATORS AND STATE SPECIFIC INFORMATION</strong>
        </p>
        <p>
          <strong>CALIFORNIA</strong>
          <br /> If you have complaints with respect to any aspect of the money
          transmission activities&nbsp; conducted at a Golden Money Transfer,
          Inc. location or its Affiliates, you may contact the California
          Department of Business Oversight at its toll-free telephone number,
          1-866-275-2677, by email at&nbsp;ask.dfpi@dfpi.ca.gov&nbsp;or by mail
          at the Department of Financial Protection and Innovation Consumer
          Services, 2101 Arena Boulevard, Sacramento, CA 95834
        </p>
        <p>
          <strong>RIGHT TO REFUND</strong>
        </p>
        <p>
          You, the customer, are entitled to a refund of the money to be
          transmitted as the result of this agreement if Golden Money Transfer,
          Inc. does not forward the money received from you within 10 days of
          the date of its receipt, or does not give instructions committing an
          equivalent amount of money to the person designated by you within 10
          days of the date of receipt of funds from you unless otherwise
          instructed by you.
          <br /> If your instructions as to when the money shall be forwarded or
          transmitted are not complied with and the money has not yet been
          forwarded or transmitted, you have a right to a refund of your money.
          <br /> If you want a refund, you must mail or deliver your written
          request to: Refunds/Complaints Golden Money Transfer, Inc. 739 Fourth
          Ave #204, San Diego, CA&nbsp; 92101. If you do not receive your
          refund, you may be entitled to your money back plus a penalty of up to
          $1,000 and attorney&rsquo;s fees pursuant to Section 2102 of the
          California Financial Code.
        </p>
        <p>
          <strong>FLORIDA</strong>
          <br /> Golden Money Transfer, Inc. is a licensed money transmitter
          under Chapter 560, Florida Statutes. For suspected violations of
          Chapter 560, Florida Statutes, call Golden Money Transfer, Inc. at
          1-888-702-5656 or contact the Florida Office of Financial Regulation,
          200 East Gaines Street, Tallahassee, FL 32399-0376, (850) 487-9687.
          <br /> <br /> <strong>ILLINOIS</strong>
          <br /> The Illinois Division of Banking will accept complaints at
          888-473-4858, or by mail at: 320 West Washington Street, Springfield,
          Illinois 62786.
        </p>
        
       <div className="tc_wrapper">
       <table width="100%" className="table tc">
          <tbody>
            <tr>
              <td width="129">
                <p>
                  <strong>STATE</strong>
                </p>
              </td>
              <td width="483">
                <p>
                  <strong>CONTACT INFORMATION</strong>
                </p>
              </td>
            </tr>
            <tr>
              <td width="129">
                <p>
                  <strong>Alabama</strong>
                </p>
              </td>
              <td width="483">
                <p>
                  <a href="https://asc.alabama.gov/Registration%20Filing%20Req/soc7a_revised_filing_req.aspx">
                    https://asc.alabama.gov/Registration%20Filing%20Req/soc7a_revised_filing_req.aspx
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="129">
                <p>
                  <strong>Alaska</strong>
                </p>
              </td>
              <td width="483">
                <p>Division of Banking and Securities PO Box 110807</p>
                <p>Juneau, AK 99811-0807</p>
                <p>Telephone:907-465-2521/ 1-888-925-2521</p>
                <p>
                  <strong>Email: </strong>
                  <a href="mailto:dbsc@alaska.gov">
                    <strong>dbsc@alaska.gov</strong>
                  </a>
                </p>
                <p>
                  For Alaska Residents Only: If your issue is unresolved by
                  TransferWise Inc. (+1 888 908 3833), please submit formal
                  complaints with the State of Alaska, Division of Banking &amp;
                  Securities.
                </p>
                <p>
                  Formal complaints must be in writing, please download the form
                  here:
                  https://www.commerce.alaska.gov/web/portals/3/pub/DBSGeneralComplaintFormupdated.pdf
                </p>
                <p>Formal complaint forms may be submitted via:</p>
                <p>1. Fax: 907-465-1230</p>
                <p>2. Email: msb_licensing@alaska.gov</p>
                <p>
                  3. Mail: Division of Banking &amp; Securities PO Box 110807
                  Juneau, AK 99811-0807
                </p>
                <p>
                  If you have questions regarding formal complaints, please call
                  907-465-2521
                </p>
                <p>
                  https://www.commerce.alaska.gov/web/dbs/ConsumerFinance.aspx
                </p>
              </td>
            </tr>
            <tr>
              <td width="129">
                <p>
                  <strong>Arkansas</strong>
                </p>
              </td>
              <td width="483">
                <p>
                  <strong>Website: </strong>
                  <a href="http://www.securities.arkansas.gov/">
                    <strong>www.securities.arkansas.gov</strong>
                  </a>
                </p>
                <p>http://www.securities.arkansas.gov/</p>
              </td>
            </tr>
            <tr>
              <td width="129">
                <p>
                  <strong>California</strong>
                </p>
              </td>
              <td width="483">
                <p>
                  <a href="https://wise.com/us/state-licenses#california">
                    https://wise.com/us/state-licenses#california
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>Colorado</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  <strong>ADD Consumer NOTICE PDF</strong>
                </p>

                <p>
                  <a href="https://banking.colorado.gov/consumers/file-a-complaint">
                    https://banking.colorado.gov/consumers/file-a-complaint
                  </a>
                </p>
                
                <p>
                  <strong>COLORADO</strong>
                </p>
                <p>
                  If you have a question about or problem with your transaction
                  &ndash; the money you sent
                </p>
                <p>
                  You must contact the Money Transmitter who processed your
                  transaction for assistance. The Division of Banking does not
                  have access to this information.
                </p>
                <p>
                  If you are a Colorado resident and have a complaint about the
                  money transmitter &ndash; the company that sent your money
                </p>
                
                <p>
                  ALL complaints must be submitted in writing. Please fill out
                  the Complaint Form provided on the Colorado Division of
                  Banking&rsquo;s website and return it and any documentation
                  supporting the complaint via mail or email
                  (DORA_BankingWebsite@state.co.us) to the Division of Banking
                  at:
                </p>
                
                <p>Colorado Division of Banking</p>
                <p>1560 Broadway, Suite 975</p>
                <p>Denver, CO 80202</p>
                
                
                
              </td>
            </tr>
            <tr>
              <td width="110">
                
                
                
                <p>
                  <strong>Connecticut</strong>
                </p>
                
              </td>
              <td width="512">
                <p>
                  <a href="http://www.ct.gov/dob/cwp/view.asp?a=2235&amp;q=297974&amp;dobNAV_GID=1659">
                    <strong>
                      http://www.ct.gov/dob/cwp/view.asp?a=2235&amp;q=297974&amp;dobNAV_GID=1659
                    </strong>
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>Delaware</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  <a href="http://www.banking.delaware.gov/">
                    http://www.banking.delaware.gov/
                  </a>
                </p>
                
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>District of Columbia</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  <a href="http://disb.dc.gov/page/check-cashers-sales-finance-companies-retail-sellers-money-lenders-money-transmitters-non-bank">
                    http://disb.dc.gov/page/check-cashers-sales-finance-companies-retail-sellers-money-lenders-money-transmitters-non-bank
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>Florida</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  <a href="http://www.flofr.com/">http://www.flofr.com/</a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>Georgia</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  <a href="https://dbf.georgia.gov/">
                    https://dbf.georgia.gov/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>Idaho</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  <a href="http://www.finance.idaho.gov/">
                    http://www.finance.idaho.gov/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="110">
                <p>
                  <strong>Illinois</strong>
                </p>
              </td>
              <td width="512">
                <p>
                  The Illinois Division of Banking will accept complaints at
                  888-473-4858, or by mail at: 320 West Washington Street,
                  Springfield, Illinois 62786.
                </p>

                <p>
                  <a href="https://www.idfpr.com/Admin/Complaints.asp">
                    https://www.idfpr.com/Admin/Complaints.asp
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Maryland</strong>
                </p>
              </td>
              <td width="505">
                
                <p>
                  <a href="http://www.dllr.state.md.us/finance/consumers/comphow.shtml">
                    http://www.dllr.state.md.us/finance/consumers/comphow.shtml
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Massachusetts</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <u></u>
                  <a href="http://www.mass.gov/ocabr/government/oca-agencies/dob-lp">
                    http://www.mass.gov/ocabr/government/oca-agencies/dob-lp
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Minnesota</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://mn.gov/commerce/">http://mn.gov/commerce/</a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                <p>
                  <strong>&nbsp;Missouri</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="https://finance.mo.gov/consumercredit/moneyorder.php">
                    https://finance.mo.gov/consumercredit/moneyorder.php
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Nevada</strong>
                </p>
              </td>
              <td width="505">
                
                <p>
                  <a href="https://business.nv.gov/">
                    https://business.nv.gov/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                <p>
                  <strong>&nbsp;New </strong>
                </p>
                <p>
                  <strong>Hampshire</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://www.nh.gov/banking/consumer-assistance/complaint.htm">
                    http://www.nh.gov/banking/consumer-assistance/complaint.htm
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                <p>
                  <strong>New Jersey</strong>
                </p>
              </td>
              <td width="505">
                
                <p>
                  <a href="http://www.state.nj.us/dobi">
                    http://www.state.nj.us/dobi
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>New Mexico</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://www.rld.state.nm.us/financialinstitutions/">
                    http://www.rld.state.nm.us/financialinstitutions/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>North Carolina</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="https://www.nccob.org/Public/financialinstitutions/mt/moneytransmittersmain.aspx">
                    https://www.nccob.org/Public/financialinstitutions/mt/moneytransmittersmain.aspx
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>North Dakota</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://www.nd.gov/eforms/Doc/sfn50702.pdf">
                    http://www.nd.gov/eforms/Doc/sfn50702.pdf
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Oregon</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://dfr.oregon.gov/">http://dfr.oregon.gov/</a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                <p>
                  <strong>Rhode Island</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://www.dbr.ri.gov/complaints/">
                    http://www.dbr.ri.gov/complaints/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                <p>&nbsp;&nbsp;</p>
                <p>
                  &nbsp;<strong>South Carolina</strong>
                </p>
              </td>
              <td width="505">
                <p>Office of the Commissioner of Banking</p>
                <p>1205 Pendleton Street, Suite 305</p>
                <p>Columbia, SC 29201</p>
                <p>Telephone: 803-734-2001 Fax: 803-734-2013</p>
                <p>
                  <strong>
                    Website:
                    <a href="https://banking.sc.gov/">
                      https://banking.sc.gov/
                    </a>
                  </strong>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>South Dakota</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://dlr.sd.gov/banking/consumers/consumer_complaint_filing.aspx">
                    http://dlr.sd.gov/banking/consumers/consumer_complaint_filing.aspx
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Tennessee</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://www.tennessee.gov/tdfi/">
                    http://www.tennessee.gov/tdfi/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                
                <p>
                  <strong>Texas</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="https://wise.com/us/state-licenses#texas">
                    https://wise.com/us/state-licenses#texas
                  </a>
                </p>
                <p>
                  <strong>TEXAS CONSUMERS:</strong>&nbsp;Complaints concerning
                  money transmission activities should be directed to: Golden
                  Money Transfer, Inc. 739 Fourth Ave #204, San Diego,
                  California 92101, USA,&nbsp; email at info@gmtnorthamerica.com
                  or call 1-888-702-5656. After first contacting Golden Money
                  Transfer, Inc., if you still have an unresolved complaint
                  regarding the company&rsquo;s money transmission activities,
                  please direct your complaint to: Texas Department of Banking,
                  2601 North Lamar Boulevard, Austin, Texas 78705; Telephone
                  Number: 1-877-276-5554, Fax Number: 1-512-475-1313, e-mail
                  address:&nbsp;
                  <a href="mailto:consumer.complaints@dob.texas.gov">
                    consumer.complaints@dob.texas.gov
                  </a>
                  ; Website Address:&nbsp;
                  <a href="http://www.dob.texas.gov/">www.dob.texas.gov</a>.
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Utah</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://dfi.utah.gov/">http://dfi.utah.gov/</a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Virginia</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="https://www.scc.virginia.gov/bfi/">
                    https://www.scc.virginia.gov/bfi/
                  </a>
                </p>
              </td>
            </tr>
            <tr>
              <td width="119">
                
                <p>
                  <strong>Washington</strong>
                </p>
              </td>
              <td width="505">
                <p>
                  <a href="http://dfi.wa.gov/">http://dfi.wa.gov/</a>
                </p>
              </td>
            </tr>
          </tbody>
        </table>
       </div>
        
        
      </div>
    </div>
  );
}
