import React, { useReducer, useState } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "@mui/material/Container";
import { Stepper, Step, StepLabel } from "@mui/material";
import { Form, Input, notification, Spin, Menu, Dropdown, Button, message } from "antd";
import { TransactionAPI } from "../../../apis/TransactionAPI";
import useHttp from "../../../hooks/useHttp";
import arrow from "../../../assets/images/svg/arrow.svg";

export function TrackTransfer() {
  const [form] = Form.useForm();
  const [loading, setloading] = useState(false);
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    activeStep: 1,
    trackingDetails: [],
  });
  const hookTrackTranscation = useHttp(TransactionAPI.trackTranscationPreLogin);

  const steps = [
    "Transfer Initiated",
    `KCB Mint Received funds in Local Currency`,
    `Currency converted to KES`,
    `KCB Mint has received funds`,
    "Credited to Recipients Bank account",
  ];
  const trackTranscation = (value) => {
    let transactiondata = {
      requestType: "TRACKMYTRANSFER",
      rgtn: value.rgtn,
    };
    setloading(true);
    hookTrackTranscation.sendRequest(transactiondata, function (data) {
      setloading(false);
      if (data.status == "S") {
        setState({ activeStep: 2, trackingDetails: data });
        notification.success({ message: data.message });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  return (
    <div className="d-flex signin bg_gradient mt-md-4 mt-sm-4">
      <Container>
        <Box className="T3_container">
          {state.activeStep === 1 && (
            <>
              <Grid spacing={2}>
                <div className="pt-0 pt-md-4">
                  <h4 className="mb-4">Track Transfer</h4>

                  <div>
                    <Form form={form} onFinish={trackTranscation} autoComplete="off">
                      <div className="mb-3">
                        <label className="form-label">Enter RGTN</label>
                        <Form.Item
                          className="form-item"
                          name="rgtn"
                          rules={[
                            {
                              required: true,
                              message: "Please input rgtn.",
                            },
                            {
                              min: 14,
                              max: 14,
                              message: "Please enter 14 digit rgtn",
                            },
                          ]}
                        >
                          <Input
                            disabled={loading}
                            className="input"
                            size="large"
                            autoComplete="off"
                          />
                        </Form.Item>
                      </div>

                      <div className="d-grid g-2">
                        <Spin spinning={loading} style={{ width: "297px" }}>
                          <button className="cont-button" type="submit">
                            Continue
                            <img src={arrow}></img>
                          </button>
                        </Spin>
                      </div>
                    </Form>
                  </div>
                </div>
              </Grid>
            </>
          )}
          {state.activeStep === 2 && (
            <div className="container track-container bg_gradient mt-md-5 mt-sm-5">
              <div className="T3_container">
                <h4 className="title">Transaction Booked</h4>
                <h5 className="sub-title">
                  Your transaction has been successfully booked. Please proceed to make payment to
                  confirm transaction within the next
                  <br /> 24 hours.
                </h5>
                <section className="my-5">
                  <h5>Tracking ID - {state.trackingDetails.txnRefNo} </h5>
                </section>

                <section className="track-stepper">
                  <Stepper orientation="vertical" activeStep={state.trackingDetails.pictograph}>
                    {steps.map((label) => (
                      <Step key={label}>
                        <StepLabel>{label}</StepLabel>
                      </Step>
                    ))}
                  </Stepper>
                </section>
                <ht />
              </div>
            </div>
          )}
        </Box>
      </Container>
    </div>
  );
}
