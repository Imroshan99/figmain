import React, { useState, useEffect, useReducer } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "react-bootstrap/Container";
import { Link, useNavigate } from "react-router-dom";
import { Form, Input, Select, notification, Spin } from "antd";
import moment from "moment";
import { AuthAPI } from "../../../apis/AuthAPI";
import { GuestAPI } from "../../../apis/GuestAPI";
import OTPBox from "../../../containers/OTPBox";
import ExchangeRate from "../../../containers/ExchangeRate";
import { config } from "../../../config";
import SetPassword from "./SetPassword";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";

import Tab from "@mui/material/Tab";
import TabContext from "@mui/lab/TabContext";
import TabList from "@mui/lab/TabList";
import TabPanel from "@mui/lab/TabPanel";
import { Stack } from "@mui/material";
import SetNewPassword from "./SetNewPassword";
import useHttp from "../../../hooks/useHttp";

const { Option } = Select;
export default function ForgotPassword(props) {
  let navigate = useNavigate();

  const ConfigReducer = useSelector((state) => state);

  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [isSelectMarketingCommunication, setisSelectMarketingCommunication] =
    useState("N");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      // twofa: ConfigReducer.twofa,
      twofa: "Y",
      sessionId: ConfigReducer.sessionId,
      formData: {},
      _isShowOTPBOX: false,
      _isShowSuccessMessage: false,
      otpType: "FP",
      activeTab: "1",
    }
  );

  const hookForgotPassword = useHttp(AuthAPI.forgotPassword);

  useEffect(() => {
    // alert(state.activeTab)
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const onCreateLead = (value) => {
    let forgotPasswordPayload = {
      requestType: "FORGOTPASSWORD",
      loginId: value.loginId,
      dob: "",
      verifyType: value.verifyType,
    };

    setLoader(true);
    hookForgotPassword.sendRequest(forgotPasswordPayload, (res) => {
      if (res.status == "S") {
        if (value.verifyType === "O") {
          setState({ verificationToken: res.verificationToken });
          if (state.twofa == "N") {
            setState({
              isModalVisible: true,
              formData: value,
            });
          } else {
            setState({
              _isShowOTPBOX: true,
              isModalVisible: true,
              formData: value,
            });
          }
        }
        if (value.verifyType === "L") {
          notification.success({ message: res.message });
          navigate("/signin");
        }
      } else {
        setLoader(false);
        notification.error({ message: res.errorMessage });

        let errors = [];
        res.data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) {
          if (value.verifyType === "O") {
            form.setFields(errors);
          }
          if (value.verifyType === "L") {
            form1.setFields(errors);
          }
        }
      }
      setLoader(false);
    });
  };

  const handleTabChange = (event, newValue) => {
    setState({ activeTab: newValue });
  };

  return (
    <div className="ForgotPassword bg_gradient container mt-md-5 mt-sm-5">
      <div className="T3_container">
        {state._isShowOTPBOX && (
          <OTPBox
            state={state}
            setState={setState}
            otpType={state.otpType}
            useFor="forgot_password"
            appState={props.appState}
          />
        )}
        <Box>
          <Grid container spacing={{ xs: 2, md: 4 }}>
            {state._isShowSuccessMessage == false ? (
              <div className="card pt-4">
                <Spin spinning={loading} delay={500}>
                  <Grid item lg={12} xl={12} className="my-auto mx-auto">
                    <div className="d-block justify-content-center">
                      <Box
                      // className="p-3 pt-sm-4 pb-sm-5 px-sm-5"
                      // sx={{
                      //   bgcolor: "background.paper",
                      //   width: "100%",
                      //   typography: "body1",
                      // }}
                      >
                        <TabContext value={state.activeTab}>
                          {/* <Box
                              sx={{ borderBottom: 1, borderColor: "divider" }}
                            >
                              <TabList
                                onChange={handleTabChange}
                                value={state.activeTab}
                                variant="fullWidth"
                                aria-label="full width tabs example"
                                className="money-tabs"
                              >
                                <Tab
                                  label="Reset Using OTP"
                                  value="1"
                                  className="money-tab-links"
                                />
                                <Tab
                                  label="Using User ID"
                                  value="2"
                                  className="money-tab-links"
                                />
                              </TabList>
                            </Box> */}
                          {/* <TabPanel value="1">
                              <Box> */}
                          <Form
                            form={form}
                            initialValues={{ verifyType: "O" }}
                            onFinish={onCreateLead}
                          >
                            <div className="p-3 pt-sm-4 pb-sm-5 px-sm-5">
                              <h4 className="title"> Forgot Password?</h4>
                              <hr />
                              <p className="text-center">
                                A 6 digit OTP will be sent to your registered
                                email id
                              </p>
                              <Grid container spacing={2}>
                                <Grid item xs={12}>
                                  <div className="">
                                    <label className="form-label">
                                      Enter User ID
                                    </label>
                                    <Form.Item
                                      className="form-item"
                                      name="loginId"
                                      rules={[
                                        {
                                          required: true,
                                          message: "Please enter User ID",
                                        },
                                      ]}
                                    >
                                      <Input size="large" />
                                    </Form.Item>
                                  </div>
                                </Grid>
                              </Grid>

                              <div className="d-grid">
                                <Form.Item name="verifyType" hidden={true}>
                                  <Input type={"hidden"} />
                                </Form.Item>

                                <button className="btn btn-primary text-white">
                                  {state.twofa == "Y"
                                    ? "Verify With OTP"
                                    : "Verify Without OTP"}
                                </button>
                              </div>
                            </div>
                          </Form>
                          {/* </Box>
                            </TabPanel>
                            <TabPanel value="2">
                              <Box>
                                <Stack fullWidth>
                                  <Box>
                                    <Form
                                      form={form1}
                                      initialValues={{ verifyType: "L" }}
                                      onFinish={onCreateLead}
                                    >
                                      <div className="rounded p-3 pt-sm-4 pb-sm-5 px-sm-4">
                                        <p className="text-center">
                                          A reset password link will be sent to
                                          your registered Email
                                        </p>
                                        <Grid container spacing={2}>
                                          <Grid item xs={12}>
                                            <div className="">
                                              <label className="form-label">
                                                Enter User ID
                                              </label>
                                              <Form.Item
                                                className="form-item"
                                                name="loginId"
                                                rules={[
                                                  {
                                                    required: true,
                                                    message:
                                                      "Please enter user id",
                                                  },
                                                ]}
                                              >
                                                <Input size="large" />
                                              </Form.Item>
                                            </div>
                                          </Grid>
                                        </Grid>

                                        <div className="d-grid">
                                          <Form.Item
                                            name="verifyType"
                                            hidden={true}
                                          >
                                            <Input type={"hidden"} />
                                          </Form.Item>

                                          <button className="btn btn-primary text-white">
                                            {state.twofa == "Y"
                                              ? "Verify With OTP"
                                              : "Verify Without OTP"}
                                          </button>
                                        </div>
                                      </div>
                                    </Form>
                                  </Box>
                                </Stack>
                              </Box>
                            </TabPanel> */}
                        </TabContext>
                      </Box>
                    </div>
                  </Grid>

                  <Grid item lg={6} xl={5} className="my-auto mx-auto">
                    <div className="d-block justify-content-center">
                      <Box
                        className="rounded-5"
                        sx={{
                          bgcolor: "background.paper",
                          width: "100%",
                          typography: "body1",
                        }}
                      ></Box>
                    </div>
                  </Grid>
                </Spin>
              </div>
            ) : (
              <div>
                <SetNewPassword
                  state={state}
                  setState={setState}
                  appState={props.appState}
                />
              </div>
            )}
          </Grid>
        </Box>
      </div>
      {/* ======== modal : OTP ============ */}
    </div>
  );
}
