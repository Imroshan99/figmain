import React, { Fragment } from "react";
import PageNotFound from "./pages/PageNotFound";
import Dashboard from "./user/Dashboard";
import SignUp from "./auth/SignUp";
import SignIn from "./auth/SignIn";
import Header from "./layout/Header";
import AddRecipient from "./user/recipient/AddRecipient";
import EditRecipient from "./user/recipient/EditRecipient";
import RecipientList from "./user/recipient/RecipientList";
import Profile from "./user/profile/Profile";
import TranctionAction from "./user/sendmoney/TranctionAction";
import TransactionList from "./user/sendmoney/TransactionList";
import BankAccountList from "./user/bankaccounts/ACH/BankAccountList";
import AddBankAccount from "./user/bankaccounts/ACH/RegularForm/AddBankAccount";
import AddBankAccountCIP from "./user/bankaccounts/CIP/AddBankAccount";
import BankAccountListCIP from "./user/bankaccounts/CIP/BankAccountList";
import RepeatTranscation from "./user/sendmoney/RepeatTransaction";
// import BankAccountList from './user/bankaccounts/BankAccountList';
// import AddBankAccount from './user/bankaccounts/AddBankAccount';
import ThankYou from "./user/sendmoney/ThankYou";
import BankThankYou from "./user/sendmoney/BankThankYou";
import ProfileSetup from "./user/profile/ProfileSetup";
import TrackMoneyTransfer from "./user/sendmoney/TrackMoneyTransfer";
import JumioPage from "./user/profile/JumioPage";
import ChangePassword from "./user/profile/ChangePassword";
import Notification from "./user/Notification";
import ForgotUserID from "./auth/ForgotUserID";
import ForgotPassword from "./auth/ForgotPassword";
import UnlockUserid from "./auth/UnlockUserid";
import RateAlert from "./user/rate_alert/RateAlert";
import ThankYouScheduleTransaction from "./user/sendmoney/ThankYouScheduleTransaction";
import { Helmet } from "react-helmet";
import { PublicRoute } from "./../../Routes/PublicRoute";
import SingleSignUpForm from "./auth/SingleSignUpForm";
import KycPage from "./auth/KYC";
import RecipientRequestList from "./user/recipient/RecipientRequestList";
import { Route, Router, Routes, useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import UnlockAccount from "./auth/UnlockAccount";
import remit from "../../services/remit";
import HomePage from "../../pages/LandingPage/index";

const RequestMoney = React.lazy(() => import("./pages/request-money"));

export default function TemplateOne({ state, manageRefreshToken, manageAuth }) {
  const location = useLocation();
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const defaultSettings = ConfigReducer.groupIdSettings.default;
  const _title = useSelector((state) => state.groupIdSettings.title);
  // console.log("location.path", location.pathname);
  let HeaderNew;
  if (location.pathname === "/") {
    if (AuthReducer.groupId === "KCB" || AuthReducer.groupId === "MF" || AuthReducer.groupId === "CSB") {
      HeaderNew = (
        <Header appState={state} manageRefreshToken={manageRefreshToken} />
      );
    }
  } else {
    HeaderNew = (
      <Header appState={state} manageRefreshToken={manageRefreshToken} />
    );
  }

  return (
    <div>
      <Helmet>
        <title>{_title}</title>
        <link
          rel="icon"
          type="image/png"
          sizes="16x16"
          href={require(`./../../assets/images/fav_icons/${
            AuthReducer.groupId + "_logo.ico"
          }`)}
        />
      </Helmet>

      {HeaderNew}
      <Routes>
        <Route
          path="/request-money"
          element={<RequestMoney appState={state} manageAuth={manageAuth} />}
        />

        <Route
          path="/signin"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <SignIn appState={state} manageAuth={manageAuth} />
            </PublicRoute>
          }
        />
        <Route
          path="/signup"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              {AuthReducer.groupIdSettings.signUpForm.formType === "REGULAR" ? (
                <SingleSignUpForm appState={state} manageAuth={manageAuth} />
              ) : (
                <SignUp appState={state} manageAuth={manageAuth} />
              )}
            </PublicRoute>
          }
        />

        <Route
          path="/forgot-userid"
          element={<ForgotUserID appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/forgot-password"
          element={<ForgotPassword appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/unlock-userid"
          element={<UnlockUserid appState={state} manageAuth={manageAuth} />}
        />
        <Route
          path="/unlock-account"
          element={<UnlockAccount appState={state} manageAuth={manageAuth} />}
        />
        <Route
          exact
          path="/"
          element={
            <PublicRoute auth={{ isLoggedIn: state.isLoggedIn }}>
              <HomePage appState={state} />
            </PublicRoute>
          }
        />

        <Route path="*" element={<PageNotFound appState={state} />} />
        {/* <Route path="*" element={<HomePage appState={state} />} /> */}
        {/* <Route path="/track-money-transfer" element={<TrackMoneyTransfer appState={state} />} /> */}
        <Route
          path="/ThankYouScheduleTransaction"
          element={
            <ThankYouScheduleTransaction
              appState={state}
              manageRefreshToken={manageRefreshToken}
            />
          }
        />

        {state.isLoggedIn && (
          <Fragment>
            <Route
              path="/dashboard"
              element={
                <Dashboard
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />

            <Route
              path="/kyc"
              element={
                <KycPage
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/change-password"
              element={
                <ChangePassword
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/profile"
              element={
                <Profile
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            {/* <Route path="/my-bank-accounts" element={<BankAccountList appState={state} manageRefreshToken={manageRefreshToken} />} /> */}
            <Route
              path="/my-bank-accounts"
              element={
                defaultSettings.sendModeCode === "ACH" ? (
                  <BankAccountList
                    appState={state}
                    manageRefreshToken={manageRefreshToken}
                  />
                ) : (
                  <BankAccountListCIP />
                )
              }
            />
            <Route
              path="/add-bank-account"
              element={
                defaultSettings.sendModeCode === "ACH" ? (
                  <AddBankAccount
                    appState={state}
                    manageRefreshToken={manageRefreshToken}
                  />
                ) : (
                  <AddBankAccountCIP />
                )
              }
            />
            <Route
              path="/my-recipient"
              element={
                <RecipientList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/recipient-request-list"
              element={
                <RecipientRequestList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/add-recipient"
              element={
                <AddRecipient
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/edit-recipient"
              element={
                <EditRecipient
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/new-transaction"
              element={
                <TranctionAction
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/repeat-transaction"
              element={
                <RepeatTranscation
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/transaction-list"
              element={
                <TransactionList
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/track-money-transfer"
              element={
                <TrackMoneyTransfer
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/jumio-page"
              element={
                <JumioPage
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />

            <Route path="/thankYou" element={<ThankYou appState={state} />} />
            <Route
              path="/bankThankYou"
              element={<BankThankYou appState={state} />}
            />
            <Route
              path="/profile-setup"
              element={<ProfileSetup appState={state} />}
            />

            <Route
              path="/rate-alert"
              element={
                <RateAlert
                  appState={state}
                  manageRefreshToken={manageRefreshToken}
                />
              }
            />
            <Route
              path="/notification-list"
              element={<Notification appState={state} />}
            />
          </Fragment>
        )}
      </Routes>
    </div>
  );
}
