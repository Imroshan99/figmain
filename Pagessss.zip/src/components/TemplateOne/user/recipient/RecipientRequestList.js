import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Form, Input, Tabs, Select, notification, Spin, Table } from "antd";
import { DeleteOutlined, EditOutlined } from "@ant-design/icons";
import { Link, useNavigate } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import Swal from "sweetalert2";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import RecipientInfo from "./RecipientInfo";
import useHttp from "../../../../hooks/useHttp";
import moment from "moment";
import CheckCircleIcon from "@mui/icons-material/CheckCircle";
import CancelIcon from "@mui/icons-material/Cancel";
import RecipientRequestNickNameForm from "./RecipientRequestNickNameForm";

function RecipientRequestList(props) {
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const navigate = useNavigate();
  // console.log(ConfigReducer)
  const recipientListConfig =
    ConfigReducer.groupIdSettings.recipientModule.recipientList;
  const [loading, setLoader] = useState(false);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      recipientRequestLists: [],
      userID: AuthReducer.userID,
    }
  );

  const hookRecipientRequestLists = useHttp(ReceiverAPI.recipientRequestLists);
  const hookRecipientRequestApprove = useHttp(
    ReceiverAPI.recipientRequestApprove
  );

  useEffect(async () => {
    if (props.appState.isLoggedIn) {
      recipientRequestListsHandler();
    }
  }, []);

  const recipientRequestListsHandler = () => {
    const payload = {
      requestType: "RECREQLIST",
      userId: AuthReducer.userID,
      startIndex: "0",
      recordsPerRequest: "",
      search: "",
      statusFlag: "",
      favouriteFlag: "",
    };
    hookRecipientRequestLists.sendRequest(payload, (res) => {
      if (res.status === "S") {
        setState({
          recipientRequestLists: res.responseData,
        });
      } else {
        setState({
          recipientRequestLists: [],
        });
      }
    });
  };

  const onNickNameChangeHandler = (nickNameData, recordToken) => {
    // console.log(e, recordToken);
    const __recipientRequestLists = [...state.recipientRequestLists];
    const recordIndex = __recipientRequestLists.findIndex(
      (item) => item.recordToken === recordToken
    );
    __recipientRequestLists[recordIndex].nickName = nickNameData;
    console.log("a", __recipientRequestLists);
    setState({
      recipientRequestLists: __recipientRequestLists,
    });
  };

  const recipientRequestApproveHandler = (record, flag) => {
    // console.log("table record : ", record.nickName);
    setLoader(true);
    const newNickName = record.nickName;
    const payload = {
      requestType: "RECREQAPPROVE",
      userId: AuthReducer.userID,
      rmId: record.rmId,
      aprroveFlag: flag,
      recordToken: record.recordToken,
      nickName: newNickName,
    };
    hookRecipientRequestApprove.sendRequest(payload, (res) => {
      console.log(res);
      if (res.status === "S") {
        notification.success({ message: res.message });
        if (flag === "Y") {
          navigate("/new-transaction", {
            state: { fromPage: "RECIPIENT_REQUEST_LIST", sendAmount: record.sendAmount },
          });
        } else {
          recipientRequestListsHandler();
        }

        setLoader(false);
      }
    });
    // console.log('record state : ', state.recipientRequestLists);
  };

  return (
    <Fragment>
      <div className="p-2 inner_title_wrapper">
        <div className="container">
          <h2 className="mb-0 inner_title">
            Manage Recipients Request
            {/* {state.recipientRequestLists.length}{" "}
            {state.recipientRequestLists[3].nickName} */}
          </h2>
        </div>
      </div>
      <Spin spinning={loading} delay={100}>
        <DefaultLayout
          accessToken={props.appState.accessToken}
          isLoggedIn={props.appState.isLoggedIn}
          publicKey={props.appState.publicKey}
        >
          <div className="card p-4 mb-4">
            {
              <Table
                columns={[
                  {
                    title: "Name",
                    dataIndex: "name",
                    render: (text, record, index) => {
                      return `${record.recvFirstName} ${record.recvLastName}`;
                    },
                  },
                  {
                    title: "Nick Name",
                    dataIndex: "nickName",
                    editable: true,
                    // onCell :''

                    render: (text, record, index) => {
                      return (
                        <RecipientRequestNickNameForm
                          key={index}
                          record={record}
                          nickNameHandler={onNickNameChangeHandler}
                        />
                        // <Form.Item
                        //   name="nickName"
                        //   style={{
                        //     margin: 0,
                        //   }}
                        //   //                     validateStatus="error"
                        //   // help="Should be combination of numbers & alphabets"
                        //   rules={[
                        //     {
                        //       required: true,
                        //       message: `Please Input `,
                        //     },
                        //   ]}
                        // >
                        //   <Input
                        //     size="large"
                        //     placeholder="Nick Name"
                        //     defaultValue={record.nickName}
                        //     onChange={(e) =>
                        //       onNickNameChangeHandler(e, record.recordToken)
                        //     }
                        //   />
                        // </Form.Item>
                      );
                    },
                  },
                  {
                    title: "Bank Name",
                    dataIndex: "bankName",
                  },
                  {
                    title: "Account No",
                    dataIndex: "accountNo",
                  },
                  {
                    title: "Bank Code",
                    dataIndex: "bankCode",
                  },
                  {
                    title: "City",
                    dataIndex: "city",
                  },
                  {
                    title: "Registration Date",
                    dataIndex: "registrationDate",
                    render: (text, record, index) => {
                      return moment(record.registrationDate).format(
                        "DD/MM/YYYY HH : mm"
                      );
                    },
                  },
                  {
                    title: `Status `,
                    dataIndex: "status",
                    className: `${
                      recipientListConfig.columns.status == "DISABLED" &&
                      "hide__column"
                    }`,
                  },

                  {
                    title: "",
                    dataIndex: "",
                    key: "y",
                    render: (text, record, index) => {
                      return (
                        <>
                          <span className="px-2">
                            <CheckCircleIcon
                              color="success"
                              i={index}
                              onClick={() =>
                                recipientRequestApproveHandler(record, "Y")
                              }
                            />
                          </span>
                          <span>
                            <CancelIcon
                              color="error"
                              i={index}
                              onClick={() =>
                                recipientRequestApproveHandler(record, "N")
                              }
                            />
                          </span>
                        </>
                      );
                    },
                  },
                ]}
                dataSource={[...state.recipientRequestLists]}
                pagination={false}
              />
            }
          </div>
        </DefaultLayout>
      </Spin>
    </Fragment>
  );
}

export default RecipientRequestList;
