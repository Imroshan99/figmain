import React, { useEffect, useReducer, Fragment } from "react";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { config } from "../../../../config";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { Link } from "react-router-dom";
import { AuthAPI } from "../../../../apis/AuthAPI";
import Swal from "sweetalert2";
import { useNavigate } from 'react-router-dom';
import useHttp from "../../../../hooks/useHttp";

function JumioPage(props) {

  let navigate = useNavigate();
  const AuthReducer = useSelector((state) => state);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      isShowFrame: false,
      jumioRedirectURL: "",
    }
  );

  const hookNetverifyInitiate = useHttp(AuthAPI.netverifyInitiate);
  const hookNetverifyResponse = useHttp(AuthAPI.netverifyResponse);

  useEffect(() => {
    if (state.isShowFrame) {
      window.addEventListener("message", receiveMessage, false);
    }
  }, [state.isShowFrame]);

  function receiveMessage(event) {
    console.log("Event ", event)
    var data = window.JSON.parse(event.data);
    // console.log("ID Verification Web was loaded in an iframe.");
    // console.log("auth-token:", data.authorizationToken);
    // console.log("event-type:", data.eventType);
    // console.log("date-time:", data.dateTime);
    // console.log("workflow-execution-id:", data.workflowExecutionId);
    // console.log("account-id:", data.accountId);
    // console.log("customer-internal-reference:", data.customerInternalReference);
    // console.log("value:", data.payload.value);
    // console.log("metainfo:", data.payload.metainfo);

    if (data.payload.value == 'success') {
      (async() => {
        const netVerifyResponseObj = {
          transactionStatus : data.payload.value,
          customerInternalReference : data.customerInternalReference,
          transactionReference : data.transactionReference
        }
       await netverifyResponse(netVerifyResponseObj);
      })()

      
    }
  }

  const onClickJumioVerify = () => {
    let payload = {
      requestType: "NETVERIFYINITIATE",      
      errorUrl: config.JUMIO_RETURN_URL,
      successUrl: config.JUMIO_RETURN_URL,
      userId: state.userID,
    };

    hookNetverifyInitiate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        Swal.fire({
          title: "Alert",
          text: "Changes you made may not be saved.",
          icon: "warning",
          showCancelButton: true,
          denyButtonText: `Cancel`,
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            setState({
              isShowFrame: true,
              jumioRedirectURL: data.redirectUrl,
            });
          }
        });
      }
    });
  };

  const netverifyResponse = async (netData) => {
    let payload = {
      requestType: "NETVERIFYAUTH",     
      ipAddress: "103.173.120.139",
      netverifyResponse: window.btoa(JSON.stringify(netData)),
      userId: state.userID
    }

    hookNetverifyResponse.sendRequest(payload, function (data) {
      if (data.status == "S") {
        Swal.fire({
          title: "Success",
          text: "You have been uploaded document successfully.",
          icon: "success",
          showCancelButton: true,
          denyButtonText: `Cancel`,
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            navigate('/profile')
          }
        });
        // netverifyCallbackResponse(decodeData);
      }
    });
  };

  // const netverifyCallbackResponse = (netResData) => {
  //   let data = {
  //     requestId: config.requestId,
  //     requestType: "NETVERIFYCALLBACKRESP",
  //     channelId: config.channelId,
  //     clientId: state.clientId,
  //     groupId: state.groupId,
  //     sessionId: state.sessionId,
  //     ipAddress: "127.0.0.1",
  //     netverifyResponse: window.btoa(JSON.stringify(netResData)),
  //     userId: state.userID
  //   }

  //   if (config.IS_ENC) {
  //     var key = config.key;
  //     var iv = config.iv;
  //     var body = encrypt(data, key, iv);
  //     var pubValue = iv.concat(key);
  //     var identifier = publickey(props.appState.publicKey, pubValue);

  //     var postData = {
  //       body: body,
  //       identifier: identifier,
  //     };
  //   } else {
  //     var postData = data;
  //   }

  //   AuthAPI.netverifyCallbackResponse(postData, props.appState.accessToken)
  //     .then((res) => {
  //       if (config.IS_ENC) {
  //         var decode = decrypt(res.data.body, key, iv);
  //         var decodeData = JSON.parse(decode);
  //       } else {
  //         var decodeData = res.data;
  //       }
  //       if (decodeData.status == "S") {
  //         userRiskProfile();
  //       }
  //       console.log("netverifyCallbackResponse", decodeData);
  //     })
  //     .catch((error) => {
  //       console.log(error);
  //     });
  // };

  // const userRiskProfile = () => {

  //   const userRiskProfileData = {
  //     requestId: config.requestId,
  //     requestType: "RISKPROFILE",
  //     channelId: config.channelId,
  //     clientId: state.clientId,
  //     groupId: state.groupId,
  //     sessionId: state.sessionId,
  //     ipAddress: "127.0.0.1",
  //     userId: state.userID
  //   }

  //   if (config.IS_ENC) {
  //     var key = config.key;
  //     var iv = config.iv;
  //     var body = encrypt(userRiskProfileData, key, iv);
  //     var pubValue = iv.concat(key);
  //     var identifier = publickey(props.appState.publicKey, pubValue);

  //     var postData = {
  //       body: body,
  //       identifier: identifier
  //     }
  //   } else {
  //     var postData = userRiskProfileData;
  //   }

  //   ProfileAPI.userRiskProfile(postData, props.appState.accessToken)
  //     .then(res => {
  //       if (config.IS_ENC) {
  //         var decode = decrypt(res.data.body, key, iv);
  //         var decodeData = JSON.parse(decode);
  //       } else {
  //         var decodeData = res.data;
  //       }

  //       if (decodeData.status == "S") {
  //         console.log('userRiskProfile', decodeData)
  //       }
  //     }).catch(error => {
  //       console.log(error)
  //     })
  // }

  return (
    <Fragment>
      <div className="p-2 bg-secondary">
        <h2 className="mb-0 text-white">Profile Verification</h2>
      </div>
      <div className="mt-4" style={{ backgroundColor: "#f1f5f6" }}>
        <DefaultLayout
          accessToken={props.appState.accessToken}
          isLoggedIn={props.appState.isLoggedIn}
          publicKey={props.appState.publicKey}
        >
          <div className="bg-white shadow-sm rounded p-4">
            {!state.isShowFrame && (<div>
              <div>
                <p>
                  You will now be redirected to a third party site for your
                  online verification process.
                </p>
                <p>
                  Please keep one of the documents listed below handy. Ensure
                  that your device camera is working properly and you are seated
                  in a well lit area.
                </p>
                <ul>
                  <li>Passport (UK or India)</li>
                  <li>UK Driving License</li>
                </ul>
              </div>
              <div className="d-block justify-content-center">
                <button
                  onClick={onClickJumioVerify}
                  className="btn btn-primary btn-sm text-white px-4"
                >
                  Verify Now
                </button>
                <Link
                  to="/profile"
                  className="btn btn-primary btn-sm text-white px-4"
                >
                  Update Profile
                </Link>
              </div>
            </div>)}

            {state.isShowFrame && (
              <iframe
                src={state.jumioRedirectURL}
                width="100%"
                height="800px"
                allow="camera;fullscreen;accelerometer;gyroscope;magnetometer"
                allowfullscreen
              ></iframe>
            )}
          </div>
        </DefaultLayout>
      </div>
    </Fragment>
  );
}

export default JumioPage;
