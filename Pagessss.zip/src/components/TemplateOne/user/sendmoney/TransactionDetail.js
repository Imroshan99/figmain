import React, { useState, useEffect } from "react";
import {
  Form,
  Select,
  Row,
  Col,
  Modal,
  Radio,
  Checkbox,
  Space,
  notification,
  DatePicker,
} from "antd";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { config } from "../../../../config";
import moment from "moment";
import useHttp from "../../../../hooks/useHttp";

const { Option } = Select;

export default function TransactionDetail(props) {
  const [form1] = Form.useForm();
  const [form2] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [isModalVisible, setIsModalVisible] = useState(false);
  const [isShowSubPurpose, setIsShowSubPurpose] = useState(false);

  const hookSubPurposeLists = useHttp(TransactionAPI.subPurposeLists);
  const hookAddPurposeDeclaration = useHttp(
    TransactionAPI.addPurposeDeclaration
  );

  useEffect(() => {
    form1.setFieldsValue({
      purpose: props.state.purposeName,
      sourse: props.state.sourceOfFund,
    });
  }, []);

  const handleChangePurpose = (purpose) => {
    let pur = JSON.parse(purpose);
    props.setState({ purposeName: pur.displayName, purposeID: pur.purposeId });
    if (pur.isDeclarationReq == "Y") {
      setIsModalVisible(true);
      setIsShowSubPurpose(false);
    } else {
      const payload = {
        requestType: "SubPurposeList",
        keyword: "",
        nickName: "175356",
        purposeId: pur.purposeId,
        recvCountryCode: "IN",
        userId: props.state.userID,
      };

      hookSubPurposeLists.sendRequest(payload, function (data) {
        if (data.status == "S") {
          props.setState({ subPurposeLists: data.responseData });
        }
      });
    }
  };

  const handleChangeSubPurpose = (subpurpose) => {
    let pur = JSON.parse(subpurpose);
    props.setState({
      subPurposeName: pur.displayName,
      subPurposeID: pur.subPurposeId,
    });
  };

  const handleChangeSourse = (sourse) => {
    console.log("my s ka value", sourse);
    let s = JSON.parse(sourse);
    props.setState({
      sourceFundId: s.sourceFundId,
      sourceOfFund: s.sourceOfFund,
    });
  };

  const onFinishBookTransaction = () => {
    props.setState({
      isStep: 4,
      pageName: "TXNREVIEW",
    });

    setTimeout(() => {
      props.onCallComputeExchangeRates(
        "TXNREVIEW",
        props.state.isDenefit,
        props.state.promoCode,
        props.state.sendAmount
      );
    }, 500);
  };

  const onFinishDeclartion = (value) => {
    const payload = {
      requestType: "ADDPURPOSEDECLARATION",
      borrower: "",
      declarationDate: "2022-01-25",
      immovableProperty: value.immovableProperty,
      isDeclarationChk: "Y",
      isImmovablePropertyChk: "Y",
      isLoanConfirm: "",
      isNRIAccount: value.isNRIAccount,
      purposeId: props.state.purposeID,
      rgtn: "",
      ulid: "128676",
      userId: props.state.userID,
    };

    hookAddPurposeDeclaration.sendRequest(payload, function (data) {
      if (data.status == "S") {
        // setState({ subPurposeLists: data.responseData })
        notification.success({ message: data.message });
        setIsModalVisible(false);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  return (
    <div>
      <Form form={form1} onFinish={onFinishBookTransaction}>
        <div className="row">
          <div className="col-12 col-md-4">
            <label className="form-label">Purpose For Transfer</label>
            <br />
            <Form.Item
              className="form-item"
              name="purpose"
              rules={[
                { required: true, message: "Please select your purpose." },
              ]}
            >
              <Select
                className="w-100"
                onChange={handleChangePurpose}
                placeholder="Purpose For Transfer"
              >
                {props.state.purposeLists.map((purpose, i) => {
                  return (
                    <Option key={i} value={JSON.stringify(purpose)}>
                      {purpose.displayName}
                    </Option>
                  );
                })}
              </Select>
            </Form.Item>
          </div>
        </div>

        {isShowSubPurpose && (
          <div className="row">
            <div className="col-12 col-md-4">
              <label className="form-label">Sub Purpose For Transfer</label>
              <br />
              <Form.Item
                className="form-item"
                name="subPurpose"
                rules={[
                  {
                    required: true,
                    message: "Please select your sub purpose.",
                  },
                ]}
              >
                <Select
                  className="w-100"
                  onChange={handleChangeSubPurpose}
                  placeholder="Sub Purpose For Transfer"
                >
                  {props.state.subPurposeLists.map((purpose, i) => {
                    return (
                      <Option key={i} value={JSON.stringify(purpose)}>
                        {purpose.displayName}
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            </div>
          </div>
        )}

        {props.state.isSelectedBankTransfer && (
          <div className="row">
            <div className="col-12 col-md-4">
              <label className="form-label">Select Sourse of Fund</label>
              <br />
              <Form.Item
                className="form-item"
                name="sourse"
                rules={[
                  { required: true, message: "Please select your sourse." },
                ]}
              >
                <Select
                  className="w-100"
                  onChange={handleChangeSourse}
                  placeholder="Select source"
                >
                  {props.state.sourceOFFundLists.map((sList, i) => {
                    return (
                      <Option key={i} value={JSON.stringify(sList)}>
                        {sList.sourceOfFund}
                      </Option>
                    );
                  })}
                </Select>
              </Form.Item>
            </div>
          </div>
        )}

        {props.state.groupId == "ICA" && props.state.isSelectedBankTransfer && (
          <>
            <Row justify="space-between">
              <Col span={10} className="py-2">
                <Form.Item
                  className="form-item"
                  name="send_type"
                  rules={[
                    { required: true, message: "Please select schedule type." },
                  ]}
                >
                  <Radio.Group name="scheduleType" value={1}>
                    <Space direction="vertical">
                      <Radio
                        value={1}
                        onClick={() => {
                          props.setState({ _isScheduleTransaction: false });
                        }}
                      >
                        Send Now
                      </Radio>

                      <Radio
                        value={2}
                        onClick={() => {
                          props.setState({ _isScheduleTransaction: true });
                        }}
                      >
                        Send Later
                      </Radio>
                    </Space>
                  </Radio.Group>
                </Form.Item>
              </Col>
            </Row>
            {props.state._isScheduleTransaction == true && (
              <Row justify="space-between">
                <Col span={10} className="py-2">
                  <Form.Item
                    className="form-item"
                    name="estimate_date"
                    rules={[{ required: true, message: "Please select date." }]}
                  >
                    <DatePicker
                      className="w-100"
                      placeholder="Start date"
                      onChange={(value, dateString) => {
                        value !== null
                          ? props.setState({
                              scheduleTransactionDate: dateString,
                            })
                          : props.setState({ scheduleTransactionDate: "" });
                      }}
                    />
                  </Form.Item>
                </Col>
              </Row>
            )}
          </>
        )}

        <div className="d-block">
          <button
            className="btn btn-primary text-white btn-sm my-2"
            onClick={() => props.setState({ isStep: 2 })}
          >
            Back
          </button>
          <button
            htmlType="submit"
            className="btn btn-primary text-white btn-sm mx-2"
          >
            Review{" "}
          </button>
        </div>
      </Form>

      <Modal
        title=""
        visible={isModalVisible}
        onCancel={() => setIsModalVisible(false)}
        footer={false}
      >
        <Form form={form2} onFinish={onFinishDeclartion}>
          <Row>
            <h3>Declaration</h3>
            <div>
              <small>Date</small> <span>21/01/2022</span>
            </div>
            <div>
              <p>I confirm that currently I am:</p>
              <Form.Item
                className="form-item"
                name="isNRIAccount"
                rules={[
                  { required: true, message: "Please select your account." },
                ]}
              >
                <Radio.Group>
                  <Space direction="vertical">
                    <Radio value="Y">
                      a non-resident Indian(NRI) having Indian passport
                    </Radio>
                    <Radio value="N">
                      an Overseas Citizen of India(OCI) under foreign exchange
                      regulations of India
                    </Radio>
                  </Space>
                </Radio.Group>
              </Form.Item>
            </div>

            <div className="my-1">
              <p>
                Type of immovable property proposed to be acquired for which
                remittance is being sent :
              </p>
              <Form.Item
                className="form-item"
                name="immovableProperty"
                rules={[
                  {
                    required: true,
                    message: "Please select your immovable property.",
                  },
                ]}
              >
                <Radio.Group>
                  <Space direction="vertical">
                    <Radio value="R">Residential</Radio>
                    <Radio value="C">Commercial</Radio>
                  </Space>
                </Radio.Group>
              </Form.Item>
            </div>

            <div className="my-1">
              <Form.Item
                className="form-item"
                name="isImmovablePropertyChk"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error(
                              "Please select your isImmovablePropertyChk."
                            )
                          ),
                  },
                ]}
              >
                <Checkbox>
                  I confirmed that the immovable property is situated in India
                  and is not an agricultural land or plantation property or farm
                  house.
                </Checkbox>
              </Form.Item>

              <Form.Item
                className="form-item"
                name="isDeclarationChk"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error("Please select your isDeclarationChk.")
                          ),
                  },
                ]}
              >
                <Checkbox>
                  I hereby declare that the aforesaid declarations and
                  statements are true and correct to the best of my knowledge
                  and behalf.
                </Checkbox>
              </Form.Item>
            </div>
            <div className="d-flex justify-content-center">
              <button
                htmlType="submit"
                className="btn btn-primary text-white btn-sm mx-2"
              >
                Submit
              </button>
            </div>
          </Row>
        </Form>
      </Modal>
    </div>
  );
}
