import React, { useEffect, useReducer } from "react";
import { config } from "../../../config";
import DefaultLayout from "../layout/DefaultLayout";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { Modal, Spin } from "antd";
import useHttp from "../../../hooks/useHttp";

export default function Notification(props) {
  const AuthReducer = useSelector((state) => state);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      notificationLists: [],
      notificationDesc: "",
      isModalVisible: false,
    }
  );

  const hookNotificationLists = useHttp(ProfileAPI.notificationLists);

  useEffect(async () => {
    notificationLists();
  }, []);

  const notificationLists = () => {
    let payload = {
      requestId: config.requestId,
      requestType: "NOTIFICATIONLISTS",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "157.33.79.38",
      userId: state.userID,
    };

    hookNotificationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          notificationLists: data.responseData,
        });
      }
    });
  };

  return (
    <div className="mt-4" style={{ backgroundColor: "#f1f5f6" }}>
      <DefaultLayout
        accessToken={props.appState.accessToken}
        isLoggedIn={props.appState.isLoggedIn}
        publicKey={props.appState.publicKey}
      >
        <div className="bg-white shadow-sm rounded p-4 mb-4">
          <h5 className="text-5 fw-400 d-flex align-items-center mb-4">
            Notification List
          </h5>
          <hr className="mb-4 mx-n4" />
          {state.notificationLists.map((not, i) => {
            return (
              <div key={i} className="p-2 mt-3 alert-danger">
                <p
                  role="button"
                  className="mb-0 text-dark"
                  onClick={() =>
                    setState({
                      notificationDesc: not.notificationDesc,
                      isModalVisible: true,
                    })
                  }
                >
                  {not.notificationName}
                </p>
              </div>
            );
          })}
        </div>
      </DefaultLayout>

      <Modal
        title="Notification Desc"
        visible={state.isModalVisible}
        onOk={() => setState({ isModalVisible: false })}
        onCancel={() => setState({ isModalVisible: false })}
        footer={false}
      >
        <h6>{state.notificationDesc}</h6>
      </Modal>
    </div>
  );
}
