import React, { useEffect } from 'react'
import Table from 'react-bootstrap/Table';
import DefaultLayout from '../layout/DefaultLayout';

export default function Dashboard(props) {

  useEffect(async () => {
    if (props.appState.isLoggedIn) {
      // let accessToken = await props.manageRefreshToken();
    }
  }, []);

  return (
    <div className='mt-4' style={{ backgroundColor: '#f1f5f6' }}>
      <DefaultLayout
        accessToken={props.appState.accessToken}
        isLoggedIn={props.appState.isLoggedIn}
        publicKey={props.appState.publicKey}
      >
        <div className="bg-white shadow-sm rounded p-4 mb-4">
          <h3 className="text-5 fw-400 d-flex align-items-center mb-4">Profile Completeness<span className="border text-success rounded-pill fw-500 text-2 px-3 py-1 ms-2">50%</span></h3>
          <hr className="mb-4 mx-n4" />
          <div className="row gy-4 profile-completeness">
            <div className="col-sm-6 col-md-3">
              <div className="border rounded text-center px-3 py-4"> <span className="d-block text-10 text-light mt-2 mb-3"><i className="fas fa-mobile-alt" /></span> <span className="text-5 d-block text-success mt-4 mb-3"><i className="fas fa-check-circle" /></span>
                <p className="mb-0">Mobile Added</p>
              </div>
            </div>
            <div className="col-sm-6 col-md-3">
              <div className="border rounded text-center px-3 py-4"> <span className="d-block text-10 text-light mt-2 mb-3"><i className="fas fa-envelope" /></span> <span className="text-5 d-block text-success mt-4 mb-3"><i className="fas fa-check-circle" /></span>
                <p className="mb-0">Email Added</p>
              </div>
            </div>
            <div className="col-sm-6 col-md-3">
              <div className="position-relative border rounded text-center px-3 py-4"> <span className="d-block text-10 text-light mt-2 mb-3"><i className="fas fa-credit-card" /></span> <span className="text-5 d-block text-light mt-4 mb-3"><i className="far fa-circle " /></span>
                <p className="mb-0"><a className="btn-link stretched-link" href>Add Card</a></p>
              </div>
            </div>
            <div className="col-sm-6 col-md-3">
              <div className="position-relative border rounded text-center px-3 py-4"> <span className="d-block text-10 text-light mt-2 mb-3"><i className="fas fa-university" /></span> <span className="text-5 d-block text-light mt-4 mb-3"><i className="far fa-circle " /></span>
                <p className="mb-0"><a className="btn-link stretched-link" href>Add Bank Account</a></p>
              </div>
            </div>
          </div>
        </div>

        <div className="bg-white shadow-sm rounded p-4 mb-4">
          <h5 className="text-5 fw-400 d-flex align-items-center mb-4">Profile Completeness<span className="border text-success rounded-pill fw-500 small px-3 py-1 ms-2">50%</span></h5>
          <hr className="mb-4 mx-n4" />
          <Table bordered hover size="sm">
            <thead>
              <tr>
                <th>#</th>
                <th>First Name</th>
                <th>Last Name</th>
                <th>Username</th>
              </tr>
            </thead>
            <tbody>
              <tr>
                <td>1</td>
                <td>Mark</td>
                <td>Otto</td>
                <td>@mdo</td>
              </tr>
              <tr>
                <td>2</td>
                <td>Jacob</td>
                <td>Thornton</td>
                <td>@fat</td>
              </tr>
              <tr>
                <td>3</td>
                <td colSpan="2">Larry the Bird</td>
                <td>@twitter</td>
              </tr>
            </tbody>
          </Table>
        </div>
      </DefaultLayout>
    </div>
  )
}
