import React, { useState, useEffect, useReducer } from "react";
import Box from "@mui/material/Box";
import Grid from "@mui/material/Grid";
import Container from "react-bootstrap/Container";
import { Link } from "react-router-dom";
import {
  Form,
  Input,
  Checkbox,
  Select,
  Radio,
  DatePicker,
  notification,
  Spin,
} from "antd";
import moment from "moment";
import { AuthAPI } from "../../../apis/AuthAPI";
import { GuestAPI } from "../../../apis/GuestAPI";
import OTPBox from "../../../containers/OTPBox";
import ExchangeRate from "../../../containers/ExchangeRate";
import { config } from "../../../config";
import SetPassword from "./SetPassword";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";
import useHttp from "../../../hooks/useHttp";

const { Option } = Select;
export default function ForgotUserID(props) {
  const ConfigReducer = useSelector((state) => state);

  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [isSelectMarketingCommunication, setisSelectMarketingCommunication] =
    useState("N");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      phoneCodes: [],
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
      formData: {},
      _isShowOTPBOX: false,
      _isShowSuccessMessage: false,
      otpType: "FL",
    }
  );

  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookForgotUserID = useHttp(AuthAPI.forgotUserID);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    const payload = {
      requestType: "COUNTRYPHONECODE",
      sendCountry: "US",
      sendCurrency: "USD",
    };
    setLoader(true);
    hookGetCountryPhoenCodes.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
        setLoader(false);
      }
    });
  }, []);

  const onCreateLead = (value) => {
    form.setFields([
      { name: "mobilePhoneCode", errors: [] },
      { name: "mobileNo", errors: [] },
    ]);

    let forgotPasswordPayload = {
      requestType: "FORGOTLOGINID",
      emailId: "",
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
    };

    setLoader(true);
    hookForgotUserID.sendRequest(forgotPasswordPayload, (res) => {
      if (res.status == "S") {
        setState({ verificationToken: res.verificationToken });

        if (state.twofa == "N") {
          setState({
            isModalVisible: true,
            formData: value,
          });
        } else {
          setState({
            _isShowOTPBOX: true,
            isModalVisible: true,
            formData: value,
          });
        }
      } else {
        notification.error({ message: res.data.errorMessage });

        let errors = [];
        res.data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
      setLoader(false);
    });
  };

  return (
    <div className="d-flex w-100 h-100">
      <Container className="my-auto mx-auto py-5">
        {state._isShowOTPBOX && (
          <OTPBox
            state={state}
            setState={setState}
            otpType={state.otpType}
            useFor="forgot_password"
            appState={props.appState}
          />
        )}
        <Box>
          <Grid container spacing={{ xs: 2, md: 4 }}>
            <Grid item md={6} lg={6} xl={6}>
              {/* <ExchangeRate /> */}
            </Grid>
            <Grid
              item
              md={6}
              lg={6}
              xl={6}
              className="my-auto mx-auto pb-4 pb-lg-0"
            >
              {state._isShowSuccessMessage == false ? (
                <div className="bg-light text-dark shadow-md rounded  pt-sm-4 pb-sm-5">
                  <h3 className="fw-400 text-center mb-4">
                    {" "}
                    Forgot Your User ID?
                  </h3>
                  <p className="text-center">
                    A 6 digit OTP will be sent to your registered mobile number
                  </p>
                  <hr />
                  <Spin spinning={loading} delay={500}>
                    <Form form={form} onFinish={onCreateLead}>
                      <div className="rounded p-3 pt-sm-4 pb-sm-5 px-sm-4">
                        <Grid container spacing={2}>
                          <Grid item xs={4}>
                            <div className="">
                              <label className="form-label">Country Code</label>
                              <div>
                                <Form.Item
                                  className="form-item"
                                  name="mobilePhoneCode"
                                  rules={[
                                    {
                                      required: true,
                                      message:
                                        "Please select your Country Code.",
                                    },
                                  ]}
                                >
                                  <Select
                                    size="large"
                                    className="w-100"
                                    placeholder="Select Country Code"
                                  >
                                    {state.phoneCodes.map((phoneCode, i) => {
                                      return (
                                        <Option
                                          key={i}
                                          value={phoneCode.countryPhoneCode}
                                        >{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>
                                      );
                                    })}
                                  </Select>
                                </Form.Item>
                              </div>
                            </div>
                          </Grid>
                          <Grid item xs={8}>
                            <div className="">
                              <label className="form-label">
                                Mobile Number
                              </label>
                              <Form.Item
                                className="form-item"
                                name="mobileNo"
                                rules={[
                                  {
                                    required: true,
                                    message: "Please input your Mobile Number.",
                                  },
                                  {
                                    min: 10,
                                    max: 10,
                                    message: "Mobile number must be 10 digit.",
                                  },
                                  // { pattern: new RegExp("^[6]{1}[0-9]*$"), message: "Mobile number must start with 6" }
                                ]}
                              >
                                <Input
                                  size="large"
                                  placeholder="123456789"
                                  maxLength={10}
                                />
                              </Form.Item>
                            </div>
                          </Grid>
                        </Grid>

                        <div className="d-grid">
                          <button className="btn btn-primary text-white">
                            {state.twofa == "Y"
                              ? "Verify With OTP"
                              : "Verify Without OTP"}
                          </button>
                        </div>
                      </div>
                    </Form>
                  </Spin>
                </div>
              ) : (
                <div>
                  Done ! Your Money2India User ID has been sent to your
                  registered email ID
                </div>
              )}
            </Grid>
          </Grid>
        </Box>
      </Container>
      {/* ======== modal : OTP ============ */}
    </div>
  );
}
