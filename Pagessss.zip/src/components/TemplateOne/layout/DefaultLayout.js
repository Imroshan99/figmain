import React, { useReducer, useEffect } from "react";
// import LeftSidebar from "./LeftSidebar";
import { useSelector } from "react-redux";
// import Swal from "sweetalert2";
import { config } from "../../../config";
import { useNavigate } from "react-router-dom";
// import { ProfileAPI } from '../../../apis/ProfileAPI'
import { GuestAPI } from "../../../apis/GuestAPI";
import Grid from "@mui/material/Grid";
import { Container } from "react-bootstrap";
import useHttp from "./../../../hooks/useHttp";

export default function DefaultLayout({ children }) {
  let navigate = useNavigate();
  const AuthReducer = useSelector((state) => state);
  const hookGetTickerMessages = useHttp(GuestAPI.tickerMessages);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      userFullName: AuthReducer.userFullName,
      tickerMessagePosition: config.tickerMessagePosition.POSTLOGIN_TOP,
    }
  );

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getTikcerMessages();
  }, []);

  const getTikcerMessages = () => {
    const payload = {
      requestType: "TICKERMESSAGES",
      countryCode: "GB",
      position: state.tickerMessagePosition,
    };

    hookGetTickerMessages.sendRequest(payload, function (data) {
      if (data.status === "S") {
        //   setState({ recvCountryList: data.responseData });
      }
    });
  };

  return (
    <Container className="mt-5">
      <Grid container justify="center" alignItems="center" spacing={3}>
        {/* <Grid item md={3}>
                    <LeftSidebar state={state} />
                </Grid> */}
        {/* <Grid item lg={1} md={1} sm={1}/> */}
        <Grid item lg={12} md={12} sm={12} className="w-100">
          {children}
        </Grid>
      </Grid>
    </Container>
  );
}
