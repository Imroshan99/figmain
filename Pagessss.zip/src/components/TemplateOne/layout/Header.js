import React, { useState, useEffect, useReducer, Fragment } from "react";
import { Link, useLocation, useNavigate } from "react-router-dom";
import AppBar from "@mui/material/AppBar";
import Toolbar from "@mui/material/Toolbar";
import Box from "@mui/material/Box";
import Container from "@mui/material/Container";
import IconButton from "@mui/material/IconButton";
import Typography from "@mui/material/Typography";
import Menu from "@mui/material/Menu";
import MenuIcon from "@mui/icons-material/Menu";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import Tooltip from "@mui/material/Tooltip";
import MenuItem from "@mui/material/MenuItem";
import { AuthService } from "../../../services/AuthService";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { notification } from "antd";
import Swal from "sweetalert2";
import { config } from "../../../config";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../helpers/makeHash";

import useHttp from "../../../hooks/useHttp";

function stringToColor(string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = "#";

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}

function stringAvatar(name) {
  let nameAr = name.split(" ");
  let nm = "";
  if (nameAr.length > 1) {
    nm = `${name.split(" ")[0][0]}${name.split(" ")[1][0]}`;
  } else {
    nm = `${name.split(" ")[0][0]}`;
  }
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: nm,
  };
}

export default function Header(props) {
  // const HOST =
  //   window.location.hostname === "localhost"
  //     ? "qaonekcb.remit.in"
  //     : window.location.hostname;
  let navigate = useNavigate();
  let navLocation = useLocation();

  const AuthReducer = useSelector((state) => state);
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      firstName: "",
      lastName: "",
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
    }
  );

  console.log("props", props);
  const hookProfileApi = useHttp(ProfileAPI.getProfile);
  useEffect(async () => {
    if (props.appState.isLoggedIn) {
      let data = {
        requestId: config.requestId,
        requestType: "LEAD",
        channelId: config.channelId,
        clientId: state.clientId,
        groupId: state.groupId,
        sessionId: state.sessionId,
        ipAddress: "127.0.0.1",
        userId: AuthReducer.userID,
      };

      if (config.IS_ENC) {
        var key = config.key;
        var iv = config.iv;
        var body = encrypt(data, key, iv);
        var pubValue = iv.concat(key);
        var identifier = publickey(props.appState.publicKey, pubValue);

        var postData = {
          body: body,
          identifier: identifier,
        };
      } else {
        var postData = data;
      }

      // let accessToken = await props.manageRefreshToken();
      ProfileAPI.getProfile(postData, props.appState.accessToken)
        .then((res) => {
          if (config.IS_ENC) {
            var decode = decrypt(res.data.body, key, iv);
            var decodeData = JSON.parse(decode);
          } else {
            var decodeData = res.data;
          }

          if (decodeData.status == "S") {
            setState({
              firstName: decodeData.firstName,
              lastName: decodeData.lastName,
            });
          } else {
            notification.error({ message: res.data.errorMessage });
          }
        })
        .catch((error) => {
          if (error.response.status == 401 || error.response.status == 400) {
            Swal.fire({
              title: "Alert",
              text: error.response.data.errorMessage,
              icon: "warning",
              confirmButtonColor: "#2dbe60",
              allowOutsideClick: false,
              allowOutsideClick: false,
            }).then((result) => {
              if (result.isConfirmed) {
                // navigate('/signin');
                window.location.href = "/signin";
              }
            });
          }
        });
    }
  }, [props.appState.isLoggedIn]);

  const getProfileHandler = () => {
    let payload = {
      requestType: "GETPROFILE",
      userId: AuthReducer.userID,
    };
    hookProfileApi.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          lastName: data.lastName,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };

  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };

  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };

  const handleCloseUserMenu = () => {
    setAnchorElUser(null);
  };

  const logout = () => {
    // navigate('/');
    window.location.href = "/";
  };

  return (
    <AppBar
      position="static"
      className={
        AuthReducer.groupId === "MF" || AuthReducer.groupId === "CSB"
          ? "bg-light"
          : "bg-primary"
      }
    >
      <Container maxWidth="xl">
        <Toolbar disableGutters>
          <Link to="/">
            <img
              src={require("../../../assets/images/logos/" +
                AuthReducer.groupId +
                "_logo.png")}
              height="48px"
              alt="Logo"
            />
          </Link>
          {/* /////////// responsive header button onclick//////// */}

          <Box
            sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}
            justifyContent={"end"}
          >
            <IconButton
              size="large"
              aria-label="account of current user"
              aria-controls="menu-appbar"
              aria-haspopup="true"
              onClick={handleOpenNavMenu}
              color="inherit"
            >
              <MenuIcon />
            </IconButton>
            <Menu
              id="menu-appbar"
              anchorEl={anchorElNav}
              anchorOrigin={{
                vertical: "bottom",
                horizontal: "left",
              }}
              keepMounted
              transformOrigin={{
                vertical: "top",
                horizontal: "left",
              }}
              open={Boolean(anchorElNav)}
              onClose={handleCloseNavMenu}
              sx={{
                display: { xs: "block", md: "none" },
              }}
            >
              {props.appState.isLoggedIn == false ? (
                [
                  <MenuItem key="m1" onClick={handleCloseNavMenu}>
                    <Link className="text-primary" to={"/signin"}>
                      LOGIN
                    </Link>
                  </MenuItem>,
                  <MenuItem key="m2" onClick={handleCloseNavMenu}>
                    <Link className="text-primary" to={"/signup"}>
                      SIGN UP
                    </Link>
                  </MenuItem>,
                ]
              ) : (
                <MenuItem onClick={handleCloseNavMenu}>
                  <Link className="text-primary" to={"/"}>
                    Home
                  </Link>
                </MenuItem>
              )}
            </Menu>
          </Box>

          {/* /////////// end responsive header button onclick//////// */}

          {/* <Typography
            variant="h6"
            noWrap
            component="div"
            sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}
          >
            LOGO
          </Typography> */}

          <Box
            sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}
            className="inline-menu"
          >
            {props.appState.isLoggedIn == false && (
              <Fragment>
                <Link
                  onClick={handleCloseNavMenu}
                  className="btn text-white"
                  to={"/signin"}
                >
                  LOGIN
                </Link>
                <Link
                  onClick={handleCloseNavMenu}
                  className="btn text-white"
                  to={"/signup"}
                >
                  SIGN UP
                </Link>
              </Fragment>
            )}
          </Box>

          {/* /////////////////// start responsive profile  /////////// */}
          {props.appState.isLoggedIn == true && (
            <Box sx={{ flexGrow: 0 }}>
              {/* <Link to="/notification-list">
                <IconButton
                  size="large"
                  aria-label="show 17 new notifications"
                  // color="inherit"
                >
                  <NotificationsIcon className="text-white" />
                  {/* <Badge badgeContent={17} color="error" /> */}
              {/* </IconButton> */}
              {/* </Link> */}
              <span className="d-none d-sm-inline-block px-3 last-login">
                Last Login : {AuthReducer.lastLogin}
              </span>
              {/* <Tooltip title="Open settings"> */}
              <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                <Avatar
                  alt={AuthReducer.userFullName}
                  {...stringAvatar(AuthReducer.userFullName)}
                  src="/static/images/avatar/2.jpg"
                />
              </IconButton>
              {/* </Tooltip> */}
              <Menu
                sx={{ mt: "45px" }}
                id="menu-appbar"
                anchorEl={anchorElUser}
                anchorOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                keepMounted
                transformOrigin={{
                  vertical: "top",
                  horizontal: "right",
                }}
                open={Boolean(anchorElUser)}
                onClose={handleCloseUserMenu}
              >
                {/* <MenuItem onClick={handleCloseUserMenu}>
                  <Link to={"/dashboard"} className="text-primary">
                    Dashboard
                  </Link>
                </MenuItem> */}
                {[
                  <MenuItem key="menu1" onClick={handleCloseUserMenu}>
                    <Link to={"/profile"} className="text-primary">
                      Profile
                    </Link>
                  </MenuItem>,
                  <MenuItem key="menu2" onClick={handleCloseUserMenu}>
                    <Link to={"/change-password"} className="text-primary">
                      Change Password
                    </Link>
                  </MenuItem>,
                  <MenuItem key="menu10" onClick={handleCloseUserMenu}>
                    <Link to={"/kyc"} className="text-primary">
                      Update KYC
                    </Link>
                  </MenuItem>,
                  // <MenuItem key="menu10" onClick={handleCloseUserMenu}>
                  //   <Link to={"/jumio-page"} className="text-primary">
                  //     Jumio
                  //   </Link>
                  // </MenuItem>,
                  <MenuItem key="menu3" onClick={handleCloseUserMenu}>
                    <Link to={"/my-bank-accounts"} className="text-primary">
                      My Bank Accounts
                    </Link>
                  </MenuItem>,
                  <MenuItem key="menu4" onClick={handleCloseUserMenu}>
                    <Link to={"/my-recipient"} className="text-primary">
                      My Recipient
                    </Link>
                  </MenuItem>,
                  <MenuItem key="menu5" onClick={handleCloseUserMenu}>
                    <Link to={"/transaction-list"} className="text-primary">
                      Transaction List
                    </Link>
                  </MenuItem>,
                  // <MenuItem key="menu6" onClick={handleCloseUserMenu}>
                  //   <Link to={"/rate-alert"} className="text-primary">
                  //     Rate Alert
                  //   </Link>
                  // </MenuItem>,
                  <MenuItem key="menu7" onClick={handleCloseUserMenu}>
                    <Link to="#!" className="text-primary" onClick={logout}>
                      Logout
                    </Link>
                  </MenuItem>,
                ]}
              </Menu>
            </Box>
          )}
          {/* /////////////////// end responsive profile  /////////// */}
        </Toolbar>
      </Container>
    </AppBar>
  );
}
