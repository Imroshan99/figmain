import React, { useState, useEffect, useReducer } from "react";
import Typography from "@mui/material/Typography";
import List from "@mui/material/List";
import ListItem from "@mui/material/ListItem";
import ListItemText from "@mui/material/ListItemText";
import Grid from "@mui/material/Grid";
import { Form, Checkbox, Input, Button, Select, Space, Radio } from "antd";

const { Option } = Select;

export default function ViewTransactionDetails(props) {
  const [form] = Form.useForm();

  const column1 = [
    {
      name: "You Send (A)",
      price: props.state.sendAmount + " " + props.state.sendingCurrencyCode,
    },
    {
      name: "Transfer Fee (B)",
      price: props.state.transferFee + " " + props.state.sendingCurrencyCode,
    },
    {
      name: "Total Amount Payable (A + B)",
      price:
        Number(props.state.sendAmount) +
        Number(props.state.transferFee) +
        " " +
        props.state.sendingCurrencyCode,
    },
    {
      name: "Prevailing Exchange Rate (C)",
      price: props.state.exchangeRate + " " + props.state.recvCurrencyCode,
    },
    {
      name: "Expected Delivery Date",
      price: props.state.expectedDeliveryDate,
    },
    {
      name: "Receiver Gets (A*C)",
      price: props.state.recvAmount + " " + props.state.recvCurrencyCode,
    },
  ];

  return (
    <React.Fragment>
      <Grid container spacing={12}>
        <Grid item xs={12} sm={12}>
          <h4>Transaction Details</h4>
          <List disablePadding>
            {column1.map((product) => (
              <ListItem key={product.name} sx={{ py: 1, px: 0 }}>
                <ListItemText primary={product.name} />
                <Typography variant="body2">{product.price}</Typography>
              </ListItem>
            ))}
          </List>
        </Grid>
      </Grid>
    </React.Fragment>
  );
}
