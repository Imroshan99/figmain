import React, { useState, useEffect, useReducer, useRef } from "react";
import { useNavigate } from "react-router-dom";
import Grid from "@mui/material/Grid";
import { Form, Input, Row, Col, Button, Tabs, Spin, notification } from "antd";
import { CopyOutlined } from "@ant-design/icons";
import useHttp from "../../../../../hooks/useHttp";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { ProfileAPI } from "../../../../../apis/ProfileAPI";
import Swal from "sweetalert2";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
import { useReactToPrint } from "react-to-print";

const XrPdf = React.lazy(() => import("../../sendmoney/Invoice/XR"));
const KcbPdf = React.lazy(() => import("../../sendmoney/Invoice/KCB"));

const { TabPane } = Tabs;

export default function TranctionSuccess(props) {
  const pdfRef = useRef(null);
  const navigate = useNavigate();
  const [transcationIntervalId, setTranscationIntervalId] = useState();
  const [sofortBtnLoader, setSofortBtnLoader] = useState(false);
  const [loginId, setLoginId] = useState("");
  const [copyLabel, setCopyLabel] = useState("Copy");
  const [transactionXrn, setTransactionXrn] = useState();
  const AuthReducer = useSelector((state) => state);

  const hookProfileApi = useHttp(ProfileAPI.getProfile);
  const hookGetTransactionReceiptDetails = useHttp(
    TransactionAPI.transactionReceiptDetails
  );
  const hookGetCoreBankDetails = useHttp(TransactionAPI.getCoreBankDetails);
  const hookTxnTraceUpdate = useHttp(TransactionAPI.txnTraceUpdate);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      userID: AuthReducer.userID,
      pdfDetails: "",
      coreBankDetailsList: [],
    }
  );

  // useEffect(() => {
  //   getCoreBankDetails();
  // }, []);

  // const getCoreBankDetails = () => {
  //   const payload = {
  //     requestType: "CORRBANKDTLS",
  //     userId: state.userID,
  //     sendCountryCode: "GB",
  //     sendCurrencyCode: "GBP",
  //     sendModeCode: "CIP",
  //   };

  //   setSofortBtnLoader(true);
  //   hookGetCoreBankDetails.sendRequest(payload, function (data) {
  //     if (data.status == "S") {
  //       setState({ coreBankDetailsList: data.responseData });
  //       setSofortBtnLoader(false);
  //     }
  //   });
  // };

  const getProfileHandler = () => {
    let payload = {
      requestType: "GETPROFILE",
      userId: props.state.userID,
    };
    hookProfileApi.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setLoginId(data.loginId);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const getSofortTranscationDetails = async () => {
    try {
      const payload = {
        groupId: "XR",
        userId: props.state.userID,
        loginId: loginId,
        rgtn: props.state.txnId,
      };
      setSofortBtnLoader(true);
      const response = await TransactionAPI.sofortTransaction(payload, "");
      const data = response.data;
      if (data.status == "S") {
        return {
          tranId: data.tranId,
          redirectUrl: data.redirectUrl,
        };
      }
    } catch (error) {
      setSofortBtnLoader(false);
    }
  };

  const callback = (key) => {
    console.log(key);
  };


  useEffect(() => {
   
    props.setState({
      isTransactionBook: true,
    });
    getProfileHandler();
  }, []);

  useEffect(() => {
    return () => {
      clearInterval(transcationIntervalId);
    };
  }, [transcationIntervalId]);

  const onSofortClickHandler = async () => {
    clearInterval(transcationIntervalId);
    const sofortResponse = await getSofortTranscationDetails();

    //Open SOFORT external URL
    window.open(sofortResponse.redirectUrl);
    let transcationInterval = setInterval(() => {
      const SOFORT_TRANS_STATUS = window.localStorage.getItem(
        sofortResponse.tranId
      );
      if (SOFORT_TRANS_STATUS) {
        clearInterval(transcationInterval);
        if (SOFORT_TRANS_STATUS === "SUCCESS") {
          Swal.fire({
            title: "Payment Successful",
            text: "Transaction Successfull",
            // icon: "success",
            html: `<img src="${require("../../../../../assets/images/XR/payment-successful.gif")}" style="width:200px;" />`,
            confirmButtonText : 'Track Payment',
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              navigate("/my-transaction");
            }
          });
        }
        if (SOFORT_TRANS_STATUS === "FAILED") {
          Swal.fire({
            title: "Payment Failed",
            text: "Payment through Sofort has failed. Click here to try again with Sofort.",
            // icon: "error",
            html: `<img src="${require("../../../../../assets/images/XR/payment-failed.gif")}" style="width:130px;" />`,
            showCancelButton: true,
            confirmButtonText: "Try Again",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              // setSofortBtnLoader(false);
              onSofortClickHandler();
            }
          });
        }
        if (SOFORT_TRANS_STATUS === "TIMEOUT") {
          Swal.fire({
            title: "Timeout",
            text: "Transaction timeout",
            icon: "error",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,
          }).then((result) => {
            if (result.isConfirmed) {
              setSofortBtnLoader(false);
            }
          });
        }
      }
    }, 2000);

    setTranscationIntervalId(transcationInterval);
  };

  const handleTransactionXrn = (e) => {
    setTransactionXrn(e.target.value);
  };

  const handleTxnTraceUpdateClickHandler = () => {
    const payload = {
      requestType: "TXNTRACENOUPDATE",
      userId: state.userID,
      rgtn: props.state.txnId,
      traceNo: transactionXrn,
    };

    hookTxnTraceUpdate.sendRequest(payload, function (data) {
      if (data.status == "S") {
        notification.success({
          message: data.message,
        });
      } else {
        notification.error({
          message: data.errorMessage,
        });
      }
    });
  };

  // const printPdf = (txnRefno) => {
  //   const payload = {
  //     requestType: "TXNDETAILS",
  //     rgtn: "",
  //     txnRefNo: txnRefno,
  //     userId: props.state.userID,
  //   };

  //   hookGetTransactionReceiptDetails.sendRequest(payload, function (data) {
  //     if (data.status == "S") {
  //       setState({ pdfDetails: data });
  //       handlePrint();
  //     }
  //   });
  // };

  // const handlePrint = useReactToPrint({
  //   content: () => pdfRef.current,
  // });

  const handlerCopyText = (text) => {
    if (navigator.clipboard) {
      navigator.clipboard.writeText(text).then(
        function () {
          setCopyLabel("Copied");
        },
        function (err) {
          console.error("Async: Could not copy text: ", err);
        }
      );
    }
  };

  console.log("all state =>", props.state);

  const PdfPage = () => {
    const pdfAuthGroupId = useSelector((state) => state);
    switch (pdfAuthGroupId.groupId) {
      case "KCB":
        return (
          <KcbPdf
            ref={pdfRef}
            pdfDetails={state.pdfDetails}
            bankDetails={state.coreBankDetailsList}
          />
        );
        break;
      case "XR":
        return (
          <XrPdf
            ref={pdfRef}
            pdfDetails={state.pdfDetails}
            bankDetails={state.coreBankDetailsList}
          />
        );
        break;
      default:
        break;
    }
  };

  return (
    <React.Fragment>
      <div style={{ display: "none" }}>
        <PdfPage />
      </div>
      <div className="py-5">
        <Grid container spacing={3}>
          <Grid item xs={12} sm={12}>
            <Tabs
              defaultActiveKey={
                props.state.programCode === "FERINST" ? "1" : "2"
              }
              onChange={callback}
            >
              <TabPane tab="Pay now via Debit/Credit Card" key="1">
                <div className="row mb-5">
                  <div className="col-12 col-md-8">
                    <p>
                      'SOFORT Banking' is XR's new direct payment option in
                      partnership with UK's leading Payment Gateway. You no
                      longer have to take the effort to visit your internet
                      banking website, add our account details or approve us as
                      a beneficiary. Sofort Banking has been authorized by all
                      banks in the United Kingdom to accept payments.
                    </p>
                  </div>
                  <div className="col-12 col-md-4">
                    <div className="row text-light mb-2">
                      <div className="col-8">Total Amount</div>
                      <div className="col-4">
                        {props.state.sendCurrencyCode}{" "}
                        <span className="text-info ms-1">
                          {props.state.sendAmount}
                        </span>
                      </div>
                    </div>
                    <div className="row text-light mb-2">
                      <div className="col-8">Payment Gateway Charges</div>
                      <div className="col-4">
                        {props.state.sendCurrencyCode}{" "}
                        <span className="text-info ms-1">
                          {props.state.transferFee}
                        </span>
                      </div>
                    </div>
                    <div className="row text-light mb-2">
                      <div className="col-8">Total Amount to Transfer</div>
                      <div className="col-4">
                        {props.state.sendCurrencyCode}{" "}
                        <span className="text-info ms-1">
                          {props.state.sendingAmount}
                        </span>
                      </div>
                    </div>

                    <div className="row mt-3">
                      <div className="col-12">
                        <p className="text-info">
                          NOTE : In case you want to send money later by adding
                          XR bank account details yourself, please select the
                          existing Internet Banking option.
                        </p>
                      </div>
                      <div className="col-12">
                        <Spin spinning={sofortBtnLoader}>
                          <button
                            className="btn btn-sm btn-light text-primary w-100"
                            onClick={onSofortClickHandler}
                          >
                            Proceed Securely to SOFORT
                          </button>
                        </Spin>
                      </div>
                    </div>
                  </div>
                </div>

                <div className="row">
                  <div className="col-12">
                    <p>
                      Simply select your bank name on the secure and pay safely
                      &amp; directly using your internet banking details. SOFORT
                      Banking's 128-bit SSL encryption, through well-known
                      security providers like Norton and Trusteer, ensures that
                      your banking information is secure and your funds are
                      transferred directly to our accounts in a safe and secure
                      manner. Remember, all banks in the United Kingdom have
                      authorized Sofort Banking to collect payments from
                      customers.
                    </p>

                    {/* <button
                      style={{ width: "200px", float: "right" }}
                      className="btn btn-sm btn-light text-primary"
                      onClick={() => printPdf(props.state.txnRefNumber)}
                    >
                      Print Payment
                    </button>

                    <h6 className="text-light">
                      Your transaction and data is secured.
                    </h6> */}
                  </div>
                </div>
              </TabPane>
              <TabPane
                tab="Pay Later with Internet Banking"
                key="2"
                style={{ color: "#fff" }}
              >
                <p className="text-info mb-0">Step 1</p>
                <p className="fs-5">
                  Note down your XRTN: {props.state.txnRefNumber}
                </p>
                <br />
                <p className="text-info mb-0">Step 2</p>
                <p className="fs-5">
                  Login to Internet banking of your local bank account.
                </p>
                <br />
                <p className="text-info mb-0">Step 3</p>
                <p className="fs-5">
                  Go to funds transfer section and make us as a beneficiary /
                  recipient.
                </p>
                <br />
                <p className="text-info mb-0">Step 4</p>
                <p className="fs-5">
                  Enter the beneficiary / recipient information as below
                </p>
                <Grid container spacing={12}>
                  <Grid item xs={12} sm={12}>
                    <table
                      border="0"
                      width="100%"
                      cellspacing="0"
                      cellpadding="0"
                    >
                      <tbody>
                        <tr>
                          <td width="30%">
                            <strong>Name On The Account:</strong>
                          </td>
                          <td>RFX CLIENT AC GBP LLOYDS</td>
                        </tr>
                        <tr></tr>
                        <tr>
                          <td width="30%">
                            <strong>Bank Account Number:</strong>
                          </td>
                          <td>00569643</td>
                        </tr>
                        <tr></tr>
                        <tr>
                          <td width="30%">
                            <strong>Partner/Correspondent Bank:</strong>
                          </td>
                          <td>Lloyds Bank</td>
                        </tr>
                        <tr></tr>
                        <tr>
                          <td width="30%">
                            <strong>Swift Code:</strong>
                          </td>
                          <td>LOYDGB21F43</td>
                        </tr>
                        <tr></tr>
                        <tr>
                          <td width="30%">
                            <strong>Sort Code:</strong>
                          </td>
                          <td>304065</td>
                        </tr>
                        <tr></tr>
                        <tr>
                          <td width="30%">
                            <strong>IBAN:</strong>
                          </td>
                          <td>GB33LOYD30406500569643 </td>
                        </tr>
                        <tr></tr>

                        <tr>
                          <td width="30%">
                            <strong>XMONIES Transaction Number </strong>
                          </td>
                          <td>
                            {props.state.txnRefNumber}
                            <a
                              className="px-2 text-info"
                              onClick={() =>
                                handlerCopyText(props.state.txnRefNumber)
                              }
                            >
                              {copyLabel} <CopyOutlined className="ms-1" />
                            </a>
                          </td>
                        </tr>
                      </tbody>
                    </table>
                  </Grid>
                </Grid>
                <p>
                  <small className="text-info">
                    NOTE : <br />
                    Please mention your XR Transaction No.{" "}
                    {props.state.txnRefNumber} in "reference description
                    details" in your Internet banking website when you do the
                    transfer. This will help us to trace your money.
                  </small>
                </p>
                <br />

                <p className="text-info mb-0">Step 5</p>
                <p className="fs-5">
                  Enter the amount to be transferred as being{" "}
                  {props.state.txnSendAmount} GBP. (Also make sure you transfer{" "}
                  {props.state.txnSendAmount} GBP i.e. the exact same amount
                  that you have done a booking for.)
                </p>
                <br />
                <p className="text-info mb-0">Step 6</p>
                <p className="fs-5">Confirm the transaction.</p>
                <br />
              </TabPane>
            </Tabs>

            <div className="bg-secondary text-primary p-3 rounded-3 mb-5">
              <h3>Track your Transaction</h3>
              <p className="text-primary">
                Once you have sent the money from your Bank A/c via internet
                banking/Sofort Banking transfer, your bank may give you a Trace
                Transaction Reference Number, please enter it in here. This will
                help us in tracking your transaction better.
              </p>

              <div className="row g-2">
                <div className="col-8 col-md-6">
                  <Form.Item
                    style={{ display: "flex" }}
                    name="txn_number"
                    rules={[
                      {
                        required: true,
                        message: "Please enter your transcation number.",
                      },
                    ]}
                  >
                    <Input
                      placeholder="Enter transaction number"
                      onChange={handleTransactionXrn}
                    />
                  </Form.Item>
                </div>
                <div className="col-4 col-md-2">
                  <button
                    className="btn btn-primary text-light btn-sm"
                    onClick={handleTxnTraceUpdateClickHandler}
                  >
                    Track
                  </button>
                </div>
              </div>
              <p className="text-primary">
                This step is optional but important to track your transaction.
              </p>
            </div>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}
