import * as React from "react";
import Typography from "@mui/material/Typography";
import Grid from "@mui/material/Grid";
import {
  Form,
  Input,
  Select,
  Spin,
  Space,
  Radio,
  Row,
  Col,
  Button,
} from "antd";
import { EditOutlined } from "@ant-design/icons";
import { Link } from "react-router-dom";

export default function Receiver(props) {

  const editTransaction = () => {
    props.setState({activeStep: 0})
    
  };

  return (
    <React.Fragment>
      <h4
        style={{
          display: "flex",
          justifyContent: "space-between",
          color: "#fff",
        }}
      >
        Receiver Details
        <div  onClick={editTransaction} className="btn-link btn-link-icon text-info">
          Edit <EditOutlined className="ms-1" />
        </div>
      </h4>
      <br />
      <Grid container spacing={3} className="mb-5">
        <Grid item xs={12} sm={12}>
          <Row justify="space-between" className="bottom_border mb-3">
            <Col span={12} className="d-block">
              <p className="text-light"><strong>Sending To:</strong></p>
            </Col>
            <Col span={12} className="text-end ">
              <p className="text-light">{props.state.receiverName}</p>
            </Col>
          </Row>
          <Row justify="space-between" className="bottom_border mb-3">
            <Col span={12} className="d-block">
              <p className="text-light"><strong>Delivery Option:</strong></p>
            </Col>
            <Col span={12} className="text-end ">
              <p className="text-light">{props.state.deliveryOption}</p>
            </Col>
          </Row>
          <Row justify="space-between" className="bottom_border mb-3">
            <Col span={12} className="d-block">
              <p className="text-light"><strong>Account Details:</strong></p>
            </Col>
            <Col span={12} className="text-end ">
              <p className="text-light">
                {props.state.receiverBankName} {props.state.receiverBankCode}
              </p>
            </Col>
          </Row>
          <Row justify="space-between">
            <Col span={12} className="d-block">
              <p className="text-light"><strong>Bank Branch:</strong></p>
            </Col>
            <Col span={12} className="text-end ">
              <p className="text-light">{props.state.receiverBankBranch}</p>
            </Col>
          </Row>
        </Grid>
        
      </Grid>
      <div className="row">
          <div className="col-6">
            <button
              className="btn btn-sm btn-outline-light me-2"
              onClick={() => props.setState({ activeStep: 0 })}
            >
              Back
            </button>
          </div>
          <div className="col-6 text-end">
            <button
              htmlType="submit"
              className="btn btn-sm btn-light text-white"
              onClick={() => props.setState({ activeStep: 2 })}
            >
              Proceed
            </button>
          </div>
        </div>
    </React.Fragment>
  );
}
