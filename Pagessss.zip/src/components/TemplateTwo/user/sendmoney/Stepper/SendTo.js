import React, { useState, useEffect } from "react";
import Grid from "@mui/material/Grid";
import {
  Form,
  Button,
  Select,
  Input,
  Space,
  Radio,
  Row,
  Col,
  Modal,
} from "antd";
import AddRecipient from "../../recipient/AddRecipient";
import ViewTransactionDetails from "./ViewTransactionDetails";
import { useSelector } from "react-redux";
import useHttp from "../../../../../hooks/useHttp";
import { TransactionAPI } from "../../../../../apis/TransactionAPI";
import { GuestAPI } from "../../../../../apis/GuestAPI";
import { useLocation } from "react-router-dom";
import AddBankAccount from "../../../../../components/TemplateTwo/user/bankaccounts/CIP/AddBankAccount";
import { BankAccountAPI } from "../../../../../apis/BankAccountAPI";
import moment from "moment";

const { Option } = Select;

export default function SendTo(props) {
  const repeatTransactionData = useLocation();
  const AuthReducer = useSelector((state) => state);

  const [form] = Form.useForm();
  const [addRecipentModal, setAddRecipentModal] = useState(false);
  const [addBankAccountModal, setAddBankAccountModal] = useState(false);
  const [rerenderBanklist, setrerenderBanklist] = useState(false);
  const [loading, setLoader] = useState(false);
  const [tableRender, settableRender] = useState(false);
  const [contentRender, setContentRender] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [viewDetails, setViewDetails] = useState(false);
  const [sendAcnt, setSendAcnt] = useState();
  const [recvName, setRecvName] = useState();

  const hookGetRepeatTranscationDeatils = useHttp(
    TransactionAPI.repeatTranscationDeatils
  );
  const hookBankAccountList = useHttp(BankAccountAPI.bankAccountList);

  useEffect(async () => {
    accountsList();
  }, []);

  const accountsList = () => {
    setLoader(true);
    if (props.appState.isLoggedIn) {
      const payload = {
        requestType: "SENDERACCOUNTLIST",
        userId: props.state.userID,
        countryCode: "GB",
        favouriteFlag: "1",
        startIndex: "0",
        recordsPerRequest: "",
      };

      hookBankAccountList.sendRequest(payload, function (data) {
        if (data.status == "S") {
          settableRender(true);
          let resData = [];
          data.responseData.forEach((detail, i) => {
            let newData = {
              key: i,
              sendAccId: `${detail.sendAccId}`,
              recordToken: `${detail.recordToken}`,
              bankName: `${detail.bankName}`,
              accountNo: `${detail.accountNo}`,
              bankClearingCode: `${detail.sortCode}`,
              dateAdded: moment(detail.createdDate).format("MM-DD-YYYY"),
              status:
                detail.accountStatus.toUpperCase() === "R"
                  ? "Verified"
                  : "Rejected",
            };
            resData.push(newData);
          });
          props.setState({
            bankAccountList: resData,
          });
          setLoader(false);
          setContentRender(true);
        } else {
          setLoader(false);
          settableRender(false);
          setContentRender(true);
        }
      });
    }
  };

  useEffect(() => {
    if (repeatTransactionData.state !== null) {
      getRepeatTranscationDetails();
    }
  }, []);

  useEffect(() => {
    setTimeout(() => {
      props.state.receiverLists.filter((b) => {
        if (b.nickName === recvName) {
          props.setState({
            receiverBankCode: b.bankCode,
            receiverBankBranch: b.bankBranch,
          });
        }
      });
    }, 4000);
  }, [recvName]);

  const getRepeatTranscationDetails = () => {
    let transactiondata = {
      requestType: "TXNDETAILS",
      rgtn: repeatTransactionData.state.rgtn, //FROM repeat button
      txnRefNo: repeatTransactionData.state.txnRefNo, //FROM repeat button
      userId: props.state.userID,
    };

    hookGetRepeatTranscationDeatils.sendRequest(
      transactiondata,
      function (data) {
        if (data.status == "S") {
          form.setFieldsValue({
            receiverName: data.receiverName,
            receiverCountry: data.recvCountry === "IN-INR" ? "India" : "",
            senderCountry: "GB",
            transferOption: data.programCode,
            sendingAmount: data.sendAmount,
            deliveryOption: data.recvModeCodeDesc,
            purposeOfSending: data.purposeDesc,
            senderAccount: data.sendAccId,
          });
          props.setState({
            receiverName: data.receiverName,
            deliveryOption: data.recvModeCodeDesc,
            receiverBankName: data.recvBankName,
            paymentOption: data.programCode,
            purposeOfSending: data.purposeDesc,
            purposeId: data.purpose,
            nickName: data.receiverNickName,
            sendingAmount: data.sendAmount,
          });
          props.getPurposeLists(data.receiverNickName);
          props.getReceiverNameLists();
          setSendAcnt(data.sendAccId);
          setRecvName(data.receiverNickName);
          props.getComputeExchange(data.sendAmount);
        }
      }
    );
  };

  useEffect(() => {
    form.setFieldsValue({
      receiverName: props.state.receiverName,
      receiverCountry: props.state.receiverCountry,
      senderCountry: "GB",
      transferOption: props.state.paymentOption,
      // sendingAmount: props.defaultSendingAmount || props.state.sendingAmount,
      deliveryOption: props.state.deliveryOption,
      purposeOfSending: props.state.purposeOfSending,
      senderAccount: props.state.senderAccount,
    });
  }, []);

  useEffect(() => {
    // console.log("defaultSendingAmount =>", props.defaultSendingAmount);
    form.setFieldsValue({
      sendingAmount: props.defaultSendingAmount || props.state.sendingAmount,
    });
  }, [props.defaultSendingAmount]);

  const handleReceiverName = (data) => {
    console.log("receiver data=>", data);
    let receiver = JSON.parse(data);
    props.setState({
      receiverName: receiver.firstName + " " + receiver.lastName,
      receiverAccountNumber: receiver.accountNo,
      receiverBankBranch: receiver.bankBranch,
      receiverBankName: receiver.bankName,
      receiverNickName: receiver.nickName,
      receiverBranchCode: receiver.branchCode,
      receiverBankCode: receiver.bankCode,
      nickName: receiver.nickName,
    });
    props.getPurposeLists(receiver.nickName);
    // props.setState({ nickName: receiver.nickName });
    // props.getComputeExchange(receiver.nickName);
  };

  const handleReceivingCountry = (data) => {
    props.setState({
      receiverCountry: data,
    });
  };

  const handleSenderCountry = (data) => {
    props.setState({
      senderCountry: data,
    });
  };

  const handleSenderAccount = (data) => {
    // let sender = JSON.parse(data);
    props.setState({
      senderAccount: data,
      senderAccId: data,
    });
  };

  const handleChangeRadio = (data) => {
    // console.log("handleChangeRadio", data);
    props.setState({
      programCode: data.target.value,
      paymentOption: data.target.value,
      selectedPaymentMethod: data.target.programName,
    });
  };

  const handleDeliveryOptions = (data) => {
    props.setState({
      deliveryOption: data,
    });
  };

  const handlePurposeOfSending = (data) => {
    let purpose = JSON.parse(data);
    props.setState({
      purposeOfSending: purpose.displayName,
      purposeId: purpose.purposeId,
    });
  };

  const onFinishAccount = (value) => {
    props.setState({ activeStep: 1 });
  };

  const handleAmount = (event) => {
    props.handleSendingAmount(event.target.value);
    props.setState({ sendingAmount: event.target.value });
  };

  return (
    <React.Fragment>
      {/* {AuthReducer.userKYC === "DOB" && <div className="backdrop"></div>} */}
      <Form form={form} onFinish={onFinishAccount}>
        <Grid container spacing={{ xs: 2, md: 10 }}>
          <Modal
            className="primary"
            centered
            visible={addRecipentModal}
            onCancel={() => setAddRecipentModal(false)}
            width={1000}
            footer={null}
          >
            <AddRecipient
              getReceiverLists={props.getReceiverNameLists}
              setAddRecipentModal={setAddRecipentModal}
            />
          </Modal>

          <Modal
            className="primary"
            centered
            visible={viewDetails}
            onCancel={() => setViewDetails(false)}
            width={1000}
            footer={null}
          >
            <ViewTransactionDetails state={props.state} />
          </Modal>

          <Modal
            className="primary"
            centered
            visible={addBankAccountModal}
            onCancel={() => setAddBankAccountModal(false)}
            forceRender={true}
            footer={null}
            width={500}
          >
            <AddBankAccount
              appState={props.state}
              visible={addBankAccountModal}
              setVisible={setAddBankAccountModal}
              setrerenderBanklist={setrerenderBanklist}
              setIsLoading={setIsLoading}
              getBankAccountLists={props.getBankAccountLists}
            />
          </Modal>

          {/* 1st row */}
          <Grid item xs={12} sm={4}>
            <h4 style={{ color: "#fff" }}>Receiver Details</h4>
            <br />
            <label className="step-label">Receiver Name</label>
            <Grid container spacing={2}>
              <Grid item xs={7}>
                <Form.Item
                  className="form-item"
                  name="receiverName"
                  rules={[
                    {
                      required: true,
                      message: "Please select receiver name.",
                    },
                  ]}
                >
                  <Select
                    className="w-100"
                    placeholder="Select Receiver Name"
                    onChange={handleReceiverName}
                  >
                    {props.state.receiverLists.map((clist, i) => {
                      return (
                        <Option key={i} value={JSON.stringify(clist)}>
                          {clist.firstName} {clist.lastName}
                          <br /> <small>{clist.accountNo}</small>
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Grid>
              <Grid item xs={5}>
                <div
                  className="btn btn-sm btn-secondary w-100"
                  onClick={() => setAddRecipentModal(true)}
                >
                  Add New
                </div>
              </Grid>
            </Grid>

            <label className="step-label">Receiver Country</label>
            <Form.Item
              className="form-item"
              name="receiverCountry"
              rules={[
                {
                  required: true,
                  message: "Please select receiver country.",
                },
              ]}
            >
              <Select
                className="w-100"
                placeholder="Select Receiver Country"
                onChange={handleReceivingCountry}
              >
                {props.state.receiverCountryLists.map((clist, i) => {
                  return (
                    <Option
                      key={i}
                      value={clist.countryName}
                    >{`${clist.countryName}`}</Option>
                  );
                })}
              </Select>
            </Form.Item>
          </Grid>

          {/* 2nd row */}
          <Grid item xs={12} sm={4}>
            <h4 style={{ color: "#fff" }}>Sender Details</h4>
            <br />
            <label className="step-label">Sender Country</label>
            <Form.Item
              className="form-item"
              name="senderCountry"
              rules={[
                {
                  required: true,
                  message: "Please select sender country.",
                },
              ]}
            >
              <Select
                className="w-100"
                placeholder="Select Sender Country"
                disabled={true}
                onChange={handleSenderCountry}
              >
                {props.state.sendCountryList.map((clist, i) => {
                  return (
                    <Option
                      key={i}
                      value={clist.sendCountry}
                    >{`${clist.countryName}`}</Option>
                  );
                })}
              </Select>
            </Form.Item>

            <label className="step-label">Transfer Options</label>
            <Form.Item
              className="form-item"
              name="transferOption"
              rules={[
                {
                  required: true,
                  message: "Please select your transfer options.",
                },
              ]}
            >
              <Radio.Group
                value={props.state.value}
                onChange={handleChangeRadio}
              >
                <Space direction="vertical">
                  {props.state.paymentOptionsList.map((clist, i) => {
                    return (
                      <Radio
                        key={`po_${i}`}
                        programName={clist.programName}
                        value={clist.programCode}
                      >
                        {clist.programName}
                      </Radio>
                    );
                  })}
                </Space>
              </Radio.Group>
            </Form.Item>

            <label className="step-label">Sender Source Account</label>
            <Grid container spacing={2}>
              <Grid item xs={7}>
                <Form.Item
                  className="form-item"
                  name="senderAccount"
                  rules={[
                    {
                      required: true,
                      message: "Please select sender account.",
                    },
                  ]}
                >
                  <Select
                    className="w-100"
                    placeholder="Select Sender Account"
                    onChange={handleSenderAccount}
                  >
                    {props.state.bankAccountLists.map((clist, i) => {
                      return (
                        <Option key={i} value={clist.sendAccId}>
                          {clist.accountHolderName}
                          <br /> <small>{clist.accountNo}</small>
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Grid>
              <Grid item xs={5}>
                <div
                  className="btn btn-sm btn-secondary w-100"
                  onClick={() => setAddBankAccountModal(true)}
                >
                  Add New
                </div>
              </Grid>
            </Grid>

            <label className="step-label">Amount (GBP)</label>
            <Form.Item
              name="sendingAmount"
              rules={[
                {
                  required: true,
                  message: "Please input your amount.",
                },
                {
                  min: 1,
                  max: 9,
                  message: "Amount should be between 1 and 9 characters long",
                },
                {
                  pattern: /^(?:\d*\.\d{1,2}|\d+)$/,
                  message: "Allow only two decimals amount",
                },
                {
                  validator(_, value) {
                    if (value > 0) {
                      return Promise.resolve();
                    }
                    return Promise.reject("Please enter amount greater than 0");
                  },
                },
              ]}
            >
              <Input type="text" onChange={handleAmount} />
            </Form.Item>

            {/* <Row justify="space-between">
              <Col span={12} className="d-block">
                <small>Amount saved</small>
              </Col>
              <Col span={12} className="text-end ">
                <small>
                  {props.state.amountSaved} {props.state.sendingCurrencyCode}
                </small>
              </Col>
            </Row> */}

            <p
              style={{ color: "#10E7DC", cursor : 'pointer' }}
              onClick={() => setViewDetails(true)}
            >
              View Details
            </p>
          </Grid>

          {/* 3rd row */}
          <Grid item xs={12} sm={4}>
            <h4 style={{ color: "#fff" }}>Delivery Options</h4>
            <br />
            <label className="step-label">Receiving</label>
            <Form.Item
              className="form-item"
              name="deliveryOption"
              rules={[
                {
                  required: true,
                  message: "Please select delivery options.",
                },
              ]}
            >
              <Select
                className="w-100"
                placeholder="Select Delivery Options"
                onChange={handleDeliveryOptions}
              >
                {props.state.deliveryOptionsList.map((clist, i) => {
                  return (
                    <Option
                      key={i}
                      value={clist.recvMode}
                    >{`${clist.recvMode}`}</Option>
                  );
                })}
              </Select>
            </Form.Item>

            <label className="step-label">Purpose of Sending</label>
            <Form.Item
              className="form-item"
              name="purposeOfSending"
              rules={[
                {
                  required: true,
                  message: "Please select purpose of sending.",
                },
              ]}
            >
              <Select
                className="w-100"
                placeholder="Select Purpose of Sending"
                onChange={handlePurposeOfSending}
              >
                {props.state.purposeLists.map((clist, i) => {
                  return (
                    <Option
                      key={i}
                      value={JSON.stringify(clist)}
                    >{`${clist.displayName}`}</Option>
                  );
                })}
              </Select>
            </Form.Item>

            <Row justify="space-between">
              <Col span={12} className="d-block">
                <small>Exchange Rate</small>
              </Col>
              <Col span={12} className="text-end ">
                <small>
                  {`1 ${props.state.sendCurrencyCode} = ${props.state.displayExRate} ${props.state.recvCurrencyCode}`}
                </small>
              </Col>
            </Row>
            
            <Row justify="space-between">
              <Col span={12} className="d-block">
                <small>Transfer Fee</small>
              </Col>
              <Col span={12} className="text-end ">
                <small>
                  {props.state.transferFee} {props.state.sendingCurrencyCode}
                </small>
              </Col>
            </Row>
            <Row justify="space-between">
              <Col span={12} className="d-block">
                <small>Total delivered</small>
              </Col>
              <Col span={12} className="text-end ">
                <small>
                  {props.state.sendAmount} {props.state.sendingCurrencyCode}
                </small>
              </Col>
            </Row>
            <Row justify="space-between">
              <Col span={12} className="d-block">
                <small>Receiving Amount</small>
              </Col>
              <Col span={12} className="text-end ">
                <small>
                  {props.state.recvAmount} {props.state.recvCurrencyCode}
                </small>
              </Col>
            </Row>
          </Grid>

          <div className="w-100 text-end mt-3">
            <button
              htmlType="submit"
              className="btn btn-sm btn-light text-white"
              // disabled={AuthReducer.userKYC == "DOB"}
            >
              Proceed
            </button>
          </div>
        </Grid>
      </Form>
    </React.Fragment>
  );
}
