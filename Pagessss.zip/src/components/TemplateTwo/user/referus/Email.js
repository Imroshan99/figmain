import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
  Tabs,
} from "antd";
import DefaultLayout from "../../layout/DefaultLayout";
import Grid from "@mui/material/Grid";
import { GuestAPI } from "../../../../apis/GuestAPI";
import useHttp from "../../../../hooks/useHttp";
import { useSelector } from "react-redux";

export default function Email(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isTransactionBook: false,
      phoneCodeList: [],
      userID: AuthReducer.userID,
      loading: false,
      countryPhoneCode: "",
      phoneNumber: "",
      email: "",
    }
  );

  const hookReferFriend = useHttp(GuestAPI.referFriend);

  const sendSms = () => {
    const payload = {
      requestType: "ADDREFERAL",
      userId: state.userID,
      firstName: "",
      lastName: "",
      emailId: state.email,
      mobilePhoneCode: "",
      mobileNo: "",
      countryCode: "GB",
    };

    setState({ loading: true });
    hookReferFriend.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ loading: false });
      }
    });
  };

  const handleEmail = (e) => {
    setState({ email: e.target.value });
  };

  return (
    <React.Fragment>
      <div style={{ marginLeft: "100px" }}>
        <Form form={form} onFinish={sendSms}>
          <Grid container spacing={3}>
            <Grid item xs={12} sm={12}>
              <h4>Enter Recipient’s E-Mail Adress</h4>
              <Form.Item
                name="email"
                rules={[
                  {
                    required: true,
                    message: "Please input your email.",
                  },
                ]}
              >
                <Input
                  type="email"
                  placeholder="Enter E-Mail"
                  onChange={handleEmail}
                />
              </Form.Item>

              <br />
              <p>
                We will send the reciepient an E-Mail containing your unique
                Referal Code
              </p>
              <button
                className="btn"
                style={{
                  background: "#003153",
                  float: "right",
                  color: "#fff",
                  marginTop: "20px",
                }}
              >
                Send E-Mail
              </button>
            </Grid>
          </Grid>
        </Form>
      </div>
    </React.Fragment>
  );
}
