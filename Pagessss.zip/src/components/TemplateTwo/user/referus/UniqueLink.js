import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
  Tabs,
} from "antd";
import DefaultLayout from "../../layout/DefaultLayout";
import Grid from "@mui/material/Grid";

export default function UniqueLink(props) {
  const [copySuccess, setCopySuccess] = useState("");
  const textRef = useRef(null);

  const handleCopyText = (e) => {
    console.log("code =>", textRef.current.value);
    textRef.current.select();
    document.execCommand("copy");
    e.target.focus();
    setCopySuccess("Copied!");
  };

  return (
    <React.Fragment>
      <div style={{ marginLeft: "100px" }}>
        <Grid container spacing={3}>
          <Grid item xs={12} sm={12}>
            <h4>Your Unique Referal Link</h4>
            <div style={{ display: "flex" }}>
              <Input
                ref={textRef}
                value="www.xmonies.com/ref-test115241-ggdg/fchgy..."
              />
              <button
                className="btn"
                style={{
                  width: "20%",
                  background: "#10E7DC",
                  borderRadius: "4px",
                  marginLeft: "10px",
                }}
                onClick={handleCopyText}
              >
                Copy Link
              </button>
              {copySuccess}
            </div>
            <br />
            <p>
              Copy this link and paste it in referal section of the other user
              to redeem referal bonus
            </p>
            <button
              className="btn"
              style={{
                background: "#003153",
                float: "right",
                color: "#fff",
                marginTop: "20px",
              }}
            >
              Done
            </button>
          </Grid>
        </Grid>
      </div>
    </React.Fragment>
  );
}
