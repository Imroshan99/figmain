import { Modal, Spin } from "antd";

function RecipientInfo(props) {
  let recipientDetails = props.state.modalRecipientsDetails;
  return (
    <Modal
      afterClose={props.afterClose}
      className="primary"
      centered
      visible={props.state.isModalVisible}
      onCancel={() => props.setState({ isModalVisible: false })}
      footer={null}
    >
      <Spin spinning={props.spinner}>
        <div className="mb-32 row">
          <div className="col-md-12 mb-6">
            <h4 className="text-white">Recipient Details</h4>
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 mb-3">
            Account Number: <br /> {recipientDetails.accountNo}
          </div>
          <div className="col-md-6 mb-3">
            Recipient's Bank Name: <br /> {recipientDetails.bankName}
          </div>
        </div>
        <div className="row">
          <div className="col-md-6 mb-3">
            Full Name: <br /> {recipientDetails.accountHolderName}
          </div>
          <div className="col-md-6 mb-3">
            City: <br /> {recipientDetails.city}
          </div>
        </div>
      </Spin>
    </Modal>
  );
}

export default RecipientInfo;
