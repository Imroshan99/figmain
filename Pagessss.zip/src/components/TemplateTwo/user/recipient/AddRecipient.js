import React, { useState, useReducer, useEffect } from "react";
import { Form, notification, Spin } from "antd";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import useHttp from "../../../../hooks/useHttp";
import AddRecipientStep1 from "./AddRecipientStep1";
import AddRecipientStep2 from "./AddRecipientStep2";

export default function AddRecipient(props) {
  const [newForm] = Form.useForm();
  const [newForm1] = Form.useForm();

  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const AddRecipientFormConfig =
    ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
  const [loading, setLoader] = useState(false);
  const [addRecipentModalStep, setAddRecipentModalStep] = useState(true);
  const [dataForm, setDataForm] = useState({});
  const [activeTab, setActiveTab] = useState(1);
  const [ifscBranchName, setIfscBranchName] = useState("");
  const [ifscCodeValidator, setIfscCodeValidator] = useState();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AddRecipientFormConfig?.twoFA
        ? AddRecipientFormConfig.twoFA
        : AuthReducer.twofa,
      // twofa:   AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      nationalities: [],
      stateCities: [],
      _showOTPBOX: false,
      showConfirmAddRecipient: false,
      isConfirmAddRecipient: false,
      formData: {},
      verificationToken: "",
      isOTPVerfied: false,
      isModalVisible: false,
      otpType: "RA",
      branchCode: "",
      bankBranch: "",
      bankAddress: "",
      bankState: "",
      bankCity: "",
      bankName: "",
      isSameBank: "N",
      bankCode: "",
      bankId: "",
      bankCountry: "",
      isSelectedIFSC: false,
      bankLists: [],
      cityLists: [],
      branchLists: [],
      phoneCodes: [],
      occupationLists: [],
      relationshipLists: [],
      deliveryOptionsList: [],
      deliveryOption: "",
      stateLists: [],
      dob: "",
      redirectPage: "",
      redirectPageState: [],
      selectedBranch: {},
    }
  );

  const hookCheckDuplicateReceiver = useHttp(
    ReceiverAPI.checkDuplicateReceiver
  );

  const hookAddReceiver = useHttp(ReceiverAPI.addReceiver);

  const onFinish = async (value) => {
    const recvPayload = {
      ...dataForm,
      ...value,
    };

    let relationship = recvPayload.relationship;
    let formData = {
      requestType: "RECEIVERADD",
      receiverType: "INDIVIDUAL",
      firstName: recvPayload.firstName.trim(),
      middleName: recvPayload.middleName ? recvPayload.middleName : "",
      lastName: recvPayload.lastName.trim(),
      nickName: recvPayload.nickName.trim(),
      accountNo: recvPayload.accountNo,
      relationship: relationship.relationshipDesc,
      gender: "",
      dob: state.dob ? state.dob : "",
      address1: recvPayload.address1.trim(),
      address2: recvPayload.city.trim(),
      zipcode: recvPayload.zipCode,
      state: recvPayload.state.trim(),
      stateOther: "",
      city: recvPayload.city,
      nationality: recvPayload.nationality ? recvPayload.nationality : "",
      cityOther: "",
      emailId: recvPayload.emailId ? recvPayload.emailId : "",

      mobileCountryCode: recvPayload.mobileCountryCode
        ? recvPayload.mobileCountryCode
        : "",
      mobileNo: recvPayload.mobileNo ? recvPayload.mobileNo : "",
      phoneNo: recvPayload.phoneNo,
      altPhone: recvPayload.phoneNo,
      fax: "",
      recvMode: recvPayload.deliveryOption,
      accountHolderName: `${value.firstName.trim()} ${value.lastName.trim()}`,
      accountType: recvPayload.accountType,
      bankName: recvPayload.bankName,
      branchCode: recvPayload.branchCode,
      bankBranch: recvPayload.branchName,
      bankAddress: recvPayload.bankAddress,
      bankState: recvPayload.bankState,
      bankCity: recvPayload.bankCity,
      nearestBranchCode: "",
      nearestBranch: "",
      recvUniqueIdType: "",
      recvUniqueIdValue: "",
      interBankCode: "",
      interBank: "",
      interAccountNo: "",
      interAccountType: "",
      interBranchCode: "",
      interBankBranch: "",
      interBankAddress: "",
      interBankCountry: "",
      recvCountry: AuthReducer.recvCountryCode,
      recvCurrency: AuthReducer.recvCurrencyCode,
      purpose: "",
      purposeCode: "",
      remark: "",
      isSameBank: "N",
      twofa: state.twofa,
      userId: state.userID,
    };

    setLoader(true);
    await hookCheckDuplicateReceiver.sendRequest(formData, function (data) {
      if (data.status == "S") {
        setState({ formData: value, showConfirmAddRecipient: true });
        saveReceiver(value);
        // window.scrollTo({ top: 0, behavior: "smooth" });
      } else {
        notification.error({ message: data.errorMessage });
        setLoader(false);
      }
    });
  };

  const saveReceiver = async (value) => {
    // let postData = value;
    const recvPayload = {
      ...dataForm,
      ...value,
    };

    let relationship = recvPayload?.relationship;

    let formData = {
      requestType: "RECEIVERADD",
      receiverType: "INDIVIDUAL",
      firstName: recvPayload.firstName.trim(),
      middleName: recvPayload.middleName ? recvPayload.middleName : "",
      lastName: recvPayload.lastName.trim(),
      nickName: recvPayload.nickName.trim(),
      accountNo: recvPayload.accountNo,
      relationship: relationship.relationshipDesc,
      gender: "",
      dob: state.dob ? state.dob : "",
      address1: recvPayload.address1.trim(),
      address2: recvPayload.city.trim(),
      zipcode: recvPayload.zipCode,
      state: recvPayload.state.trim(),
      stateOther: "",
      city: recvPayload.city,
      nationality: recvPayload.nationality ? recvPayload.nationality : "",
      cityOther: "",
      emailId: recvPayload.emailId ? recvPayload.emailId : "",

      mobileCountryCode: recvPayload.mobileCountryCode
        ? recvPayload.mobileCountryCode
        : "",
      mobileNo: recvPayload.mobileNo ? recvPayload.mobileNo : "",
      phoneNo: recvPayload.phoneNo,
      altPhone: recvPayload.phoneNo,
      fax: "",
      recvMode: recvPayload.deliveryOption,
      accountHolderName: `${value.firstName.trim()} ${value.lastName.trim()}`,
      accountType: recvPayload.accountType,
      bankName: recvPayload.bankName,
      branchCode: recvPayload.branchCode,
      bankBranch: recvPayload.branchName,
      bankAddress: recvPayload.bankAddress,
      bankState: recvPayload.bankState,
      bankCity: recvPayload.bankCity,
      nearestBranchCode: "",
      nearestBranch: "",
      recvUniqueIdType: "",
      recvUniqueIdValue: "",
      interBankCode: "",
      interBank: "",
      interAccountNo: "",
      interAccountType: "",
      interBranchCode: "",
      interBankBranch: "",
      interBankAddress: "",
      interBankCountry: "",
      recvCountry: AuthReducer.recvCountryCode,
      recvCurrency: AuthReducer.recvCurrencyCode,
      purpose: "",
      purposeCode: "",
      remark: "",
      isSameBank: "N",
      twofa: state.twofa,
      userId: state.userID,
    };

    setLoader(true);
    hookAddReceiver.sendRequest(formData, function (data) {
      if (data.status == "S") {
        notification.success({ message: data.message });
        props.getReceiverLists();
        setLoader(false);
        props.setAddRecipentModal(false);
        newForm.resetFields();
        newForm1.resetFields();
        setAddRecipentModalStep(true);
      } else {
        setLoader(false);
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) newForm.setFields(errors);
        if (errors.length > 0) newForm1.setFields(errors);
      }
    });
  };

  const saveFormDataHandler = (values) => {
    setDataForm({ ...values });
  };

  return (
    <div>
      <Spin spinning={loading}>
        <div className="row mb-3">
          <div className="col">
            <h2
              style={{
                width: "12.57rem",
                borderBottom: "1px solid white",
              }}
            >
              Add New Receiver
            </h2>
          </div>
          <div className="col text-end">
            {addRecipentModalStep ? <h2>Step 1</h2> : <h2>Step 2</h2>}
          </div>
        </div>
        {addRecipentModalStep && (
          <AddRecipientStep1
            state={state}
            setState={setState}
            setLoader={setLoader}
            setDataForm={setDataForm}
            saveFormDataHandler={saveFormDataHandler}
            setAddRecipentModalSetp2={setAddRecipentModalStep}
            newForm={newForm}
            activeTab={activeTab}
            setActiveTab={setActiveTab}
            ifscBranchName={ifscBranchName}
            setIfscBranchName={setIfscBranchName}
            setIfscCodeValidator={setIfscCodeValidator}
            ifscCodeValidator={ifscCodeValidator}
          />
        )}
        {!addRecipentModalStep && (
          <AddRecipientStep2
            setLoader={setLoader}
            saveFormDataHandler={saveFormDataHandler}
            formState={dataForm}
            setDataForm={setDataForm}
            onFinish={onFinish}
            newForm1={newForm1}
            setAddRecipentModalSetp2={setAddRecipentModalStep}
          />
        )}
      </Spin>
    </div>
  );
}
