import React, { useEffect, useReducer, useState } from "react";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { useSelector } from "react-redux";
import { Row, Col, notification, Spin, Input, Form, Select } from "antd";
import { GuestAPI } from "../../../../apis/GuestAPI";
import useHttp from "../../../../hooks/useHttp";
import { Modal } from "antd";
import SubHeader from "../../layout/SubHeader";
import EditAddressBox from "../../containers/EditAddressBox";
import EditContactBox from "../../containers/EditContactBox";
import { useNavigate } from "react-router-dom";
import KYCModal from "../../auth/KYCModal";

function Profile2(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const [loader, setLoader] = useState(false);
  const Navigate = useNavigate();
  const [isModalVisible, setIsModalVisible] = useState(false);

  const profileConfig = ConfigReducer.groupIdSettings.profileModule;
  // alert(profileConfig.twoFA)
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      twofa: profileConfig.twoFA,
      firstName: "",
      middleName: "",
      lastName: "",
      emailId: "",
      dob: "",
      editableMobileNo: "",
      editablemobilePhoneCode: "",
      mobilePhoneCode: "",
      mobileNo: "",
      phoneNo: "",
      gender: "",
      citizenship: "",
      citizenshipDesc: "",
      nationality_id: "",
      nationalityDesc: "",
      occupation_id: "",
      occupationDesc: "",
      profession_id: "",
      professionDesc: "",
      isSameCommAddressFlag: "",
      marketCommunication: "",
      address1: "",
      address3: "",
      city: "",
      state: "",
      country:
        AuthReducer.sendCountryCode == "GB"
          ? "United Knigdom"
          : AuthReducer.sendCountryCode,
      zip: "",
      income_id: "",
      incomeDesc: "",
      countryPhoneCodes: [],
      occupationLists: [],
      professionLists: [],
      incomeLists: [],
      _isShowAddressEditModel: false,
      _isShowContactEditModel: false,
      _isShowMarketingEditModel: false,
      _isShowAddressOTPBOX: false,
      _isShowContactOTPBOX: false,
      _isShowMarketingOTPBOX: false,
      _isEditPhoneModal: false,
      isModalVisible: false,
      _editAddressBoxBtn: false,
      verificationToken: "",
      verifiedToken: "",
      citizenshipLists: [],
      senderContactDetailsErrors: [],
      stateLists: [],
      cityLists: [],
      newStateList: [],
      editContactTab: "",
    }
  );

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookGetIncomeLists = useHttp(ProfileAPI.incomeLists);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookEditSenderContactdtls = useHttp(ProfileAPI.editSenderContactdtls);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetProfessionLists = useHttp(GuestAPI.professionLists);
  const hookGetCitizenshipLists = useHttp(GuestAPI.citizenshipLists);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);

  useEffect(() => {
    getProfile();
    countryPhoneCodes();
    // incomeLists();
    // occupationLists();
    // professionLists();
    // citizenshipLists();
    getStateLists();
  }, []);
  useEffect(() => {
    if (state._editAddressBoxBtn) {
      editProfile(state);
      setState({ _editAddressBoxBtn: false });
    }
  }, [state._editAddressBoxBtn]);

  const getProfile = () => {
    setLoader(true);
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setLoader(false);
        const homePhoneNo = data.homePhoneNo;
        const homePhoneNoArray = homePhoneNo.split("-");
        
        form.setFieldsValue({
          phoneCountryCode:  homePhoneNoArray[0] ? (homePhoneNoArray[0]).replace('+', '') : "",
        });
        form.setFieldsValue({
          phoneNo: homePhoneNoArray[1] ? homePhoneNoArray[1] : "",
        });

        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          phoneNo: data.homePhoneNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isSameCommAddressFlag: data.isSameCommAddressFlag,
          marketCommunication: data.marketCommunication,
        });
      } else {
        setLoader(false);
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };

    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const newStateList = [
          ...data.responseData,
          {
            stateCode: "OTHER",
            state: "Other",
          },
        ];
        setState({ newStateList: newStateList });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      stateCode: stateCode,
    };

    hookGetStateCities.sendRequest(cityPayload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      }
    });
  };

  const editProfile = (value) => {
    const editProfileData = {
      requestType: "EDITPROFILE",
      SIN: undefined,
      address1: window.btoa(state.address1),
      address2: "",
      address3: window.btoa(state.address3),
      address4: "",
      address5: "",
      citizenship: state.citizenship,
      city: window.btoa(state.city),
      commAddress1: "",
      commAddress2: "",
      commCity: "",
      commCountry: "",
      commPostalCode: "",
      commStateProvince: "",
      companyName: "",
      dob: state.dob,
      gender: state.gender,
      homePhoneNo: "+" + value.phoneCountryCode + "-" + value.phoneNo,
      income: state.income_id,
      industry: "",
      periodicUpdate: state.isSameCommAddressFlag,
      isSameCommAddressFlag: state.isSameCommAddressFlag,
      marketCommunication: state.marketCommunication,
      motherMaidenName: "",
      nationality: state.nationality_id,
      occupation: state.occupation_id,
      pageName: "EDITPROFILE",
      pep: "",
      primaryBusinessFunction: "",
      profession: state.profession_id === "" ? "1" : state.profession_id,
      salutation: "",
      sendCountry: AuthReducer.sendCountryCode,
      state: window.btoa(state.state),
      tnc: "",
      zipCode: state.zip,
      userId: state.userID,
    };
    setLoader(true);
    hookEditProfile.sendRequest(editProfileData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
          _isEditPhoneModal: false,
        });
        notification.success({ message: data.message });
      } else {
        setLoader(false);
        setState({
          isModalVisible: false,
        });
        setState({ _isEditPhoneModal: false });
        notification.error({ message: data.errorMessage });
      }
      getProfile();
    });
  };
  const citizenshipLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCitizenshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ citizenshipLists: data.responseData });
      }
    });
  };
  const countryPhoneCodes = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCountryPhoenCodes.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
      }
    });
  };

  const occupationLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ occupationLists: data.responseData });
      }
    });
  };

  const professionLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetProfessionLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ professionLists: data.responseData });
      }
    });
  };

  const incomeLists = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetIncomeLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ incomeLists: data.responseData });
      }
    });
  };
  const editAddressHandler = () => {
    setIsModalVisible(true);
  };
  const sendOTP = (otpType, otpFor) => {
    const OTPData = {
      requestType: "SENDOTP",
      mobilePhoneCode: state.mobilePhoneCode,
      mobileNo:
        state.editableMobileNo == "" ? state.mobileNo : state.editableMobileNo,
      emailId: state.emailId,
      otpType: otpType,
      senderName: "",
      // userId: otpFor == "Edit_Contact" ? undefined : state.userID,
      userId: state.userID,
    };

    hookSendOTP.sendRequest(OTPData, function (data) {
      if (data.status == "S") {
        setState({
          verificationToken: data.verificationToken,
        });
        setTimeout(() => {
          if (otpFor == "Edit_Address") {
            setState({
              _isShowAddressOTPBOX: true,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Contact") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: true,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Marketing") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: true,
              isModalVisible: true,
            });
          }
        }, 100);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const editSenderContactdtls = (verifiedToken) => {
    setLoader(true);
    const contactData = {
      requestType: "editContactProfile",
      areaCode: "",
      emailId: state.emailId,
      mobilePhoneCode: state.editablemobilePhoneCode,
      mobileNo: state.editableMobileNo,
      phoneNo: state.phoneNo,
      //   altMobileNo: state.phoneNo,
      sendCountryCode: AuthReducer.sendCountryCode,
      verifiedToken: verifiedToken,
      userId: state.userID,
      twofa: state.twofa, //for otp
    };

    hookEditSenderContactdtls.sendRequest(contactData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
          mobilePhoneCode: state.editablemobilePhoneCode,
          mobileNo: state.editableMobileNo,
          editablemobilePhoneCode: "",
          editableMobileNo: "",
        });
        notification.success({ message: data.message });
      } else {
        setLoader(false);
        setState({
          isModalVisible: false,
        });

        notification.error({ message: data.errorMessage });
        setState({
          senderContactDetailsErrors: data.errorList,
        });
      }
      getProfile();
    });
  };
  const onFinish = (value) => {
    editProfile(value);
  };

  const renderGender = () => {
    if (state.gender === "M") {
      return "Male";
    } else if (state.gender === "F") {
      return "Female";
    } else {
      return state.gender;
    }
  };

  return (
    <>
      <SubHeader title="Profile" />
      <Spin spinning={loader}>
        <div className="profile-container template2__main">
          <div className="container _profile_page">
            <Row className="my-4">
              <h2 style={{ fontWeight: 600 }}>{AuthReducer.userFullName}</h2>
            </Row>
            <Row className="d-flex justify-content-between">
              <Col style={{ width: "45%" }}>
                <label className="form-label text-white">Email</label>
                <div className="d-flex">
                  <Input
                    size="large"
                    style={{
                      backgroundColor: "#184562",
                      border: 0,
                      color: "#849DAB",
                    }}
                    disabled
                    value={state.emailId}
                  ></Input>
                  <button
                    onClick={() =>
                      setState({
                        _isShowContactEditModel: true,
                        editContactTab: "3",
                      })
                    }
                    className="showmore-button"
                  >
                    Edit
                  </button>
                </div>
              </Col>
              <Col
                style={{ width: "50%" }}
                className="d-flex justify-content-between"
              >
                <div style={{ width: "39%" }}>
                  <label className="form-label text-white">Gender</label>
                  <Input
                    size="large"
                    style={{
                      backgroundColor: "#003153",
                      border: "1px solid #9FB2BF",
                      color: "#DFE6E9",
                    }}
                    disabled
                    value={renderGender()}
                  ></Input>
                </div>
                <div style={{ width: "59%" }}>
                  <label className="form-label text-white">Date of Birth</label>
                  <Input
                    size="large"
                    style={{
                      backgroundColor: "#003153",
                      border: "1px solid #9FB2BF",
                      color: "#DFE6E9",
                    }}
                    disabled
                    value={state.dob}
                  ></Input>
                </div>
              </Col>
            </Row>
            <Row className="my-4">
              <h2 style={{ fontWeight: 600, margin: 0, marginRight: "0.2rem" }}>
                Address
              </h2>
              <button
                onClick={() => editAddressHandler()}
                className="showmore-button"
              >
                Edit
              </button>
            </Row>
            <Row
              style={{ borderBottom: "1px solid #356078" }}
              className="d-flex justify-content-between my-3"
            >
              <label className="form-label text-white m-0 pb-2">
                Building No. / Name
              </label>
              <p className="m-0">{state.address1}</p>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <Col
                className="d-flex justify-content-between"
                style={{ width: "45%", borderBottom: "1px solid #356078" }}
              >
                <label className="form-label text-white m-0 pb-2">City:</label>
                <p className="m-0">{state.city}</p>
              </Col>
              <Col
                className="d-flex justify-content-between"
                style={{ width: "50%", borderBottom: "1px solid #356078" }}
              >
                <label className="form-label text-white m-0 pb-2">State</label>
                <p className="m-0">{state.state}</p>
              </Col>
            </Row>
            <Row className="d-flex justify-content-between my-3">
              <Col
                className="d-flex justify-content-between"
                style={{ width: "45%" }}
              >
                <label className="form-label text-white m-0">Postal Code</label>
                <p className="m-0">{state.zip}</p>
              </Col>
              <Col
                className="d-flex justify-content-between"
                style={{ width: "50%" }}
              >
                <label className="form-label text-white m-0">Country</label>
                <p className="m-0">{state.country}</p>
              </Col>
            </Row>
            <Row className="my-4">
              <h2 style={{ fontWeight: 600 }}>Contact Details</h2>
            </Row>
            <Row className="d-flex justify-content-between">
              <Col style={{ width: "45%" }}>
                <label className="form-label text-white">Mobile Number</label>
                <div className="d-flex">
                  <Input
                    size="large"
                    style={{
                      backgroundColor: "#184562",
                      border: 0,
                      color: "#849DAB",
                    }}
                    disabled
                    value={"+" + state.mobilePhoneCode + "-" + state.mobileNo}
                  ></Input>
                  <button
                    onClick={() =>
                      setState({
                        _isShowContactEditModel: true,
                        editContactTab: "1",
                      })
                    }
                    className="showmore-button"
                  >
                    Edit
                  </button>
                </div>
              </Col>
              <Col style={{ width: "50%" }}>
                <label className="form-label  text-white">Phone Number</label>
                <div className="d-flex">
                  <Input
                    size="large"
                    style={{
                      backgroundColor: "#184562",
                      border: 0,
                      color: "#849DAB",
                    }}
                    disabled
                    value={state.phoneNo}
                  ></Input>
                  <button
                    onClick={() =>
                      setState({
                        _isEditPhoneModal: true,
                      })
                    }
                    className="showmore-button"
                  >
                    Edit
                  </button>
                </div>
              </Col>
            </Row>
            <Row className="d-flex justify-content-end">
              <button
                style={{ width: "10rem", fontWeight: 700 }}
                className="mt-5 btn btn-sm btn-light text-primary"
                onClick={() => Navigate("/new-transaction")}
              >
                Done
              </button>
            </Row>
          </div>
          {state._isShowContactEditModel && (
            <EditContactBox
              state={state}
              setState={setState}
              sendOTP={sendOTP}
              editSenderContactdtls={editSenderContactdtls}
              loader={loader}
            />
          )}
          {state._isShowAddressEditModel && (
            <EditAddressBox
              state={state}
              setState={setState}
              sendOTP={sendOTP}
              loader={loader}
              onSelectStateHandler={onSelectStateHandler}
            />
          )}
          {state._isEditPhoneModal && (
            <Modal
              centered
              className="primary"
              width={450}
              visible={state._isEditPhoneModal}
              onCancel={() => setState({ _isEditPhoneModal: false })}
              footer={null}
            >
              <Form form={form} onFinish={onFinish}>
                <Spin spinning={loader}>
                  <div className="p-0 mb-4">
                    <h4 className="text-white">Contact details</h4>
                  </div>
                  <div className="row justify-content-center">
                    <div className="col-12 col-md-4">
                      <label className="form-label">Country Code</label>
                      <Form.Item
                        className="form-item"
                        name="phoneCountryCode"
                        rules={[
                          {
                            required: true,
                            message: "Please select your Country Code.",
                          },
                        ]}
                      >
                        <Select
                          size="large"
                          className="w-100"
                          placeholder="Select Country Code"
                          showSearch
                          optionFilterProp="children"
                          // onSelect={(v) =>
                          //   setState({ editablemobilePhoneCode: v })
                          // }
                        >
                          {state.phoneCodes.map((list, i) => {
                            return (
                              <Select.Option
                                key={i}
                                value={list.countryPhoneCode}
                              >
                                {list.countryPhoneCode} ( {list.countryName})
                              </Select.Option>
                            );
                          })}
                        </Select>
                      </Form.Item>
                    </div>
                    <div className="col-12 col-md-8">
                      <label className="form-label">Phone Number</label>
                      <Form.Item
                        className="form-item"
                        name="phoneNo"
                        rules={[
                          {
                            min: 10,
                            max: 12,
                            message:
                              "Mobile number should be between 10 to 12 digits.",
                          },
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      >
                        <Input
                          // onChange={(e) => setState({ phoneNo: e.target.value })}
                          size="large"
                          placeholder="Enter your Phone Number"
                        />
                      </Form.Item>
                    </div>
                  </div>
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button
                      className="btn btn-danger btn-block btn-sm px-4"
                      onClick={() => setState({ _isEditPhoneModal: false })}
                      type="button"
                    >
                      Cancel
                    </button>
                    <button className="btn btn-secondary btn-sm px-4">
                      Submit
                    </button>
                  </div>
                </Spin>
              </Form>
            </Modal>
          )}
          <KYCModal
            getProfile={getProfile}
            isModalVisible={isModalVisible}
            setIsModalVisible={setIsModalVisible}
          />
        </div>
      </Spin>
    </>
  );
}

export default Profile2;
