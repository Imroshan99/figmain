import React, { useEffect, useReducer, useState } from "react";
import { config } from "../../../../config";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import { useSelector } from "react-redux";
import DefaultLayout from "../../layout/DefaultLayout";
import { encrypt, decrypt, publickey } from "../../../../helpers/makeHash";
import { Collapse, Row, Col, notification, Spin } from "antd";
import EditMarketingBox from "../../../../containers/EditMarketingBox";
import OTPBox from "../../../../containers/OTPBox";
import { GuestAPI } from "../../../../apis/GuestAPI";
import useHttp from "../../../../hooks/useHttp";
import { Tabs } from "antd";
import SubHeader from "../../layout/SubHeader";
import EditAddressBox from "../../containers/EditAddressBox";
import EditContactBox from "../../containers/EditContactBox";

const { TabPane } = Tabs;
const { Panel } = Collapse;

function Profile(props) {
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const [loader, setLoader] = useState(false);

  const profileConfig = ConfigReducer.groupIdSettings.profileModule;
  // alert(profileConfig.twoFA)
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      twofa: profileConfig.twoFA,
      firstName: "",
      middleName: "",
      lastName: "",
      emailId: "",
      dob: "",
      editableMobileNo: "",
      editablemobilePhoneCode: "",
      mobilePhoneCode: "",
      mobileNo: "",
      gender: "",
      citizenship: "",
      citizenshipDesc: "",
      nationality_id: "",
      nationalityDesc: "",
      occupation_id: "",
      occupationDesc: "",
      profession_id: "",
      professionDesc: "",
      isSameCommAddressFlag: "",
      marketCommunication: "",
      address1: "",
      address3: "",
      city: "",
      state: "",
      country: AuthReducer.sendCountryCode,
      zip: "",
      income_id: "",
      incomeDesc: "",
      countryPhoneCodes: [],
      occupationLists: [],
      professionLists: [],
      incomeLists: [],
      _isShowAddressEditModel: false,
      _isShowContactEditModel: false,
      _isShowMarketingEditModel: false,
      _isShowAddressOTPBOX: false,
      _isShowContactOTPBOX: false,
      _isShowMarketingOTPBOX: false,
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      citizenshipLists: [],
      senderContactDetailsErrors: [],
      stateLists: [],
      cityLists: [],
      newStateList: [],
      // formSubmit: false,
    }
  );

  const hookGetProfile = useHttp(ProfileAPI.getProfile);
  const hookGetIncomeLists = useHttp(ProfileAPI.incomeLists);
  const hookSendOTP = useHttp(ProfileAPI.sendOTP);
  const hookEditProfile = useHttp(ProfileAPI.editProfile);
  const hookEditSenderContactdtls = useHttp(ProfileAPI.editSenderContactdtls);
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetOccupationLists = useHttp(GuestAPI.occupationLists);
  const hookGetProfessionLists = useHttp(GuestAPI.professionLists);
  const hookGetCitizenshipLists = useHttp(GuestAPI.citizenshipLists);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);

  useEffect(async () => {
    getProfile();
    countryPhoneCodes();
    incomeLists();
    occupationLists();
    professionLists();
    citizenshipLists();
    getStateLists();
  }, []);

  const getProfile = () => {
    setLoader(true);
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetProfile.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setLoader(false);
        setState({
          firstName: data.firstName,
          middleName: data.middleName,
          lastName: data.lastName,
          emailId: data.emailId,
          dob: data.dob,
          mobileNo: data.mobileNo,
          gender: data.gender,
          mobilePhoneCode: data.mobilePhoneCode,
          citizenship: data.citizenship,
          citizenshipDesc: data.citizenshipDesc,
          nationality_id: data.nationality,
          nationalityDesc: data.nationalityDesc,
          occupation_id: data.occupation,
          occupationDesc: data.occupationDesc,
          profession_id: data.profession,
          professionDesc: data.professionDesc,
          address1: data.address1,
          address3: data.address3,
          city: data.city,
          state: data.state,
          zip: data.zip,
          income_id: data.income,
          incomeDesc: data.incomeDesc,
          isSameCommAddressFlag: data.isSameCommAddressFlag,
          marketCommunication: data.marketCommunication,
        });
      } else {
        setLoader(false);
      }
    });
  };
  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.sendCountryCode,
      keyword: "",
    };

    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        const newStateList = [
          ...data.responseData,
          {
            stateCode: "OTHER",
            state: "Other",
          },
        ];
        setState({ newStateList: newStateList });
      }
    });
  };
  const onSelectStateHandler = async (stateCode) => {
    const cityPayload = {
      requestType: "CITILIST",
      countryCode: AuthReducer.sendCountryCode,
      stateCode: stateCode,
    };

    hookGetStateCities.sendRequest(cityPayload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
      }
    });
  };

  const citizenshipLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCitizenshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ citizenshipLists: data.responseData });
      }
    });
  };
  const countryPhoneCodes = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetCountryPhoenCodes.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
      }
    });
  };

  const occupationLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetOccupationLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ occupationLists: data.responseData });
      }
    });
  };

  const professionLists = () => {
    let payload = {
      requestType: "LEAD",
    };

    hookGetProfessionLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ professionLists: data.responseData });
      }
    });
  };

  const incomeLists = () => {
    let payload = {
      requestType: "LEAD",
      userId: state.userID,
    };

    hookGetIncomeLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ incomeLists: data.responseData });
      }
    });
  };

  const sendOTP = (otpType, otpFor) => {
    const OTPData = {
      requestType: "SENDOTP",
      mobilePhoneCode: state.mobilePhoneCode,
      mobileNo:
        state.editableMobileNo == "" ? state.mobileNo : state.editableMobileNo,
      emailId: state.emailId,
      otpType: otpType,
      senderName: "",
      // userId: otpFor == "Edit_Contact" ? undefined : state.userID,
      userId: state.userID,
    };

    hookSendOTP.sendRequest(OTPData, function (data) {
      if (data.status == "S") {
        setState({
          verificationToken: data.verificationToken,
        });
        setTimeout(() => {
          if (otpFor == "Edit_Address") {
            setState({
              _isShowAddressOTPBOX: true,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Contact") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: true,
              _isShowMarketingOTPBOX: false,
              isModalVisible: true,
            });
          } else if (otpFor == "Edit_Marketing") {
            setState({
              _isShowAddressOTPBOX: false,
              _isShowContactOTPBOX: false,
              _isShowMarketingOTPBOX: true,
              isModalVisible: true,
            });
          }
        }, 100);
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };

  const editProfile = (verifiedToken) => {
    setLoader(true);
    const editProfileData = {
      requestType: "EDITPROFILE",
      SIN: undefined,
      address1: window.btoa(state.address1),
      address2: "",
      address3: window.btoa(state.address3),
      address4: "",
      address5: "",
      citizenship: state.citizenship,
      city: window.btoa(state.city),
      commAddress1: "",
      commAddress2: "",
      commCity: "",
      commCountry: "",
      commPostalCode: "",
      commStateProvince: "",
      companyName: "",
      dob: state.dob,
      gender: state.gender,
      homePhoneNo: "",
      income: state.income_id,
      industry: "",
      periodicUpdate: state.isSameCommAddressFlag,
      isSameCommAddressFlag: state.isSameCommAddressFlag,
      marketCommunication: state.marketCommunication,
      motherMaidenName: "",
      nationality: state.nationality_id,
      occupation: state.occupation_id,
      pageName: "EDITPROFILE",
      pep: "",
      primaryBusinessFunction: "",
      profession: state.profession_id === "" ? "1" : state.profession_id,
      salutation: "",
      sendCountry: AuthReducer.sendCountryCode,
      state: window.btoa(state.state),
      tnc: "",
      zipCode: state.zip,
      userId: state.userID,
    };

    hookEditProfile.sendRequest(editProfileData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
        });
        notification.success({ message: data.message });
      } else {
        setLoader(false);
        setState({
          isModalVisible: false,
        });
        notification.error({ message: data.errorMessage });
      }
      getProfile();
    });
  };

  const editSenderContactdtls = (verifiedToken) => {
    setLoader(true);
    const contactData = {
      requestType: "editContactProfile",
      areaCode: "",
      emailId: state.emailId,
      mobilePhoneCode: state.mobilePhoneCode,
      mobileNo: state.editableMobileNo,
      phoneNo: "",
      sendCountryCode: AuthReducer.sendCountryCode,
      verifiedToken: verifiedToken,
      userId: state.userID,
      twofa: state.twofa, //for otp
    };

    hookEditSenderContactdtls.sendRequest(contactData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        setState({
          _isShowAddressEditModel: false,
          _isShowContactEditModel: false,
          _isShowMarketingEditModel: false,
          _isShowAddressOTPBOX: false,
          _isShowContactOTPBOX: false,
          _isShowMarketingOTPBOX: false,
          isModalVisible: false,
          mobilePhoneCode: state.editablemobilePhoneCode,
          mobileNo: state.editableMobileNo,
          editablemobilePhoneCode: "",
          editableMobileNo: "",
        });
        notification.success({ message: data.message });
      } else {
        setLoader(false);
        setState({
          isModalVisible: false,
        });

        notification.error({ message: data.errorMessage });
        setState({
          senderContactDetailsErrors: data.errorList,
        });
      }
      getProfile();
    });
  };

  const renderGender = () => {
    if (state.gender === "M") {
      return "Male";
    } else if (state.gender === "F") {
      return "Female";
    } else {
      return state.gender;
    }
  };

  return (
    <>
      <SubHeader title="Profile" />
      <Spin spinning={loader}>
        <div className="profile-container template2__main">
          <div className="container">
            <div className="sendmoney__page">
              <Tabs defaultActiveKey="1" size="large">
                <TabPane tab="Personal Information" key="1">
                  <div className="mt-5">
                    <Row justify="space-between">
                      <Col span={12}>
                        <h6 className="text-white">First Name</h6>
                        <p>{state.firstName}</p>
                      </Col>
                      <Col span={12}>
                        <h6 className="text-white text-end">Last Name</h6>
                        <p className="text-end">{state.lastName}</p>
                      </Col>
                    </Row>
                    <Row justify="space-between">
                      <Col span={12}>
                        <h6 className="text-white">Date Of Birth</h6>
                        <p>{state.dob}</p>
                      </Col>
                      <Col span={12}>
                        <h6 className="text-white text-end">Gender</h6>
                        <p className="text-end ">{renderGender()}</p>
                      </Col>
                    </Row>
                  </div>
                </TabPane>
                <TabPane tab="Current Address" key="2">
                  <div className="mt-5">
                    <Row justify="space-between">
                      <Col span={12} className="d-block">
                        <h6 className="text-white">Country</h6>
                        <p>{state.country}</p>
                      </Col>
                      <Col span={12} className="text-end ">
                        <h6 className="text-white">District</h6>
                        <p>{state.state} </p>
                      </Col>
                    </Row>
                    <Row justify="space-between">
                      <Col span={12} className="d-block">
                        <h6 className="text-white">Address</h6>
                        <p>{state.address1}</p>
                      </Col>
                      <Col span={12} className="text-end ">
                        <h6 className="text-white">Citizenship</h6>
                        <p>{state.citizenshipDesc}</p>
                      </Col>
                    </Row>
                    <Row justify="space-between">
                      {/* <Col span={12} className="d-block">
                  <h6>House/ Building Name</h6>
                  <p>{state.address3}</p>
                </Col> */}
                      {/* <Col span={24} className="text-end ">
                  <h6>Citizenship</h6>
                  <p>{state.citizenshipDesc}</p>
                </Col> */}
                    </Row>
                    {/* <Row justify="space-between">
                <Col span={12} className="d-block">
                  <h6>Street Name</h6>
                  <p>{state.address1}</p>
                </Col>
                <Col span={12} className="text-end ">
                  <h6>Annual Income</h6>
                  <p>{state.incomeDesc}</p>
                </Col>
              </Row> */}

                    <Row justify="space-between">
                      <Col span={12} className="d-block">
                        <h6 className="text-white">Post Town</h6>
                        <p>{state.city}</p>
                      </Col>
                      <Col span={12} className="text-end ">
                        <h6 className="text-white">Postcode</h6>
                        <p>{state.zip}</p>
                      </Col>
                    </Row>
                    <Row justify="space-between">
                      <Col span={12} className="d-block">
                        <h6 className="text-white">Occupation</h6>
                        <p>{state.occupationDesc}</p>
                      </Col>
                      {/* <Col span={12} className="text-end ">
                  <h6>Employment Status</h6>
                  <p>{state.professionDesc}</p>
                </Col> */}
                    </Row>

                    <Row justify="space-between">
                      <Col span={12}></Col>
                      <Col className="d-flex justify-content-end" span={12}>
                        <button
                          className="btn btn-secondary text-white btn-sm px-5 my-4"
                          onClick={() =>
                            setState({ _isShowAddressEditModel: true })
                          }
                        >
                          Edit
                        </button>
                      </Col>
                    </Row>
                  </div>
                </TabPane>
                <TabPane tab="Contact details" key="3">
                  <div className="mt-5">
                    <Row justify="space-between">
                      <Col span={12}>
                        <h6 className="text-white">Country Code</h6>
                        <p>+{state.mobilePhoneCode}</p>
                      </Col>
                      <Col span={12}>
                        <h6 className="text-white text-end">Mobile</h6>
                        <p className="text-end">{state.mobileNo}</p>
                      </Col>
                    </Row>
                    <Row justify="space-between">
                      <Col span={12}>
                        <h6 className="text-white">Communication Email ID</h6>
                        <p>{state.emailId}</p>
                      </Col>
                    </Row>

                    <Row justify="space-between">
                      <Col span={12}></Col>
                      <Col className="d-flex justify-content-end" span={12}>
                        <button
                          className="btn btn-secondary text-white btn-sm px-5  my-4"
                          onClick={() =>
                            setState({ _isShowContactEditModel: true })
                          }
                        >
                          Edit
                        </button>
                      </Col>
                    </Row>
                  </div>
                </TabPane>
                <TabPane tab="Account Details" key="4">
                  <div className="mt-5">
                    <Row justify="space-between">
                      <Col span={24}>
                        <h6 className="text-white">User ID</h6>
                        <p>{state.emailId}</p>
                      </Col>
                    </Row>
                  </div>
                </TabPane>
              </Tabs>
              {state._isShowAddressEditModel && (
                <EditAddressBox
                  state={state}
                  setState={setState}
                  sendOTP={sendOTP}
                  editProfile={editProfile}
                  loader={loader}
                  onSelectStateHandler={onSelectStateHandler}
                />
              )}
              {state._isShowAddressOTPBOX && (
                <OTPBox
                  state={state}
                  setState={setState}
                  otpType="EP"
                  useFor="Edit_Address"
                  appState={props.appState}
                  editProfile={editProfile}
                />
              )}
              {state._isShowContactEditModel && (
                <EditContactBox
                  state={state}
                  setState={setState}
                  sendOTP={sendOTP}
                  editSenderContactdtls={editSenderContactdtls}
                  loader={loader}
                />
              )}
              {state._isShowContactOTPBOX && (
                <OTPBox
                  state={state}
                  setState={setState}
                  otpType="CU"
                  useFor="Edit_Contact"
                  appState={props.appState}
                  editSenderContactdtls={editSenderContactdtls}
                />
              )}
              {state._isShowMarketingEditModel && (
                <EditMarketingBox
                  state={state}
                  setState={setState}
                  sendOTP={sendOTP}
                />
              )}
              {state._isShowMarketingOTPBOX && (
                <OTPBox
                  state={state}
                  setState={setState}
                  otpType="EP"
                  useFor="Edit_Marketing"
                  appState={props.appState}
                  editProfile={editProfile}
                />
              )}
            </div>
          </div>
        </div>
      </Spin>
    </>
  );
}

export default Profile;
