import { Route, Routes } from "react-router-dom";
import Header from "./layout/Header";
import ChangePassword from "./user/profile/ChangePassword";
import RecipientList from "./user/recipient/RecipientList";
import TranctionAction from "./user/sendmoney/TranctionAction";
import TransactionList from "./user/sendmoney/TransactionList";
import BankAccountList from "./user/bankaccounts/CIP/BankAccountList";
import CookiePolicy from "./pages/Cookie";
import FAQ from "./pages/faq";
import TnC from "./pages/Terms";
import PrivacyPolicy from "./pages/Privacy";
import Regulations from "./pages/Regulations";
import TrackMoneyTransfer from "./user/sendmoney/TrackMoneyTransfer";
import ReferUs from "./user/referus/ReferUs";

import KycPage from "./auth/KYC";
import { PrivateRoute } from "./../../Routes/PrivateRoute";
import Notification from "./user/Notification";
import Profile from "./user/profile/Profile2";
import SofortSuccess from "./pages/SofortSuccess";
import SofortFail from "./pages/SofortFail";
import SofortTimeout from "./pages/SofortTimeout";
import SofortTranscationSuccess from "./user/sendmoney/Stepper/SofortTranscationSuccess";

export default function Dashboard({ appState }) {
  return (
    <>
      {/* <Header appState={appState} /> */}
      <Routes>
        <Route element={<Header appState={appState} />}>
          <Route
            path="new-transaction"
            element={
              <PrivateRoute>
                <TranctionAction appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="my-recipient"
            element={
              <PrivateRoute>
                <RecipientList appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="my-transaction"
            element={
              <PrivateRoute>
                <TransactionList appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="my-refer-us"
            element={
              <PrivateRoute>
                <ReferUs appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="/track-money-transfer"
            element={
              <PrivateRoute>
                <TrackMoneyTransfer appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="notifications"
            element={
              <PrivateRoute>
                <Notification appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="profile"
            element={
              <PrivateRoute>
                <Profile appState={appState} />
              </PrivateRoute>
            }
          />
          <Route path="test" element={<div>abc</div>} />
          <Route
            path="/change-password"
            element={
              <PrivateRoute>
                <ChangePassword appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="/my-bank-accounts"
            element={
              <PrivateRoute>
                <BankAccountList appState={appState} />
              </PrivateRoute>
            }
          />
          <Route
            path="/sofort-transcation-success"
            element={
              <PrivateRoute>
                <SofortTranscationSuccess appState={appState} />
              </PrivateRoute>
            }
          />
          {/* <Route path="request-money" element={<NewTransaction />} /> */}
          {/* <Route path="/kyc" element={<UpdateKyc appState={appState} />}/> */}
          <Route path="/kyc" element={<KycPage appState={appState} />} />

          <Route path={"/terms-and-conditions"} element={<TnC />} />
          <Route path="/faq" element={<FAQ />} />
          <Route path={"/cookie-policy"} element={<CookiePolicy />} />
          <Route path={"/regulations"} element={<Regulations />} />
          <Route path={"/privacy-policy"} element={<PrivacyPolicy />} />
          <Route path="/sofort-success" element={<SofortSuccess />} />
          <Route path="/sofort-failed" element={<SofortFail />} />
          <Route path="/sofort-timeout" element={<SofortTimeout />} />
        </Route>
      </Routes>
    </>
  );
}
