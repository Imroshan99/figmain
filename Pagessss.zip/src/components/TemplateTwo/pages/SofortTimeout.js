import { useEffect } from "react";
import { useSearchParams } from "react-router-dom";
import SubHeader from "../layout/SubHeader";

export default function SofortTimeout() {
  const [searchParams, setSearchParams] = useSearchParams();
  const transId = searchParams.get("transId");
  useEffect(() => {
    window.localStorage.setItem(transId, "TIMEOUT");
    window.close("", "_parent", "");
  }, []);

  const onClickWindowCloseHandler = () => {
    window.close("", "_parent", "");
  };
  return (
    <div>
      <SubHeader title="Transaction Timeout." />
      <div className="text-center">
        <button
          className="btn btn-primary text-light mt-5"
          onClick={onClickWindowCloseHandler}
        >
          close window
        </button>
      </div>
    </div>
  );
}
