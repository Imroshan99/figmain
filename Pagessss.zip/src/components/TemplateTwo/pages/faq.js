import React from "react";
import SubHeader from "../layout/SubHeader";
import FAQPage from "../../../pages/FAQ/";
import { Footer } from "../../../pages/LandingPage/XR";

const FAQ = (props) => {
  return (
    <React.Fragment>
      <SubHeader title="Frequently Asked Questions" />
      <div className="template2__main py-5">
        <div className="sendmoney__page">
          <div className="container">
              <FAQPage />
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
};

export default FAQ;
