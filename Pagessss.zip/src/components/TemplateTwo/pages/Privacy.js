import React from "react";
import SubHeader from "../layout/SubHeader";
import PrivacyPolicyPage from "../../../pages/PrivacyPolicy";
import { Footer } from "../../../pages/LandingPage/XR";

const PrivacyPolicy = (props) => {
  return (
    <React.Fragment>
      <SubHeader title="Privacy Policy" />
      <div className="template2__main py-5">
        <div className="sendmoney__page">
          <div className="container">
            <PrivacyPolicyPage />
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
};

export default PrivacyPolicy;
