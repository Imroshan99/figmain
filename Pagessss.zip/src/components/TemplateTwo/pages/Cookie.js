import React from "react";
import SubHeader from "../layout/SubHeader";
import CookiePolicyPage from "../../../pages/CookiePolicy/";
import { Footer } from "../../../pages/LandingPage/XR";

const Cookie = (props) => {
  return (
    <React.Fragment>
      <SubHeader title="Cookie Policy" />
      <div className="template2__main py-5">
        <div className="sendmoney__page">
          <div className="container">
            <CookiePolicyPage />
          </div>
        </div>
      </div>
      <Footer />
    </React.Fragment>
  );
};

export default Cookie;
