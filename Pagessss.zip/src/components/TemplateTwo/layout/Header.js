import React, { useState, useEffect, useReducer } from "react";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";
import Box from "@mui/material/Box";
import PermIdentityOutlinedIcon from "@mui/icons-material/PermIdentityOutlined";
import NotificationsNoneOutlinedIcon from "@mui/icons-material/NotificationsNoneOutlined";
import IconButton from "@mui/material/IconButton";
import Avatar from "@mui/material/Avatar";
import Button from "@mui/material/Button";
import { ProfileAPI } from "../../../apis/ProfileAPI";
import { notification } from "antd";
import { useSelector } from "react-redux";
import { NavLink } from "react-router-dom";
import useHttp from "../../../hooks/useHttp";
import NotificationMenu from "../user/NotificationMenu";
import UserMenu from "../user/UserMenu";


const pages = [
  {
    label: "Send Money",
    link: "/new-transaction",
    isLoginRequired: true,
  },
  // {
  //   label: "Support",
  //   link: "/",
  //   isLoginRequired: false,
  // },
  {
    label: "FAQs",
    link: "/faq",
    isLoginRequired: false,
  },
];

function stringToColor(string) {
  let hash = 0;
  let i;

  /* eslint-disable no-bitwise */
  for (i = 0; i < string.length; i += 1) {
    hash = string.charCodeAt(i) + ((hash << 5) - hash);
  }

  let color = "#";

  for (i = 0; i < 3; i += 1) {
    const value = (hash >> (i * 8)) & 0xff;
    color += `00${value.toString(16)}`.slice(-2);
  }
  /* eslint-enable no-bitwise */

  return color;
}
function stringAvatar(name) {
  let nameAr = name.split(" ");
  let nm = "";
  if (nameAr.length > 1) {
    nm = `${name.split(" ")[0][0]}${name.split(" ")[1][0]}`;
  } else {
    nm = `${name.split(" ")[0][0]}`;
  }
  return {
    sx: {
      bgcolor: stringToColor(name),
    },
    children: nm,
  };
}
export default function Header(props) {
  let navigate = useNavigate();
  let location = useLocation();

  const AuthReducer = useSelector((state) => state);
  const [anchorElNav, setAnchorElNav] = useState(null);
  const [anchorElUser, setAnchorElUser] = useState(null);
  const [anchorElNoti, setAnchorElNoti] = useState(null);
  const [notificationMenu, setNotificationMenu] = useState(false);
  const [notificationLoader, setNotificationLoader] = useState(false);
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      firstName: "",
      lastName: "",
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      notificationList: [],
    }
  );
  const hookProfileApi = useHttp(ProfileAPI.getProfile);
  const hookNotificationList = useHttp(ProfileAPI.notificationLists);

  useEffect(async () => {
    if (props.appState.isLoggedIn) {
      getProfileHandler();
      getNotificationList();
    }
  }, [props.appState.isLoggedIn]);

  const getProfileHandler = () => {
    let payload = {
      requestType: "GETPROFILE",
      userId: AuthReducer.userID,
    };
    hookProfileApi.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setState({
          firstName: data.firstName,
          lastName: data.lastName,
        });
      } else {
        notification.error({ message: data.errorMessage });
      }
    });
  };
  const getNotificationList = () => {
    let payload = {
      requestType: "NOTIFICATIONLISTS",
      userId: AuthReducer.userID,
    };
    setNotificationLoader(true);
    hookNotificationList.sendRequest(payload, (data) => {
      if (data.status == "S") {
        setState({ notificationList: data.responseData });
        setNotificationLoader(false);
      } else {
        // notification.error({ message: data.errorMessage });
        setNotificationLoader(false);
      }
    });
  };
  const handleOpenNavMenu = (event) => {
    setAnchorElNav(event.currentTarget);
  };
  const handleOpenUserMenu = (event) => {
    setAnchorElUser(event.currentTarget);
  };
  const handleCloseNavMenu = () => {
    setAnchorElNav(null);
  };
  const handleOpenNotiMenu = (event) => {
    setAnchorElNoti(event.currentTarget);
    setNotificationMenu(true);
  };
  const handleCloseNotiMenu = () => {
    setAnchorElNoti(null);
    setNotificationMenu(false);
  };
  const handleCloseUserMenu = (e) => {
    setAnchorElUser(null);
    if (e === "Logout") {
      window.location.href = "/";
    }
  };

  return (
    <>
      <header className="header">
        <div className="container pt-4">
          <div class="row">
            <div className="col-auto">
              <h2 className="logo-text mb-0">
                <Link to="/"><img
                  src={require("../../../assets/images/logos/" +
                    AuthReducer.groupId +
                    "_dark_logo.svg")}
                  height="40px"
                /></Link>
              </h2>
            </div>
            <div className="col d-flex justify-content-end text-end">
              {AuthReducer.isLoggedIn == true && (
                <>
                  <Box
                    sx={{ flexGrow: 1, display: { xs: "none", md: "flex" } }}
                    style={{
                      justifyContent: "end",
                    }}
                  >
                    {pages.map((page) => (
                      <Button
                        key={page.link}
                        onClick={handleCloseNavMenu}
                        sx={{ color: "white", display: "block" }}
                      >
                        <NavLink className="template2_nav" to={page.link}>
                          {page.label}
                        </NavLink>
                      </Button>
                    ))}
                  </Box>

                  <Box sx={{ flexGrow: 0 }} justifyContent={"end"}>
                    {/* Notification Button disabled till product team reverts */}
                    <IconButton
                      className="me-2"
                      onClick={handleOpenNotiMenu}
                      sx={{ p: 0 }}
                    >
                      <Avatar>
                        <NotificationsNoneOutlinedIcon />
                      </Avatar>
                    </IconButton>
                    {notificationMenu && (
                      <NotificationMenu
                        state={state}
                        anchorElNoti={anchorElNoti}
                        setAnchorElNoti={setAnchorElNoti}
                        handleCloseNotiMenu={handleCloseNotiMenu}
                        notificationLoader={notificationLoader}
                      />
                    )}

                    <IconButton onClick={handleOpenUserMenu} sx={{ p: 0 }}>
                      <Avatar
                        alt={AuthReducer.userFullName}
                        // {...stringAvatar(AuthReducer.userFullName)}
                      >
                        <PermIdentityOutlinedIcon />
                      </Avatar>
                    </IconButton>
                    <UserMenu
                      anchorElUser={anchorElUser}
                      handleCloseUserMenu={handleCloseUserMenu}
                    />
                  </Box>
                </>
              )}

              {/* <Box
                sx={{ flexGrow: 1, display: { xs: "flex", md: "none" } }}
                style={{
                  justifyContent: "end",
                }}
              >
                <IconButton
                  size="large"
                  aria-label="account of current user"
                  aria-controls="menu-appbar"
                  aria-haspopup="true"
                  onClick={handleOpenNavMenu}
                  color="inherit"
                >
                  <MenuIcon />
                </IconButton>
                <Menu
                  id="menu-appbar"
                  anchorEl={anchorElNav}
                  anchorOrigin={{
                    vertical: "bottom",
                    horizontal: "left",
                  }}
                  keepMounted
                  transformOrigin={{
                    vertical: "top",
                    horizontal: "left",
                  }}
                  open={Boolean(anchorElNav)}
                  onClose={handleCloseNavMenu}
                  sx={{
                    display: { xs: "block", md: "none" },
                  }}
                >
                  {pages.map((page) => (
                    <MenuItem
                      key={`_${page.link}`}
                      onClick={handleCloseNavMenu}
                    >
                      
                      <NavLink to={page.link}>{page.label}</NavLink>
                    </MenuItem>
                  ))}
                </Menu>
              </Box> */}
            </div>
          </div>
          {/* {props.appState.isLoggedIn == true && (
            <SubHeader appState={props.appState} />
          )} */}
        </div>
      </header>
      <Outlet />
    </>
  );
}
