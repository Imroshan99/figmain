import React, { useState, useEffect, useReducer } from "react";
import { useNavigate } from "react-router-dom";
import { Form, Input, DatePicker, notification, Spin } from "antd";
import moment from "moment";
import { AuthAPI } from "../../../apis/AuthAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../hooks/useHttp";
import LogoXmonies from "../layout/LogoXmonies";
import InputOTPBox from "../../../containers/InputOTPBox";

export default function UnlockAccount(props) {
  let navigate = useNavigate();

  const ConfigReducer = useSelector((state) => state);

  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const [current, setCurrent] = React.useState(0);
  const [loading, setLoader] = useState(false);
  const [parentLoader, setParentLoader] = useState(false);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      twofa: ConfigReducer.twofa,
      formData: {},
      dob: "",
      loginId: "",
      _isShowOTPBOX: false,
      otpType: "UL",
    }
  );

  const hookUnlockUserid = useHttp(AuthAPI.unlockUserid);
  const hookUnlockAccount = useHttp(AuthAPI.unlockAccount);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const unlockUserIdHandler = (value) => {
    setState({
      loginId: value.loginId,
    });

    let unlockUseridPayload = {
      requestType: "UNLOCKUSERID",
      loginId: value.loginId,
      dob: state.dob,
      verifyType: value.verifyType,
    };

    setLoader(true);
    hookUnlockUserid.sendRequest(unlockUseridPayload, function (data) {
      if (data.status == "S") {
        if (value.verifyType === "O") {
          setState({ verificationToken: data.verificationToken });
          if (state.twofa == "N") {
            setState({
              isModalVisible: true,
              formData: value,
            });
          } else {
            setState({
              _isShowOTPBOX: true,
              isModalVisible: true,
              formData: value,
            });
            setCurrent(current + 1);
          }
        }
        if (value.verifyType === "L") {
          notification.success({ message: data.message });
          navigate("/signin");
        }
      } else {
        notification.error({ message: data.errorMessage });

        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) {
            if (value.verifyType === "O") {
              form.setFields(errors);
            }
            if (value.verifyType === "L") {
              form1.setFields(errors);
            }
          }
        }
      }
      setLoader(false);
    });
  };

  const onUnlockAccountHandler = () => {
    setParentLoader(true);
    let unlockAccountPayload = {
      requestType: "UNLOCKACCOUNT",
      loginId: state.loginId,
      dob: state.dob,
    };

    setLoader(true);
    hookUnlockAccount.sendRequest(unlockAccountPayload, function (data) {
      if (data.status == "S") {
        setParentLoader(false);
        setState({
          _isShowOTPBOX: false,
          isModalVisible: false,
        });

        notification.success({ message: data.message });
        navigate("/signin");
      } else {
        setParentLoader(false);
        setLoader(false);
        notification.error({ message: data.errorMessage });

        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) {
            form.setFields(errors);
          }
        }
      }
      setLoader(false);
    });
  };

  return (
    <div className="container-fluid __t2">
      <div className="row">
        <div className="col-12 col-md-5  p-0 ">
          <LogoXmonies />
        </div>
        <div className="col-12 col-md-7 col-xl-6 col-xxl-5 p-5 align-self-center">
          <div className="login-right">
            <div className="login-div">
              <h1 className="title mb-4">Unlock Account</h1>
              {state._isShowOTPBOX ? (
                <InputOTPBox
                  state={state}
                  setState={setState}
                  otpType={state.otpType}
                  useFor="unlock_account"
                  onUnlockAccountHandler={onUnlockAccountHandler}
                  appState={props.appState}
                  parentLoader={parentLoader}
                  setParentLoader={setParentLoader}
                  unlockA={true}
                />
              ) : (
                <div>
                  <Spin spinning={loading} delay={500}>
                    <Form
                      form={form}
                      initialValues={{ verifyType: "O" }}
                      onFinish={unlockUserIdHandler}
                    >
                      <div>
                        <p>
                          A 6 digit OTP will be sent to your registered email id
                        </p>

                        <div className="">
                          <label className="step-label  mb-1">
                            Enter User ID
                          </label>
                          <Form.Item
                            className="form-item"
                            name="loginId"
                            rules={[
                              {
                                required: true,
                                message: "Please enter user id",
                              },
                            ]}
                          >
                            <Input size="large" />
                          </Form.Item>

                          <label className="step-label  mb-1">
                            Date of Birth
                          </label>
                          <div>
                            <Form.Item
                              className="form-item"
                              name="dob"
                              rules={[
                                {
                                  required: true,
                                  message: "Please input your Date Of Birth.",
                                },
                              ]}
                            >
                              <DatePicker
                                size="large"
                                className="w-100"
                                defaultPickerValue={moment().subtract(
                                  18,
                                  "years"
                                )}
                                disabledDate={(d) =>
                                  !d ||
                                  d.isAfter(moment().subtract(18, "years")) ||
                                  d.isSameOrBefore("1900-01-01")
                                }
                                onChange={(value, dateString) => {
                                  value !== null
                                    ? setState({
                                        dob: dateString,
                                      })
                                    : setState({ dob: "" });
                                }}
                              />
                            </Form.Item>
                          </div>
                        </div>
                        <div className="d-grid">
                          <Form.Item name="verifyType" hidden={true}>
                            <Input type={"hidden"} />
                          </Form.Item>
                          <br />
                          <button className="btn btn-primary text-white">
                            {state.twofa == "Y"
                              ? "Send OTP"
                              : "Verify Without OTP"}
                          </button>
                        </div>
                      </div>
                    </Form>
                  </Spin>
                </div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
