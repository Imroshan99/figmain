import React, { useState, useEffect, useReducer } from "react";
import { Link } from "react-router-dom";
import { Dropdown, Menu, Steps } from "antd";
import { GuestAPI } from "../../../apis/GuestAPI";
import SetPassword from "./SetPassword";
import { useSelector } from "react-redux";
import LogoXmonies from "../layout/LogoXmonies";
import SignUpStep1 from "./SignUpStep1";
import SignUpStep2 from "./SignUpStep2";
import useHttp from "../../../hooks/useHttp";

const { Step } = Steps;

export default function SignUp(props) {
  const ConfigReducer = useSelector((state) => state);
  const [stepsData, setStepData] = useState({});

  const [current, setCurrent] = React.useState(0);
  const [sendCountryState, SetSendCountryState] = useState();
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      phoneCodes: [],
      sendCountryList: [],
      isModalVisible: false,
      tcModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      twofa: ConfigReducer.twofa,
      dob: "",
      formData: {},
      _isShowOTPBOX: false,
      _isShowSetPassword: false,
    }
  );
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetUserCountryList = useHttp(GuestAPI.countryList);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };

    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      if (data.status === "S") {
        setState({ phoneCodes: data.responseData });
      }
    });

    const dataCountry = {
      requestType: "SENDCOUNTRYLIST",
    };
    hookGetUserCountryList.sendRequest(dataCountry, function (data) {
      if (data.status === "S") {
        setState({ sendCountryList: data.responseData });
      }
    });
  }, []);

  const steps = [
    {
      step: 1,
      title: "Step 1",
      content: (
        <SignUpStep1
          state={state}
          setState={setState}
          setStepData={setStepData}
          setCurrent={setCurrent}
        />
      ),
    },
    {
      step: 2,
      title: "Step 2",
      content: (
        <SignUpStep2
          state={state}
          setState={setState}
          stepsData={stepsData}
          setStepData={setStepData}
          setCurrent={setCurrent}
          SetSendCountryState={SetSendCountryState}
        />
      ),
    },
    {
      step: 3,
      title: "Step 3",
      content: (
        <SetPassword
          state={state}
          setState={setState}
          appState={props.appState}
          stepsData={stepsData}
          sendCountryState={sendCountryState}
        />
      ),
    },
  ];

  const menu = (
    <Menu>
      <Menu.Item>
        <Link to="/forgot-password">Forgot Password?</Link>
      </Menu.Item>
      <Menu.Item>
        <Link to="/unlock-account">Unlock Account?</Link>
      </Menu.Item>
    </Menu>
  );

  return (
    <div className="container-fluid __t2">
      <div className="row ">
        <div className="col-12 col-md-5  p-0 ">
          <LogoXmonies />
        </div>
        <div className="col-12 col-md-7 col-xl-7 col-xxl-7 p-auto p-md-5 align-self-center overflow-auto vh-100 ">
          <div className="login-right">
            <div className="row">
              <div className="col-md-12 col-xxl-8">
                <h1 className="title mb-4">Sign Up</h1>
                <div className="signup-form">
                  <div className="step-div">
                    <>
                      <Steps
                        responsive={false}
                        size="small"
                        progressDot
                        current={current}
                        className="mb-4"
                      >
                        {steps.map((item) => (
                          <Step key={item.title} title={item.title} />
                        ))}
                      </Steps>
                      {steps.map((item) => (
                        <div
                          className={`steps-content ${
                            item.step !== current + 1 && "hidden"
                          }`}
                        >
                          {item.content}
                          {item.step != 1 && (
                            <button
                              onClick={() => {
                                setCurrent(current - 1);
                              }}
                              className={`btn btn-primary text-white my-1 w-100`}
                              type="button"
                            >
                              Back
                            </button>
                          )}
                        </div>
                      ))}
                    </>
                    <br />
                    <Link to="/signin">
                      <h6 className="text-center text-primary">
                        <strong>Return to Login</strong>
                      </h6>
                    </Link>
                    <Dropdown
                      overlay={menu}
                      trigger={["click"]}
                      placement="bottomLeft"
                      arrow
                    >
                      <p role="button" className="btn-link mt-5 text-center">
                        Problems Signing Up ?
                      </p>
                    </Dropdown>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
