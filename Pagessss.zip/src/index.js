import React, { Suspense } from "react";
import ReactDOM from "react-dom";
import "antd/dist/antd.min.css";
// import 'bootstrap/dist/css/bootstrap.min.css';
import "./assets/scss/custom.scss";
import "./assets/scss/theme.scss";
import "./index.scss";
import App from "./App";
// import setupAxios from "./setupAxios";
// import axios from "axios";
// import { CookiesProvider } from 'react-cookie';
import reportWebVitals from "./reportWebVitals";

import { Provider } from "react-redux";
import { store } from "./store";
import { Spin } from "antd";

// import store from './redux/store';

// setupAxios(axios, store)
// console.log("store", store.getState());
// composeWithDevTools use debug

const Spinner = () => {
  return (
    <div style={{ height: "100vh" }}>
      <div
        style={{
          marginTop: "250px",
          padding: "30px 50px",
          borderRadius: "4px",
          display: "flex",
          justifyContent: "center",
          alignContent: "center",
        }}
      >
        <Spin size="large" />
      </div>
    </div>
  );
};

ReactDOM.render(
  <React.StrictMode>
    {/* <CookiesProvider>
      <App />
    </CookiesProvider> */}
    <Provider store={store}>
      <Suspense fallback={<Spinner />}>
        <App />
      </Suspense>
    </Provider>
  </React.StrictMode>,
  document.getElementById("root")
);

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
