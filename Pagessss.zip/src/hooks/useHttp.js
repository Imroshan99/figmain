import axios from "axios";
import { useCallback, useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { store } from "../store";
import { config } from "../config";
import { encrypt, publickey, decrypt } from "../helpers/makeHash";
import Swal from "sweetalert2";
import log from "../services/utility/log";

export default function useHttp(axiosReq) {
  const ConfigReducer = useSelector((state) => state);
  const AuthReducer = useSelector((state) => state);
  const [isLoading, setIsLoading] = useState(false);
  const [apiData, setApiData] = useState(null);
  const [serverError, setServerError] = useState(null);

  const sendRequest = useCallback(
    async (customPaylod, response) => {
      setIsLoading(true);
      try {
        const storeData = store.getState();
        const { ___token, ..._customPaylod } = customPaylod;
        const payload = {
          requestId: config.requestId,
          channelId: config.channelId,
          clientId: ConfigReducer.clientId,
          groupId: ConfigReducer.groupId,
          sessionId: ConfigReducer.sessionId,
          ipAddress: "127.0.0.1",
          ..._customPaylod,
          // ...(true && { a: "sanjy" }),
        };
        // ------ console.log("PAYLOAD", ConfigReducer);
        if (config.IS_ENC) {
          var key = config.key;
          var iv = config.iv;

          var body = encrypt(payload, key, iv);
          var pubValue = iv.concat(key);
          var identifier = publickey(ConfigReducer.pubkey, pubValue);

          var postData = {
            body: body,
            identifier: identifier,
          };
        } else {
          var postData = payload;
        }

        const accessToken = ___token ? ___token : storeData.accessToken;

        log.message("Store ===>", store.getState());
        log.message("Hook token ===>", accessToken);
        const res = await axiosReq(postData, accessToken);

        // Encryption Decryption Logic
        if (config.IS_ENC) {
          var decode = decrypt(res.data.body, key, iv);
          var decodeData = JSON.parse(decode);
        } else {
          var decodeData = res.data;
        }

        log.message("RESPONSE ", decodeData);
        // response in callback function
        response(decodeData);
        setIsLoading(false);
      } catch (error) {
        if (error.response.status === 401) {
          Swal.fire({
            title: "Alert",
            text: error.response.data.errorMessage,
            icon: "warning",
            confirmButtonColor: "#2dbe60",
            allowOutsideClick: false,
            preConfirm: () => {
              window.location.href = "/signin";
              return false;
            },
          }).then((result) => {
            if (result.isConfirmed) {
              window.location.href = "/signin";
            }
          });
        }
        log.message("hook error status code =>", error.response.status);
        log.message("hook error =>", error);
        setServerError(error);
        setIsLoading(false);
        throw error;
      }
    },
    [axiosReq]
  );

  return { isLoading, apiData, serverError, sendRequest };
}
