import { Button } from "antd";
import { useState } from "react";

export default function PrivacyPolicy() {
  const [showMore, setShowMore] = useState(false);

  return (
    <>
      <p>
        At XMONIES, we understand the privacy, confidentiality and security of
        our esteemed customer’s personal information that resides with the
        XMONIES &amp; its products as a part of the legal and regulatory
        compliances. Keeping personal information of customers secure and using
        it solely for activities related to the legal and regulatory compliances
        and requirement to use XMONIES and preventing any misuse thereof is a
        top priority of the XMONIES. In this Policy, personal information means
        any information that relates to a natural person, which either directly
        or indirectly, in combination with other information available or likely
        to be available with the XMONIES, is capable of identifying such person.
      </p>
      <p>Applicability</p>
      <p>
        This Policy is applicable to personal information collected by XMONIES
        directly from the customer or through the XMONIES online portals
        (https://www.xmonies.com) and or mobile based application, electronic
        communications as also any information collected by the XMONIES server
        entered from the customer's browser.
      </p>
      <p>Information</p>
      <p>
        XMONIES collects, retains and uses personal information only when it
        reasonably believes that it is for a lawful purpose (as per the
        regulatory compliances’) and that it will help administer its business
        or provide products, services, and other opportunities to the visitor /
        customer. XMONIES collects three types of information: personal,
        sensitive personal data or information and non-personal.
      </p>
      {showMore && (
        <>
          <p>Personal Information</p>
          <p>
            Any information that relates to a natural person, either directly or
            indirectly, in combination with other information available is
            capable of identifying such person; Information including but not
            limited to name, address, telephone number, e-mail, occupation, etc.
          </p>
          <p>Sensitive Personal Data or Information</p>
          <p>
            Sensitive personal data or information of a person means such
            personal information which consists of information relating to
            passwords, financial information such as bank account or credit card
            or debit card or other payment instrument details, sexual
            orientation, physical physiological and mental health condition,
            medical records and history, biometric information, details of
            nominees and national identifiers including but not limited to:
            Aadhaar card, passport number, income, PAN, etc. For customers
            enrolled in services provided by XMONIES, such as online bill
            payment, personal information about the transaction is collected.
          </p>
          <p>
            Any information that is freely available or accessible in public
            domain or furnished under the Right to Information Act, 2005 or any
            other law for the time being in force shall not be regarded as
            sensitive personal data or information for the purpose of these
            rules.
          </p>
          <p>
            The information you provide online is held by XMONIES business that
            maintains your account or is processing your application for a new
            product or service.
          </p>
          <p>
            Please note that the Internet is an open system and XMONIES cannot,
            and does not, guarantee that the personal information which the
            Registered User furnishes will not be intercepted or accessed by
            others and decrypted. XMONIES, its affiliates and partners, and its
            and their respective directors, employees, agents and
            representatives shall not be liable or responsible should any
            confidential or other information provided by or pertaining to the
            Visitor (including credit card numbers, XMONIES account numbers,
            passwords, personal identification numbers, IDs, transaction
            details, and etc.) be intercepted and subsequently used by an
            unintended recipient.
          </p>
          <p>Non personal information</p>
          <p>
            This information includes the IP address of the device used to
            connect to the XMONIES’s website along with other information such
            as browser details, operating system used, the name of the website
            that redirected the visitor to the XMONIES 's website, etc. Also,
            when you browse our site or receive one of our emails, the XMONIES
            and our affiliated companies, use cookies and/or pixel tags to
            collect information and store your online preferences.
          </p>

          <p>Choice:</p>
          <p>
            Consent will be obtained from you when your information is collected
            by the XMONIES (In this case: https://www.xmonies.com ), in a manner
            recognized by law. Also, you will be informed of the choices you
            have for providing your personal information. Only information
            required for legal purposes or for providing services will be
            collected.
          </p>
          <p>
            Visitors authorize XMONIES to exchange, share, part with all
            information related to the details and transaction history of the
            Visitor to XMONIES affiliates / XMONIES s / financial institutions /
            credit bureaus / agencies/ participation in any telecommunication or
            electronic clearing network as may be required by law, customary
            practice, credit reporting, statistical analysis and credit scoring,
            verification or risk management and shall not hold XMONIES liable
            for use or disclosure of this information.
          </p>
          <p>Accuracy:</p>

          <p>
            The XMONIES has processes in place to ensure that the personal
            information residing with it is complete, accurate and current. If
            at any point of time, there is a reason to believe that personal
            information residing with the XMONIES is incorrect, the customer may
            inform the XMONIES in this regard. The XMONIES will correct the
            erroneous information as quickly as possible.
          </p>
          <p>Purpose and Usage:</p>
          <p>
            XMONIES uses the information collected and appropriately notifies
            you to manage its business and offer an enhanced, personalized
            online experience on its website. Further, it enables the XMONIES
            (&amp; remitee) to::
          </p>
          <p>• Process applications, requests and transactions.</p>
          <p>• Maintain internal records as per regulatory guidelines.</p>
          <p>
            • Provide services to customers, including responding to customer
            requests.
          </p>

          <p>• Comply with all applicable laws and regulations.</p>
          <p>• Recognize the customer when he conducts online XMONIES</p>
          <p>
            • Understand the needs and provide relevant product and service
            offers.
          </p>
          <p>Disclosure / Sharing</p>
          <p>
            XMONIES does not disclose sensitive personal data or information of
            a customer except as directed by law or as per mandate received from
            the customer. No specific information about customer accounts or
            other personally identifiable data is shared with non-affiliated
            third parties unless any of the following conditions is met:
          </p>
          <p>• To help complete a transaction initiated by XMONIES customer.</p>
          <p>
            • To perform support services through an outsourced entity provided
            it conforms to the Privacy Policy of the XMONIES.
          </p>
          <p>
            • To perform support services through an outsourced entity provided
            it conforms to the Privacy Policy of the XMONIES.
          </p>
          <p>
            • The disclosure is necessary for compliance of a legal obligation.
          </p>
          <p>
            • The information is shared with Government agencies mandated under
            law.
          </p>

          <p>
            • The information is shared with any third party by an order under
            the law.
          </p>
          <p>Security</p>
          <p>
            The security of personal information is a priority and is protected
            by maintaining physical, electronic, and procedural safeguards that
            meet applicable laws. Employees are trained in the proper handling
            of personal information. The XMONIES has internal corporate policy
            and procedures such as Grievance Redressal, Incident Management,
            Third Party Management, etc., which are available to our employees.
            When other companies are used to provide services on behalf of the
            XMONIES, it is ensured that such companies protect the
            confidentiality of personal information they receive in the same
            manner the XMONIES protects.
          </p>
          <p>Retention</p>
          <p>
            Information may be retained for a duration, required by regulatory
            clauses, or as long as required to achieve the identified (and
            notified) purpose:
          </p>
          <p>Contact Information</p>
          <p>
            In order to address any discrepancies or grievances related to the
            personal information residing with XMONIES, the customer may visit:
            http://www.bank.com/complaints-and-grievance-redressal.aspx
          </p>
          <br />
          <p>Notice of change</p>
          <p>
            XMONIES may, from time to time, change this Policy. The effective
            date of this Policy, as stated below, indicates the last time this
            Policy was revised or materially changed.
          </p>
          <p>Effective Date</p>
          <p>1st February, 2022</p>
        </>
      )}
      <button
        className="showmore-button"
        onClick={() => setShowMore(!showMore)}
      >
        {showMore ? "View Less" : "View More"}
      </button>
      
    </>
  );
}
