import { useSelector } from "react-redux";
import { Navigate } from "react-router-dom";

export const PrivateRoute = ({ auth, children }) => {
  const AuthReducer = useSelector((state) => state);
  const isAllowed = AuthReducer.isLoggedIn;
  if (!isAllowed) {
    return <Navigate to="/signin" replace />;
  }
  return children;
};
