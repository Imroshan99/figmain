import React, { useEffect, useState } from "react";
import { Form, Input, Select, Modal, Spin } from "antd";
import { config } from "../config";
import { encrypt, decrypt, publickey } from "../helpers/makeHash";
import { Row, Col } from "react-bootstrap";
import { GuestAPI } from "../apis/GuestAPI";
import { useSelector } from "react-redux";
import { inputValidations } from "../services/validations/validations";


const { Option } = Select;

export default function EditAddressBox(props) {
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const AuthReducer = useSelector((state) => state);
  const ConfigReducer = useSelector((state) => state);
  const profileConfig = ConfigReducer.groupIdSettings.profileModule;

  const [serachAddressData, setSerachAddressData] = useState([]);
  const [editAddressFormSubmit, setEditAddressFormSubmit] = useState(false);

  useEffect(() => {
    form.setFieldsValue({
      // address: props.state.address1,
      country: props.state.country,
      citizenship: props.state.citizenshipDesc,
      // houseBuildingName: props.state.,
      district: props.state.state,
      streetName: props.state.address1,
      annualIncome: props.state.income_id,
      postTown: props.state.city,
      postcode: props.state.zip,
      occupation: props.state.occupation_id,
      employmentStatus: props.state.profession_id,
    });
  }, []);

  useEffect(() => {
    if (editAddressFormSubmit) {
      props.editProfile("");
    }
  }, [editAddressFormSubmit]);

  const onSearch = (searchText) => {
    GuestAPI.searchAddress(searchText).then((res) => {
      let resText = [];
      res.data.Items.forEach((d) => {
        let desc = "";
        if (d.Description != "") {
          desc = `(${d.Description})`;
        }

        let data = {
          id: d.Id,
          searchTerm: d.Text,
          text: d.Text + desc,
          next: d.Next,
          description: d.Description,
          // description: d.Description.replace(' Results', '')
        };
        resText.push(data);
      });
      setSerachAddressData(resText);
    });
  };

  const findSubAddress = (id, searchTerm) => {
    GuestAPI.findSubAddress(id, searchTerm).then((res) => {
      let resText = [];
      // console.log(res.data)
      res.data.Items.forEach((d) => {
        let desc = "";
        if (d.Description != "") {
          desc = `(${d.Description})`;
        }

        let data = {
          id: d.Id,
          text: d.Text + desc,
          next: d.Next,
          description: d.Description,
        };
        resText.push(data);
      });
      setSerachAddressData(resText);
    });
  };

  const onSelect = (data) => {
    let address = JSON.parse(data);
    // console.log(address)

    if (address.next == "Find") {
      findSubAddress(address.id, address.searchTerm);
    } else {
      GuestAPI.selctedSearchAddress(address.id).then((res) => {
        if (res.data.Items.length > 0) {
          let getAddress = res.data.Items[0];
          form.setFieldsValue({
            houseBuildingName: getAddress.BuildingName,
            streetName: getAddress.Street,
            country: getAddress.CountryName,
            district: getAddress.Province,
            postTown: getAddress.AdminAreaName,
            postcode: getAddress.PostalCode,
          });
        }
      });
    }
  };

  const onFinish = (value) => {
    props.setState({
      // address: value. "tcfvygbhnjkm,",
      // citizenship: value.citizenship,
      // country: value. "United Kingdom",
      // houseBuildingName: value. "tfyghj",
      income_id: value.annualIncome ? value.annualIncome : "1",
      state: value.district,
      // profession_id: value.employmentStatus,
      occupation_id: value.occupation,
      city: value.postTown,
      zip: value.postcode,
      address1: value.streetName,
      // address3: value.houseBuildingName,
    });

    if (props.state.twofa === "Y") {
      props.sendOTP("EP", "Edit_Address");
    } else {
      setEditAddressFormSubmit(true);
    }
  };

  return (
    <div>
      <Modal
        centered
        title="Edit Address"
        visible={props.state._isShowAddressEditModel}
        onCancel={() => props.setState({ _isShowAddressEditModel: false })}
        footer={null}
      >
        <Form form={form} onFinish={onFinish}>
          <div className="d-flex justify-content-center align-items-center">
            <Row className="justify-content-center">
              {profileConfig?.addressApi && (
                <Col md={12}>
                  <label className="form-label">Address</label>
                  <Form.Item
                    className="form-item"
                    name="address"
                    rules={[
                      { required: true, message: "Please input your Address." },
                    ]}
                  >
                    <Select
                      className="w-100"
                      showSearch
                      onSearch={onSearch}
                      onSelect={onSelect}
                      placeholder="Select Recipient"
                    >
                      {serachAddressData.map((rec, i) => {
                        return (
                          <Option
                            key={i}
                            value={JSON.stringify(rec)}
                          >{`${rec.text}`}</Option>
                        );
                      })}
                    </Select>
                  </Form.Item>
                </Col>
              )}

              <Col md={6}>
                <label className="form-label">Country</label>
                <Form.Item
                  className="form-item"
                  name="country"
                  rules={[
                    { required: true, message: "Please input your Country." },
                  ]}
                >
                  <Input
                    disabled
                    size="large"
                    placeholder="Enter your Country"
                  />
                </Form.Item>
              </Col>

              <Col md={6}>
                <label className="form-label">Citizenship</label>
                <Form.Item
                  className="form-item"
                  name="citizenship"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Citizenship.",
                    },
                  ]}
                >
                  <Input
                    disabled
                    size="large"
                    placeholder="Enter your Citizenship"
                  />
                </Form.Item>
              </Col>

              {/* <Col md={6}>
                <label className="form-label">House / Building Name</label>
                <Form.Item
                  className="form-item"
                  name="houseBuildingName"
                  // rules={[
                  //     { required: true, message: 'Please input House / Building Name.' }
                  // ]}
                >
                  <Input
                    size="large"
                    placeholder="Enter House / Building Name"
                  />
                </Form.Item>
              </Col> */}
              <Col md={12}>
                <label className="form-label">Address Line 1</label>
                <Form.Item
                  className="form-item"
                  name="streetName"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Street Name.",
                    },
                  ]}
                >
                  <Input size="large" placeholder="Enter your Street Name" />
                </Form.Item>
              </Col>
              <Col md={6}>
                <label className="form-label">District</label>
                <Form.Item
                  className="form-item"
                  name="district"
                  rules={[
                    { required: true, message: "Please input your District." },
                  ]}
                >
                  <Input size="large" placeholder="Enter your District" />
                </Form.Item>
              </Col>

              {/* <Col md={6}>
                <label className="form-label">Annual Income</label>
                <Form.Item
                  className="form-item"
                  name="annualIncome"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Annual Income.",
                    },
                  ]}
                >
                  <Select
                    size="large"
                    className="w-100"
                    placeholder="Select Annual Income"
                    showSearch
                  >
                    {props.state.incomeLists.map((list, i) => {
                      return (
                        <Option key={i} value={list.incmId}>
                          {list.incomeDesc}
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Col> */}

              <Col md={6}>
                <label className="form-label">Post Town</label>
                <Form.Item
                  className="form-item"
                  name="postTown"
                  rules={[
                    { required: true, message: "Please input your Post Town." },
                  ]}
                >
                  <Input size="large" placeholder="Enter your Post Town" />
                </Form.Item>
              </Col>

              <Col md={6}>
                <label className="form-label">Postcode</label>
                <Form.Item
                  className="form-item"
                  name="postcode"
                  rules={[
                    { required: true, message: "Please input your Postcode." },
                    ...inputValidations.zipCode(AuthReducer.sendCountryCode),
                  ]}
                >
                  <Input size="large" placeholder="Enter your Postcode" />
                </Form.Item>
              </Col>

              <Col md={6}>
                <label className="form-label">Occupation</label>
                <Form.Item
                  className="form-item"
                  name="occupation"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Occupation.",
                    },
                  ]}
                >
                  <Select
                    size="large"
                    className="w-100"
                    placeholder="Select Occupation"
                    showSearch
                  >
                    {props.state.occupationLists.map((list, i) => {
                      return (
                        <Option key={i} value={list.occupationId}>
                          {list.occupationDesc}
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Col>

              {/* <Col md={6}>
                <label className="form-label">Employment Status</label>
                <Form.Item
                  className="form-item"
                  name="employmentStatus"
                  rules={[
                    {
                      required: true,
                      message: "Please select your Employment Status.",
                    },
                  ]}
                >
                  <Select
                    size="large"
                    className="w-100"
                    placeholder="Select Employment Status"
                    showSearch
                  >
                    {props.state.professionLists.map((list, i) => {
                      return (
                        <Option key={i} value={list.professionId}>
                          {list.professionDesc}
                        </Option>
                      );
                    })}
                  </Select>
                </Form.Item>
              </Col> */}

              <Spin spinning={loading} delay={500}>
                <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                  <button
                    className="btn btn-danger btn-block btn-sm px-4"
                    onClick={() =>
                      props.setState({ _isShowAddressEditModel: false })
                    }
                    type="button"
                  >
                    Cancel
                  </button>
                  <button className="btn btn-primary btn-sm text-white px-4 btn-sm">
                    Submit
                  </button>
                </div>
              </Spin>
            </Row>
          </div>
        </Form>
      </Modal>
    </div>
  );
}
