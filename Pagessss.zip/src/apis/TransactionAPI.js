import axios from "axios";
import { config } from "../config";
// import { AuthService } from "../services/AuthService";

export const TransactionAPI = {
    transactionLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/transaction-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    txnStatement: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/txn-statement`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    defaultTransactionList: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/default-transactions`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    computeExchangeRates: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/compute-exchange-rates`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    categoryPromoLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/category-promo-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    receiverLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/recv/receiver-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    getBankAccountLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/send-bank-account-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    getAchAccountLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/ach-account-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    purposeLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/purpose-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    subPurposeLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/sub-purpose-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    sourceOFFundLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/source-of-fund-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    promoLists: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/promo-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    addPurposeDeclaration: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/add-purpose-declaration`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    bookTransaction: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/transaction`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    bookScheduleTransaction: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/schedule-transaction`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    getGlobalpayData: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/get-globalpay-data`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    globalpayResponse: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/globalpay-response`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    transactionReceiptDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/transaction-receipt-details`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    cancelTransaction: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/cancel-transactions`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    scheduleTransactionReceiptDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/scedule-transaction-receipt-details`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    txnFaviorate: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/txn/faviorate`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    trackTranscation: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/post-track-my-transfer`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    trackTranscationPreLogin: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `https://kcbadmin.remit.in/services/txn/track-my-transfer`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    repeatTranscationDeatils: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/transaction-details`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },

    sofortTransaction: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.SOFORT_URL}`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    scheduleTransactionReminder: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/schedule-transaction-reminder`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    getCoreBankDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/corr-bank-details`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    txnTraceUpdate: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/txn-trace-update`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    // get sofort transcation status api
    getTxnSofortStatus: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/get-txn-sofort-status`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
}