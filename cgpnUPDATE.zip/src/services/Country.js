const COUNTRY = {
  GB: {
    countryCurrency: "GBP",
    isoCountrycode: "GBR",
    countryName: "United Kingdom",
    countryCode: "GB",
  },
  US: {
    countryCurrency: "USD",
    isoCountrycode: "US",
    countryName: "United States of America",
    countryCode: "US",
  },
  IN: {
    countryCurrency: "INR",
    isoCountrycode: "IN",
    countryName: "India",
    countryCode: "IN",
  },
};
