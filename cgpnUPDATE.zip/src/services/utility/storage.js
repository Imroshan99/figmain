import SecureLS from "secure-ls";

class SecureStorage extends SecureLS {
  constructor(config) {
    super(config);
    // tslint:disable-next-line:ban-ts-ignore
    // @ts-ignore
    super.ls = config.useSessionStore ? sessionStorage : localStorage;
  }
}

const ls = new SecureStorage({
  encodingType: "",
  isCompression: false,
  // encodingType: "aes",
  // encryptionSecret: "&&&**&*Y5656555#@#2^",
  useSessionStore: sessionStorage,
});
export function setSessionStorage(key, value) {
  ls.set(key, value);
}

export function getSessionStorage(key) {
    return ls.get(key);
}

export function removeSessionStorage(key) {
  ls.remove(key);
}

export function removeAllSessionStorage() {
    ls.removeAll()
  }
