export const flags = {
  IN: "IN.png",
  US: "US.png",
  GB: "GB.png",
  CA: "CA.png",
  KE: "KE.png",
  AE: "AE.png",
};

export const getFlagPath = (country) => {
  const path = "/images/flags/4x3/" + country.toLowerCase() + ".svg";
  return path;
};
