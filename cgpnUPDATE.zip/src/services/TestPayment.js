// /* eslint-disable no-undef */
// /* eslint-disable react/prop-types */
// import React, { Component } from 'react';
// import { Platform, SafeAreaView, Dimensions, View } from 'react-native';
// import { Helmet } from 'react-helmet';
// import Header from '../../../components/Header/Header';
// import CustomFooter from '../../../components/customFooter';
// import { hocComponentFetcherWithLoader } from '../../../components';
// import { paymentStatus } from '../../network/request/globalPayment/paymentStatus';
// import fetchAllNotification from '../../network/request/notification/allNotification';
// import {
//   getPrefData,
//   USER_ID,
//   INSTID,
//   SESSION_ID,
//   USER_IP,
// } from '../../../storage/preferenceStorage';
// import { stickyFooterStyle } from '../../../styles/stickyHeaderandFooterStyle';

// import { getGroupIdMap } from '../../../utils/helperUtils';
// import { GLOBAL_PAYMENT_URL } from '../../utils/domainUrl';
// import WebTickerComponent from '../WebTickerComponent/TickerComponent';
// import { AppConsumer } from '../../../AppContext';

// class PaymentPage extends Component {
//   static contextType = AppConsumer;

//   constructor(props) {
//     super(props);

//     this.state = {
//       transactionId: props.navigation.getParam('transactionId'),
//       transactionNo: props.navigation.getParam('transactionNo'),
//       paymentId: props.navigation.getParam('paymentId'),
//       paymentInfo: props.navigation.getParam('paymentDetails'),
//     };

//     this.loadPrefData();
//   }

//   componentDidMount() {
//     const { paymentInfo } = this.state;
//     const { showLoader } = this.props;
//     showLoader();

//     RealexHpp.setHppUrl(GLOBAL_PAYMENT_URL);
//     RealexHpp.embedded.init(
//       'autoload',
//       'targetIframe',
//       (gpResponse, close) => this.navigateToThankYouPage(gpResponse, close),
//       paymentInfo
//     );
//   }

//   loadPrefData = async () => {
//     this.userId = await getPrefData(USER_ID);
//     this.instanceId = await getPrefData(INSTID);
//     this.sessionId = await getPrefData(SESSION_ID);
//     this.userIp = await getPrefData(USER_IP);
//   };

//   navigateToThankYouPage = (paymentResponse, closePaymentGateWay) => {
//     const { makeAPICall, navigation } = this.props;
//     const { transactionId, paymentId, transactionNo } = this.state;

//     console.log('----Payment Response----', paymentResponse);

//     makeAPICall(
//       paymentStatus(
//         this.userId,
//         transactionId,
//         paymentId,
//         this.instanceId,
//         getGroupIdMap(this.instanceId),
//         this.sessionId,
//         this.userIp,
//         paymentResponse
//       ),
//       response => {
//         // TODO: move this api call to one file
//         makeAPICall(
//           fetchAllNotification(this.userId, this.sessionId, this.userIp),
//           response => {
//             const { setContext, ShowBadgeCount } = this.context;
//             if (response.status === 'S') {
//               setContext({
//                 notificationCount: response.newNotification,
//               });

//               if (Platform.OS !== 'web') {
//                 ShowBadgeCount({
//                   count: response.newNotification,
//                 });
//               }
//             }
//           },
//           this.onError
//         );

//         navigation.navigate('ThankYouPaymentGateway', {
//           debitStatus: response.status,
//           transactionNo,
//           transactionId,
//         });
//       },
//       this.onError
//     );

//     closePaymentGateWay();
//   };

//   onError = () => {
//     console.log(error);
//   };

//   render() {
//     const { navigation, makeAPICall } = this.props;
//     const { paymentInfo = {} } = this.state;

//     return (
//       <SafeAreaView style={{ flex: 1 }}>
//         {/* TODO: Infuture plan to load global payment scripts using helmet */}
//         {/* <Helmet>
//           <script
//             type="text/javascript"
//             src="/GlobalPayment/dist/rxp-js.js"
//           ></script>
//         </Helmet> */}

//         {Platform.OS === 'web' && this.context.tickerMessage !== '' ? (
//           <WebTickerComponent {...this.props} />
//         ) : null}

//         <Header
//           hideIcons={true}
//           disableLogo={true}
//           navigation={navigation}
//           makeAPICall={makeAPICall}
//         />

//         {Platform.OS === 'web' && Object.keys(paymentInfo).length > 0 ? (
//           <iframe
//             title="card-payment"
//             id="targetIframe"
//             width={Dimensions.get('window').width}
//             height={Dimensions.get('window').height}
//           ></iframe>
//         ) : null}

//         <div style={stickyFooterStyle()}>
//           <View onLayout={() => this.onLayoutFooter}>
//             <CustomFooter {...this.props} />
//           </View>
//         </div>
//       </SafeAreaView>
//     );
//   }
// }

// export default hocComponentFetcherWithLoader()(PaymentPage);
