import thunk from "redux-thunk";
import { createStore, combineReducers, applyMiddleware } from "redux";
import { composeWithDevTools } from "redux-devtools-extension";
// import profileReducer from './reducers/profileReducer';

import { configureStore } from "@reduxjs/toolkit";
import userReducer from "./reducers/userReducer";

const masterReducer = combineReducers({
  user: userReducer,
});

// const store = createStore(
//   masterReducer,
//   composeWithDevTools(applyMiddleware(thunk))
// );
const store = configureStore({
  reducer: masterReducer,
  middleware: [thunk],
});

export default store;
