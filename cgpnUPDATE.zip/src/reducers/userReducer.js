import { createSlice } from "@reduxjs/toolkit";

const initialState = {
  // app.js state
  userLastActivitiyAt: new Date(),
  publicKey: "",
  isLoggedIn: false,
  additionalAuthRequired: false, //if user required more authentication before move to sendmoney page
  tokenExpiredAt: new Date(),
  tokenExpiredMinute: 4,

  accessToken: "",
  userID: "",
  userLoginId: "",
  lastLogin: "",
  userKYC: "",
  userFullName: "",

  clientId: "",
  groupId: "",
  groupIdSettings: "",
  twofa: "",

  sessionId: "",
  sendCountryCode: "",
  sendCurrencyCode: "",
  recvCountryCode: "",
  recvCurrencyCode: "",
  regCountryCode: "", //for user registered country code

  kycFrmTxnValidate: false, //for via transcation validate kyc
};

export const userSlice = createSlice({
  name: "user",
  initialState,
  reducers: {
    login: (state, action) => {
      state.lastLogin = action.payload.lastLogin;
      state.userID = action.payload.userID;
      state.userLoginId = action.payload.userLoginId;
      state.regCountryCode = action.payload.regCountryCode;
      state.userFullName = action.payload.userFullName;
      state.accessToken = action.payload.accessToken;
      state.isLoggedIn = action.payload.isLoggedIn;
    },
    setToken: (state, action) => {
      // Redux Toolkit allows us to write "mutating" logic in reducers. It
      // doesn't actually mutate the state because it uses the Immer library,
      // which detects changes to a "draft state" and produces a brand new
      // immutable state based off those changes
      state.accessToken = action.payload;
    },
    setTokenExpiredAt: (state, action) => {
      state.tokenExpiredAt = action.payload;
    },
    setTokenExpiredMinute: (state, action) => {
      state.tokenExpiredMinute = action.payload;
    },
    setUserLastActivitiyAt: (state, action) => {
      state.userLastActivitiyAt = action.payload;
    },
    setPublicKey: (state, action) => {
      state.publicKey = action.payload;
    },
    setUserId: (state, action) => {
      state.userID = action.payload;
    },
    setLastLogin: (state, action) => {
      state.lastLogin = action.payload;
    },
    setUserKyc: (state, action) => {
      state.userKYC = action.payload;
    },
    setUserFullName: (state, action) => {
      state.userFullName = action.payload;
    },
    setIsLoggedIn: (state, action) => {
      state.isLoggedIn = action.payload;
    },
    setClientId: (state, action) => {
      state.clientId = action.payload;
    },
    setGroupId: (state, action) => {
      state.groupId = action.payload;
    },
    setGroupIdSettings: (state, action) => {
      state.groupIdSettings = action.payload;
    },
    setTwofa: (state, action) => {
      state.twofa = action.payload;
    },

    setSessionId: (state, action) => {
      state.sessionId = action.payload;
    },
    setSendCountryCode: (state, action) => {
      state.sendCountryCode = action.payload;
    },
    setSendCurrencyCode: (state, action) => {
      state.sendCurrencyCode = action.payload;
    },
    setRecvCountryCode: (state, action) => {
      state.recvCountryCode = action.payload;
    },
    setRecvCurrencyCode: (state, action) => {
      state.recvCurrencyCode = action.payload;
    },
    setKycDoneFrmTxnValidate: (state, action) => {
      state.kycFrmTxnValidate = action.payload;
    },
    setAdditionalAuthRequired: (state, action) => {
      state.additionalAuthRequired = action.payload;
    },
  },
});

// Extract the action creators object and the reducer
const { actions, reducer } = userSlice;
// Action creators are generated for each case reducer function
export const {
  login,
  setToken,
  setTokenExpiredAt,
  setTokenExpiredMinute,
  setUserLastActivitiyAt,
  setPublicKey,
  setUserId,
  setLastLogin,
  setUserKyc,
  setUserFullName,
  setIsLoggedIn,
  setClientId,
  setGroupId,
  setGroupIdSettings,
  setTwofa,
  setSessionId,
  setSendCountryCode,
  setSendCurrencyCode,
  setRecvCountryCode,
  setRecvCurrencyCode,
  setKycDoneFrmTxnValidate,
  setAdditionalAuthRequired
} = actions;

// console.log(setToken({ id: 123, title: 'Hello World' }))
// {type : "user/setToken", payload : {id : 123, title : "Hello World"}}
export default reducer;
