import React from "react";
import { useSelector } from "react-redux";

const RegulationsXR = React.lazy(() => import("./XR"));

const Regulations = () => {
  const AuthReducer = useSelector((state) => state.user);
  switch (AuthReducer.groupId) {
    case "KCB":
      return <div>To be updated soon</div>;
      break;

    case "XR":
      return <RegulationsXR />;
      break;

    default:
      return <div>To be updated soon</div>;
      break;
  }
};

export default Regulations;
