import { useState } from "react";
import { Button } from "antd";

export default function TCXR() {
  const [showMore, setShowMore] = useState(false);
  return (
    <div className="text-white">
      <p id="tc1">
        <strong>1. ABOUT THIS AGREEMENT</strong>
      </p>
      <ol style={{ listStyleType: "lower-alpha" }}>
        <li>
          <strong>About us</strong>: this agreement is made by XeOPAR Fintech
          Private Limited, a company registered in India under The Companies Act
          2013 [CIN U67100UP2018PTC107164] and whose registered and head office
          is at H -187, Sector 63, Noida, Gautam Buddha Nagar, U.P., India.
          Under the product/ brand name <strong>Xmonies, </strong>an
          International Cross Border Remittance and Payments Platform. (
          <strong>
            &lsquo;&rsquo;XeOPAR&rsquo;&rsquo;,
            &lsquo;&rsquo;Xmonies&rsquo;&rsquo;, &lsquo;&rsquo;we&rsquo;&rsquo;,
            &lsquo;&rsquo;our&rsquo;
          </strong>
          &rsquo;).
          <br />
          Along with her compliance partner Rational Foreign Exchange Limited, a
          company registered in England and Wales under 05385999 and whose
          registered and head office is at Level 32, One Canada Square, London,
          E14 5AB, United Kingdom (&ldquo;<strong>RationalFX</strong>&rdquo;).
        </li>
        <li>
          <strong>Regulatory information: </strong>Our compliance partner
          RationalFX have the following authorisations and registrations:
          <ol style={{ listStyleType: "lower-roman" }}>
            <li>
              authorised by the Financial Conduct Authority as an Authorised
              Payment Institution under the Payment Services Regulations with
              FCA registration number 507958;
            </li>
            <li>
              a registered money services business with HM Revenue and Customs
              No.
            </li>
          </ol>
        </li>
        <li>
          <strong>Our Services</strong>: We provide foreign exchange and
          international payment services (&ldquo;<strong>Services</strong>
          &rdquo;) to our corporate and personal clients (&ldquo;
          <strong>Client</strong>&rdquo;, &ldquo;<strong>you</strong>&rdquo;,
          &ldquo;<strong>your</strong>&rdquo;).
        </li>
        <li>
          <strong>About these terms</strong>: These terms and conditions
          (&ldquo;<strong>Terms</strong>&rdquo;) explain how you can place an
          Order for our Services and set out the terms and conditions which will
          apply to any Contract that is made between us as a result of our
          acceptance of your Order. Your attention is particularly drawn to the
          following:
          <ol style={{ listStyleType: "lower-roman" }}>
            <li>
              The key information and risks of using our Services (see clause{" "}
              <a href="#tc3">3</a>).
            </li>
            <li>
              Cancellation rights (see clause <a href="#tc8">8</a>).
            </li>
            <li>
              We have limitations on our liability to you (see clause{" "}
              <a href="#tc16">16</a>).
            </li>
            <li>
              You are liable to us for any breach of these terms and conditions
              (see clause <a href="#tc17">17</a>).
            </li>
            <li>
              Our obligations and liability to you under the Payment Services
              Regulations (if applicable) (see clause <a href="#tc19">19</a>).
            </li>
            <li>
              Your right to take any complaint you may have to the Financial
              Ombudsman (see clause <a href="#tc20">20</a>).
            </li>
          </ol>
        </li>
        <li>
          When you place an Order, you will be required to read, and accept
          these Terms. You agree that if you use our Services you will be taken
          to have agreed to these Terms. If you do not agree to these Terms, you
          should not place an Order with us. We recommend that you print a copy
          of them for your future reference. Capitalised terms are defined in
          clause
        </li>
        <li>
          These Terms will apply to all Contracts between you and us however you
          access our Services (including through our Website or through any
          mobile device application).
        </li>
      </ol>
      {showMore && (
        <div>
          <p id="tc2">
            <strong>2. CHANGES TO THESE TERMS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Single Payment Service: Notice of changes</strong>: We
              will give you advanced notice of such changes to a Single Payment
              Service and will post them on our Website so that you can view
              them when you next log in.
            </li>
            <li>
              <strong>Changes to our Regular Payments Service </strong>If your
              Contract is for our Regular Payments Service:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  we will notify you in writing (either by email or post) of any
                  proposed changes to these Terms and the Contract at least two
                  months before the changes are to take effect. However, we may
                  apply a change in exchange rate that is based on a change to a
                  reference exchange rate or is more favourable to the customer
                  immediately and without notice provided that this change is
                  applied in a non-discriminatory manner;
                </li>
                <li>
                  such changes will come into effect provided you do not notify
                  us that you are opposed to the change before the date
                  specified;
                </li>
                <li>
                  you will be deemed to have accepted the changes, unless you
                  notify us otherwise; and
                </li>
                <li>
                  you and we have the right to terminate the Contract without
                  charge, at any time before the proposed date of the change.
                </li>
              </ol>
            </li>
            <li>
              <strong>Changes to these Terms</strong>: We may need to change
              these Terms from time to time to:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>comply with law or regulations;</li>
                <li>reflect changing market conditions; or</li>
                <li>meet our changing business</li>
              </ol>
            </li>
            <li>
              <strong>Changes required by law</strong>: We may make changes
              without your specific agreement only where those changes are
              required to comply with law or regulations.
            </li>
            <li>
              <strong>
                Single Payment Service Transactions: Date changes are effective
              </strong>
              : Changes will only apply to Single Payment Service Transaction
              Contracts which are entered into on or after the date upon which
              the changes become effective. However, the changes will also apply
              to Contracts entered into before such date if required by law or
              regulatory requirements.
            </li>
            <li>
              <strong>Your agreement to the changes</strong>: By placing an
              Order after the new terms are effective, you agree to be bound by
              the new terms. If you object to the changes, you should not place
              any further Orders with us.
            </li>
            <li>
              <strong>Changes requested by the Client</strong>: Changes to these
              Terms requested by a Client will only be effective if agreed to by
              us in writing.
            </li>
          </ol>
          <p  id="tc3">
            <strong>3. KEY INFORMATION AND RISKS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>No financial advice</strong>: In providing our Services,
              we do not provide you with any investment advice including any
              guidance on the merits of a particular Order or its likely
              implications, nor can we advise on or recommend to the Client any
              investment products. To the extent that we provide you with any
              advice, it will relate only to the mechanics of the transaction
              you are proposing to enter into or to publicly available
              information.
            </li>
            <li>
              <strong>No liability for currency fluctuation</strong>: The
              foreign currency market is volatile and outside of our We will not
              be liable to you for any loss or damage which arises as a result
              of any currency fluctuation between the Deal Confirmation and the
              Value Date. You agree that in placing an Order, you have relied
              purely on your own judgement and you have not relied on anything
              not expressly contained within these Terms.
            </li>
            <li>
              <strong>Provision of Information</strong>: We will provide certain
              information to you prior to entering into a Contract which we are
              required to provide under the Payment Services Regulations.
              <br />
              We will communicate this information either over the phone or in
              writing (through our online ordering process, by letter or by
              email). If we communicate this information over the phone, we will
              confirm it by email. We will also provide the information to you
              in paper or in a downloadable format, if you request it.
            </li>
          </ol>
          <p  id="tc4">
            <strong>4. PRIVACY POLICY</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Your information</strong>: We understand that the privacy
              of your personal information (and that of your Authorised Persons)
              is important and we will not share it with anyone else for their
              use in any marketing or promotional campaign.
            </li>
            <li>
              <strong>Our privacy policy</strong>: Any personal information you
              provide to us (in any capacity) via our Website, over the
              telephone or otherwise may be collected, stored, processed and
              used in accordance with our{" "}
              <a href="https://www.rationalfx.com/privacy-policy">
                Privacy Policy
              </a>
              . By continuing to use our Services you consent to such use of
              your personal information.
            </li>
          </ol>
          <p  id="tc5">
            <strong>5. REGISTRATION AND ELIGIBILITY</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Registration</strong>: Before XeOPAR can provide any
              Services to you, you must register for an account on our Website
              or you can complete a paper registration form available from us on
              request. You are permitted to open one Personal and one Business
              account only.
            </li>
            <li>
              <strong>Proof of ID</strong>: We may carry out an electronic
              verification of your identity. You may also need to provide us
              with evidence of your identity and proof of address so that we can
              complete our anti-money laundering process, together with any
              other information we may request.
            </li>
            <li>
              <strong>Re-registration</strong>: If you do not use our Services
              for 12 months, you may need to re-register before we can perform
              any further Services for you.
            </li>
            <li>
              <strong>Eligibility</strong>: To be eligible to register for and
              use our Services, you (or in the case of a corporate Client, your
              Authorised Persons) must:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>be 18 years of age; and</li>
                <li>
                  not be suffering from any disability or impairment which may
                  affect your capacity to enter into a Contract (or the
                  Authorised Person&rsquo;s capacity to enter into a Contract on
                  the Client&rsquo;s behalf).
                </li>
              </ol>
            </li>
            <li>
              <strong>Accuracy of your information</strong>: You are solely
              responsible for ensuring that the information you give to us is
              and remains true and You agree to inform us of any changes to such
              information either by changing your Client Profile online or by
              written notice to us.
            </li>
            <li>
              <strong>Password security</strong>: It is your responsibility to
              keep safe and secure any passwords or other security devices used
              to access our Website or Services. You must notify us immediately
              of any actual or suspected loss or compromise of any of them.
            </li>
          </ol>
          <p  id="tc6">
            <strong>6. PLACING AN ORDER</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Placing orders</strong>: Once registered, you will be
              given a unique reference number. You can then place an Order by
              telephone, email, or through our Website. However, we may require
              written confirmation of any Order (or other Client instruction) at
              any An Order received from an email address in your Client Profile
              or through your account on our Website will be deemed to have been
              sent by you. The Contract will become binding in accordance with
              clause <a href="#tc7">7.</a> By placing an Order through
              the order process described in these Terms, you acknowledge that
              you are authorising us to make the payment in accordance with the
              terms of the Contract that is formed
            </li>
            <li>
              <strong>Non-reliance</strong>: You agree that in placing an Order,
              you have relied purely on your own judgement and you have not
              relied on anything not expressly contained within these Terms.
            </li>
            <li>
              <strong>Own account</strong>: Orders will only be accepted from a
              Client acting on its own account and not from a person acting for
              or on behalf of, or as agent for, a third party (except Authorised
              Persons).
            </li>
            <li>
              <strong>Unregulated Foreign Exchange Contract: </strong>You
              promise that where you place an order for an Unregulated Foreign
              Exchange Contract, except in relation to a Spot Contract, the
              purpose of the Order will be to facilitate payment for
              identifiable goods, services or direct If at any point the purpose
              of your Unregulated Foreign Exchange Contract, excluding a Spot
              Contract, is not to or is no longer to facilitate payment for
              identifiable goods, services or direct investment, you will
              immediately notify us by telephone or email.
            </li>
            <li>
              <strong>Authorising payment: </strong>By placing an Order through
              the order process described in these Terms, you acknowledge that
              you are authorising us to make the payment in accordance with the
              terms of the Contract that is formed.
            </li>
            <li>
              <strong>Using a Commercial Card: </strong>If you place an Order
              using a Commercial Card, you agree that we may charge you the
              costs borne by us for the use of that specific Commercial Card in
              Charges will vary between issuers and will be disclosed prior to
              booking confirmation.
            </li>
          </ol>
          <p id="tc7">
            <strong>7. ACCEPTANCE OF AN ORDER</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Online</strong>: If you place an Order through our
              Website, the following process applies:
              <br />
              <strong>An acknowledgment </strong>will appear on screen and sent
              via email at the time the order is placed online, which confirms
              that we have received your request to place an order.
              <br />
              <strong>Deal confirmation </strong>will be sent via email once the
              order has been processed. The Contract will be legally binding on
              you when we provide you with the Deal Confirmation.
            </li>
            <li>
              <strong>Email</strong>: If you place an Order by email, the
              Contract will be binding on you when we process your email. You
              acknowledge that, if you place an Order by email, it may not be
              processed immediately. When we process your Order, we will send
              you a Deal Confirmation by email.
            </li>
            <li>
              <strong>Telephone</strong>: If you place an Order by telephone,
              the Contract will be legally binding at the conclusion of the
              telephone We will send you a Deal Confirmation by email. If there
              is any discrepancy between the Deal Confirmation and the details
              of the Contract that have already been agreed in the telephone
              conversation, you must contact us within 24 hours of receipt of
              the Deal Confirmation, failing which the details in the Deal
              Confirmation will be deemed to be correct. In the event of any
              dispute, the transcript of our telephone conversation may be used
              as evidence as to the terms of the Contract that was entered into.
            </li>
            <li>
              <strong>Separate Contracts</strong>: Each Deal Confirmation issued
              by us to you will amount to a separate Contract for an individual
              payment transaction between us which is subject to these Terms.
            </li>
            <li>
              <strong>No obligation to accept Orders</strong>: While we will
              endeavour to comply with your requests for Services, there may be
              circumstances in which we are unable to do so. Therefore, we
              always reserve the right to refuse to accept your Orders and to do
              so without giving you any reasons and without incurring any
              liability to you for any resulting loss or damages incurred by you
              or any other party.
            </li>
            <li>
              <strong>Out-of-Market Quotes</strong>: If we quote you a rate or
              Purchase Price that is clearly a mistake on our part as the result
              of a technical or human error, it is not binding on You must
              notify us as soon as the mistake comes to your attention and we
              will re-quote as soon as possible
            </li>
            <li>
              <strong>Receipt of an Order and time for payment</strong>:
              Pursuant to a Contract, we will agree with you that execution of
              the payment is to take place either:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>on a specific day;</li>
                <li>on the last day of a certain period; or</li>
                <li>
                  the day on which the payer puts funds at your disposal, and
                  the time of receipt of your payment order is deemed to be that
                  day or the next Business Day if this falls on a non-Business
                  Day. This date is referred to in these Terms as the Value
                  Date.
                </li>
              </ol>
            </li>
            <li>
              Once an Order is completed, we will not retain the proceeds unduly
              and will send them to the Recipient, Your Nominated Account or
              otherwise return them to you.
            </li>
            <li>
              The payment will be credited to the Recipient&rsquo;s bank account
              on or before:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  the end of the Business Day following the Value Date for
                  payment transactions except those initiated on paper; and
                </li>
                <li>
                  the end of the second Business Day following the Value Date
                  for payment transactions initiated on paper.
                </li>
              </ol>
            </li>
            <li>
              For further protection, RationalFX may also take steps to
              safeguard Client monies consistent with our obligations under the
              Payment Services Regulations. Further information on the steps
              RationalFX take can be found by contacting us by email to{" "}
              <a href="mailto:info@rationalfx.com">info@rationalfx.com</a> or
              writing to Chief Operating Officer at RationalFX.
            </li>
          </ol>
          <p id="tc8">
            <strong>8. CANCELLING AND REFUSING AN ORDER OR CONTRACT</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Cancellation before acceptance</strong>: You are free to
              cancel an Order at any time before we have accepted it and it
              becomes legally binding.
            </li>
            <li>
              <strong>Cancellation after acceptance</strong>: If you have placed
              an Order under a Spot Contract, Forward Contract, Limit Order or
              our Regular Payments Service which has been accepted, you may
              cancel or terminate the Contract at any point up to the end of the
              Business Day preceding the Value Date by notifying us by
              telephone, post, email, or through our Website and no charges will
              apply. Cancellation of an Order may also be made in accordance
              with clause <a href="#tc3">3</a> below.
            </li>
            <li>
              <strong>Payment</strong>: failure to make payment for an accepted
              Order within five working days could lead to a cancellation of the
              contract, potentially causing cancellation fees to be payable, and
              your account being Suspended until the cancellation fee is paid
            </li>
            <li>
              <strong>Cancellation at our discretion</strong>: We may at our
              discretion accept cancellation requests. However, this may be
              subject to cancellation fees which will be communicated to you
              before cancellation is accepted.
            </li>
            <li>
              <strong>Refund</strong>: If we accept your cancellation of an
              Order, we will refund you the funds transferred to us for the
              purposes of the Order less any applicable cancellation or
              administration fees applicable at the time the refund is made.
            </li>
            <li>
              <strong>Refusal to accept an Order</strong>: If we refuse to
              accept an Order or to complete a payment under a Contract, we will
              notify you of the refusal and, if possible, the reasons for such
              refusal together with the procedure for rectifying any factual
              errors that led to the refusal by the end of the Business Day
              following the day that we received the Order.
            </li>
            <li>
              <strong>Regular Payments Service</strong>: In a Contract for our
              Regular Payments Service unless it is otherwise unlawful, we can
              only refuse to make one or more of the payments required under
              such Contract where the following conditions are met:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  one of the grounds for terminating the Contract specified at
                  clause <a href="#tc1">1</a> has arisen; or
                </li>
                <li>if there is a Disruption Event</li>
              </ol>
            </li>
          </ol>
          <p id="tc9">
            <strong>9. AUTHORISED PERSONS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Individual Clients</strong>: For private individual
              Clients, we will only accept Orders placed or instructions given
              by the Client, unless the Client has a Joint Account with us, in
              which case the provisions relating to Joint Accounts at clause{" "}
              <a href="#tc10">10</a> will apply. The following provisions
              of this clause <a href="#tc9">9</a> will apply to corporate
              Clients only.
            </li>
            <li>
              <strong>Corporate Clients</strong>: For corporate Clients, we will
              only accept Orders placed or instructions given by an Authorised
              Person.
            </li>
            <li>
              <strong>Authorised Persons</strong>: At the time of registration,
              you are required to supply us with the name and contact details of
              all personnel within your business whom have authority to act on
              your behalf in connection with our Such personnel will become
              Authorised Persons when they have been accepted as Authorised
              Persons by us.
            </li>
            <li>
              <strong>Authority of an Authorised Person</strong>: We will treat
              each Authorised Person as having authority from the Client to
              instruct us in respect of all matters relating to the Services
              unless you notify us that an Authorised Person is to have a more
              limited scope of authority.
            </li>
            <li>
              <strong>Removal of an Authorised Person</strong>: You may remove
              an Authorised Person or change the registered contact details or
              scope of authority of an existing Authorised Person by updating
              your Client Profile or sending written notice of the change to us.
            </li>
          </ol>
          <p id="tc10">
            <strong>10. JOINT ACCOUNTS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Responsibility of joint account holders</strong>: A
              registration may be made by two private individuals jointly
              (&ldquo;<strong>Joint Account</strong>&rdquo;). Each Joint Account
              holder will be (both together and separately) responsible for the
              performance of all obligations of the Client under these Terms and
              each
            </li>
            <li>
              <strong>Joint account holders under these Terms</strong>: All
              references in these Terms to &ldquo;the Client&rdquo;,
              &ldquo;you&rdquo; or &ldquo;your&rdquo; shall be to both Joint
              Account holders except that:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  each individual Joint Account holder has authority to place
                  Orders, enter into Contracts and provide instructions to us on
                  behalf of both Joint Account holders; and
                </li>
                <li>
                  any notice or other communication which we are required to
                  give pursuant to these Terms will be treated as properly given
                  if it is given to only one of the Joint Account holders.
                </li>
              </ol>
            </li>
          </ol>
          <p id="tc11">
            <strong>11. FORWARD CONTRACTS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Forward Contract</strong>: If we accept an Order from you
              where the Value Date is later than two Business Days after the
              date of the Order, this Order will become a Forward Contract.
            </li>
            <li>
              <strong>Margin</strong>: A deposit, which is calculated as a
              percentage of the Purchase Price, will be agreed at the point of
              placing the Order and confirmed in the Deal Confirmation (&ldquo;
              <strong>Margin</strong>&rdquo;). You will immediately pay the
              Margin into Our Account on the date of the Deal You will pay any
              outstanding balance of the Purchase Price into Our Account no
              later than one Business Day before the Value Date.
            </li>
            <li>
              <strong>Margin Call</strong>: We have the right to request further
              deposits from you in the event that the spot exchange rate moves
              in a direction that makes your contract less valuable to you, such
              that the loss in value is equal to, or greater than 60% of the
              initial deposit at any time prior to full settlement of the
              Forward Contract (&ldquo;<strong>Margin Call</strong>&rdquo;). If
              we make a Margin Call, you must pay the additional deposit to us
              within 24 hours.
            </li>
            <li>
              <strong>Credit Limit</strong>: If you have been issued a credit
              limit, this will cover the initial Margin requirement in part or
              in full. However, Margin Calls will still apply should the value
              of the open Forward Contract(s) fall.
            </li>
            <li>
              <strong>Termination of Forward Contract</strong>: If you do not
              pay the Margin Call within 48 hours of our request, and the value
              of the Order continues to decrease, we reserve the right to
              terminate your Forward Contract to protect us against negative
              value positions. You agree that the Margin and any Margin Call may
              be retained by us to cover any losses that we may incur if the
              Forward Contract is terminated for reasons attributable to you.
              Any funds held once losses have been covered will be returned to
              you
            </li>
          </ol>
          <p id="tc12">
            <strong>12. YOUR OBLIGATIONS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              You agree to:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  provide complete and accurate sort code and account number
                  information or for international payments IBAN number for the
                  Recipient of the funds and you acknowledge that the funds will
                  be transmitted to the account details submitted by you;
                </li>
                <li>
                  examine all confirmations and communications sent by us within
                  a reasonable time after receiving them and to promptly advise
                  us of any mistake or discrepancy;
                </li>
                <li>
                  on request, supply us with all the information and
                  documentation necessary to enable us to comply with all
                  applicable laws and regulations, including the Money
                  Laundering Regulations 2007. For corporate Clients, this might
                  include proof of your registered office, principal business
                  address, confirmation of beneficial ownership, access to
                  corporate documentation (such as Memorandum and Articles of
                  Association) and proof of identity of any director and/or
                  Authorised Person. For private individuals this might include
                  proof of identity and residential address;
                </li>
                <li>
                  on request, supply us with complete and accurate details about
                  the Recipient (if different from the Client) including, as
                  applicable, date of birth, name and address details, passport
                  number and any other information required by our banking
                  partners;
                </li>
                <li>
                  promptly update us about any changes to your details held by
                  us;
                </li>
                <li>
                  not use, and to procure that your Authorised Persons do not
                  use, our Services for any speculative purpose or to try to
                  profit from exchange rate fluctuations; and
                </li>
                <li>
                  transfer the Purchase Price to Our Account promptly on or
                  after receipt of the Deal Confirmation. We will send you one
                  or more reminder emails if we have not received the Purchase
                  Price to Our Account within two Business Days. If we receive
                  no response or payment from you within five Business Days from
                  the date the order was approved, then we may terminate the
                  Contract in accordance with clause <a href="#tc15">15</a>. If you fail to honour
                  an order by not transferring your payment in full to our bank
                  account, you could be charged a cancellation fee and your
                  account will be locked until the cancellation fee is paid.
                </li>
              </ol>
            </li>
          </ol>
          <p id="tc13">
            <strong>13. FEES</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              You may be required to pay service, transaction and/or
              administration fees for our Services (&ldquo;<strong>Fee</strong>
              &rdquo;). If a Fee is payable, we will notify you of the Fee as
              follows:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  <strong>Online</strong>: if you place an Order through our
                  Website, on the screen;
                </li>
                <li>
                  <strong>Email Orders</strong>: by email prior to us processing
                  your Order;
                </li>
                <li>
                  <strong>Telephone Orders</strong>: during the telephone
                </li>
              </ol>
            </li>
          </ol>
          <p>
            You will be given the opportunity to confirm your Order after we
            have notified you of the Fee and prior to the Contract becoming
            binding on you.
          </p>
          <p  id="tc14">
            <strong>14. PAYMENT</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Spot Contracts</strong>: You will pay the Purchase Price
              under a Spot Contract in full into Our Account on such date or
              dates as we may direct, but no later than by 12 midnight on the
              second Business Day after the date of the Deal Confirmation.
            </li>
            <li>
              <strong>Payments</strong>: All payments due from you to us
              pursuant to a Contract must be made into Our Account in the
              currency specified in the Deal Confirmation without set-off,
              counterclaim or deduction whatsoever. We will not accept cash or
              cheques.
            </li>
            <li>
              <strong>Cut-off times</strong>: Banks have specified cut-off times
              for the receipt and dispatch of electronic payments. You
              acknowledge and agree that any delay in onward payment
              attributable to the cut-off times of the designated bank shall be
              a Disruption Event.
            </li>
            <li>
              <strong>Use of funds</strong>: All funds provided by you (whether
              as security or otherwise) to us may be used by us to settle any
              liability incurred on your behalf or exposure to an increased
              market risk (as we may decide in our sole discretion in respect of
              any Contract) or in the event that you are unable to pay your
              debts or you fail to comply with these Terms or any provision of a
            </li>
            <li>
              <strong>Dishonoured payments</strong>: If your payment is
              dishonoured or stopped for whatever reason, we shall charge an
              administration fee. The administration fee will be payable by the
              Client in addition to the amount due under the Contract. The
              administration fee will reflect any additional costs or fees
              incurred by RationalFX.
            </li>
            <li>
              <strong>Bank charges</strong>: You will be solely responsible for
              any charges applied by your bank or the Recipient&rsquo;s bank
              resulting from the receipt of funds into Your Nominated Bank
              Account.
            </li>
            <li>
              <strong>Interest on outstanding balance</strong>: If you fail to
              make a payment in full or in part, the outstanding balance shall
              bear interest from the Value Date at the rate of 4 per cent per
              annum above the base rate of the Bank of England. Such interest /
              charges will accrue from the due date until RationalFX are in
              receipt of settlement in full, in clear funds by the Client.
            </li>
            <li>
              <strong>No interest payable on funds held by us: </strong>You
              acknowledge and agree that we will not pay to you any interest on
              any funds held by us whether by way of deposit or otherwise.
            </li>
          </ol>
          <p id="tc15">
            <strong>15. TERMINATION OF THESE TERMS OR A CONTRACT</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Our right to terminate</strong>: We may terminate all or
              part of any Contract without giving prior notice or any liability
              to you at any time after the occurrence of any of the following
              events:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  the Client fails to comply with any of its obligations under
                  these Terms or a Contract (including its obligation to pay the
                  Purchase Price, Margin or any other sums to us);
                </li>
                <li>
                  the Client fails to provide any information or documentation
                  requested by us as part of our regulatory obligations;
                </li>
                <li>
                  where the Client is an individual, the death of the Client;
                </li>
                <li>
                  it becomes or may become unlawful for us to provide our
                  Services to you under the Contract;
                </li>
                <li>
                  we are requested to terminate the Contract (or any part
                  thereof) by any regulatory authority, whether or not the
                  request is legally binding;
                </li>
                <li>
                  you are unable to pay your debts as they become due or you
                  have a bankruptcy position presented against you, or you
                  propose a form of composition or arrangement to your
                  creditors, or if you cease or threaten to cease to carry on
                  all or a part of your business; or
                </li>
                <li>
                  where any of the events specified above, or anything analogous
                  thereto, occurs under the laws of any applicable jurisdiction.
                </li>
              </ol>
            </li>
            <li>
              <strong>Notice of an event</strong>: If you become aware of the
              occurrence of any event referred to in this clause{" "}
              <a href="#tc15">15,</a> you must give us immediate written
              notice of such event.
            </li>
            <li>
              <strong>No Payment of Profit</strong>: We will not pay you any
              profit arising from terminating a Contract in any circumstances.
            </li>
            <li>
              <strong>Your right to terminate </strong>You will have the right
              to terminate all or part of any Contract without giving prior
              notice or any liability to us at any time if we commit a serious
              breach of our obligations under these Terms or a Contract or we
              are unable to pay our debts as they become due or we have a
              bankruptcy position presented against us, or we propose a form of
              composition or arrangement to our creditors, or if we cease or
              threaten to cease to carry on all or a part of our business.
            </li>
            <li>
              If your Contract is for our Regular Payments Service:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  you may terminate these Terms and any Contract made under
                  these Terms by giving one month&rsquo;s notice to us provided
                  that you will be liable to pay and costs incurred by us which
                  result from your termination; and
                </li>
                <li>
                  we may terminate the Contract by giving two months&rsquo;
                  notice to
                  <br />
                  Any notice of termination given pursuant to this clause shall
                  be subject to any Contract which has not been settled, closed
                  or terminated prior to the termination date specified in the
                  notice of termination.
                </li>
              </ol>
            </li>
          </ol>
          <p id="tc16">
            <strong>16. OUR LIABILITY TO YOU</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>No liability for delays</strong>: You acknowledges that
              delays in the transmission and receipt of payments may occur. In
              particular, you acknowledge that we operate an online dealing
              platform that could be subject to technical, or other, problems,
              the nature and duration of which may be beyond our Our Services
              also involve the use of intermediaries who are outside our
              control. Accordingly, while we do everything in our power to
              ensure the timely transmission of funds, we cannot guarantee that
              transfers of funds will always be made on time and cannot accept
              any liability to you for any loss suffered by you or any other
              person as a result of any delays in the transmission of funds.
            </li>
            <li>
              <strong>Exclusions of certain types of loss</strong>: We are not
              liable, whether in contract, tort (including negligence) or
              otherwise in connection with these Terms or any Contract for any:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>indirect or consequential loss or damage;</li>
                <li>
                  loss of business, loss of opportunity, loss of profits or
                  contracts or loss of interest on funds;
                </li>
                <li>
                  loss of damage caused as a result of inaccurate or misleading
                  information provided to us by the Client or an Authorised
                  Person;
                </li>
                <li>
                  loss or damage caused by an Authorised Person providing us
                  with instructions which are against the Client&rsquo;s
                  interests or outside of the scope of the Client&rsquo;s actual
                  authority; or
                </li>
                <li>loss or damage caused by our refusal to accept an</li>
              </ol>
            </li>
            <li>
              <strong>Maximum liability</strong>: Subject to clause{" "}
              <a href="#tc10">10,</a> our total liability in connection
              with our performance or contemplated performance of the Contract
              is limited to the amount of the Purchase Price.
            </li>
            <li>
              <strong>Liability not excluded</strong>: Nothing in these Terms
              shall exclude or limit our liability for death or personal injury
              or fraud or fraudulent misrepresentation.
            </li>
            <li>
              <strong>
                Our liability for incorrect, unauthorised or defective payments
              </strong>
              : You must notify us without undue delay (and in any event within
              13 months of the payment date) if we make any unauthorised or
              incorrect payment of your funds.
            </li>
            <li>
              We will then immediately investigate your claim and notify you of
              the If, following our investigation, we reasonably consider that
              the payment was in fact authorised and made correctly, we will
              provide evidence of this to you.
            </li>
            <li>
              However, if we discover that the payment was not authorised and/or
              was made incorrectly, we will immediately refund the amount of the
              unauthorised or incorrect payment to you and reimburse you for any
              charges or interest for which you become liable as a result of the
              unauthorised or incorrect payment provided that we will not be
              liable if you notify us of the error more than 13 months of the
              payment date.
            </li>
            <li>
              If you notify us that a payment which is due has not been
              correctly made, we will make immediate efforts to trace the
              payment transaction and notify you of the If we are unable to
              prove that the payment has been made to the Recipient within the
              timeframe specified in the Contract, we will repay you the
              Purchase Price (or the part of the Purchase Price if the payment
              is only partially defective) and reimburse you for any charges or
              interest for which you become liable as a result of the defective
              payment.
            </li>
            <li>
              We will not be liable to you for an allegedly incorrect,
              unauthorised or defective payment if you provide us with incorrect
              or incomplete:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  Sort code and/or account number for payments to a UK bank
                  account; or
                </li>
                <li>
                  The IBAN number for international payments,
                  <br />
                  however, we will make reasonable efforts to recover the funds
                  provided that you pay any costs we reasonably incur in doing
                  so.
                </li>
              </ol>
            </li>
            <li>
              We will not be liable to you for any (allegedly or actual)
              incorrect, unauthorised or defective payment or for any other
              failure under Part 7 of the Payment Services Regulations where
              this is attributable to:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  abnormal and unforeseeable circumstances beyond our control,
                  the consequences of which would have been unavoidable despite
                  all efforts to the contrary; or
                </li>
                <li>
                  our other legal obligations imposed by national or EU law, and
                  clause <a href="#tc18">18</a> shall not apply to such
                  failure.
                </li>
              </ol>
            </li>
          </ol>
          <p id="tc17">
            <strong>17. YOUR LIABILITY TO US</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              Subject to clause <a href="#tc2">2,</a> you shall be
              liable to us and repay us for any loss or damage suffered by us as
              a result of your (or an Authorised Person&rsquo;s) breach of these
              Terms or any Contract, or fraudulent use of our Services. This
              includes any legal costs that we may incur in order to enforce our
              rights or recover any amounts you owe us.
            </li>
            <li>
              You are liable to us:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  up to a maximum of &pound;35 for each instance of fraud; and
                </li>
                <li>for all unauthorised transactions if you act</li>
              </ol>
            </li>
          </ol>
          <p id="tc18">
            <strong>18. DISRUPTION EVENT</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>No liability in case of the Disruption Event</strong>:
              Neither party will breach these Terms or any Contract nor be
              liable for delay in performing or failure to perform any of its
              obligations under any Contract if such delay or failure results
              from a Disruption Event for the period of time during which the
              Disruption Event continues. We will if necessary contact you as
              soon as reasonably possible to notify you of a Disruption Event
              which has resulted in our delay or failure to perform any of our
              obligations under a Contract.
            </li>
            <li>
              <strong>
                Right of termination for long term Disruption Event
              </strong>
              : If the period of delay or non- performance continues for
              twenty-eight Business Days then you or we may terminate any
              Contract made between us by giving five Business Days written
              notice to the other party.
            </li>
          </ol>
          <p id="tc19">
            <strong>19. COMPLAINTS</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              We aim to provide the highest level of customer service possible.
              If you do experience a problem, we will always seek to resolve
              this as quickly and efficiently as possible. You can request a
              copy of our complaints procedure by emailing{" "}
              <a href="mailto:care@xmonies.com">care@xmonies.com</a> or by
              writing to XeOPAR at H -187, Sector 63, Noida, Gautam Buddha
              Nagar, U.P., India.
            </li>
            <li>
              In the unlikely event that you are dissatisfied with any of our
              Services, in the first instance, in accordance with our complaint
              procedures, you should inform us of the complaint as soon as you
              can in writing. Where the initial complaint is verbal it must be
              followed up immediately with a written complaint to the Complaints
              Manager at H -187, Sector 63, Noida, Gautam Buddha Nagar, U.P.,
              India.
            </li>
            <li>
              If you are dissatisfied with our response you may refer the matter
              to the Financial Ombudsman Service situated at South Quay, 183
              Marsh Wall, London, E14 9SR.
            </li>
          </ol>
          <p id="tc20">
            <strong>20. NOTICES</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              Where any notice is required by our Terms to be given in writing,
              it must be written in the English language and:
              <ol style={{ listStyleType: "lower-roman" }}>
                <li>
                  where it is to be given by the Client, it must be sent by
                  email to{" "}
                  <a href="mailto:care@xmonies.com">care@xmonies.com</a> or by
                  post to H -187, Sector 63, Noida, Gautam Buddha Nagar, U.P.,
                  India; or
                </li>
                <li>
                  where it is to be given by XeOPAR, it must be sent by email to
                  your registered email address or by post to you registered
                  postal address.
                </li>
              </ol>
            </li>
            <li>
              Any notice sent by email will be treated as being received on the
              first Business Day after the day on which it was sent and any
              notice sent by post will be treated as being received on the
              second Business Day after the day on which it was posted.
            </li>
            <li>
              In the event that we suspect any fraudulent activity in relation
              to any of your Orders, we will attempt to contact you using a
              secure method in order to discuss such suspicious or fraudulent
            </li>
          </ol>
          <p id="tc21">
            <strong>21. GENERAL</strong>
          </p>
          <ol style={{ listStyleType: "lower-alpha" }}>
            <li>
              <strong>Interpretation</strong>: Any words following the terms{" "}
              <strong>including</strong>, <strong>include</strong>,{" "}
              <strong>in particular</strong>, <strong>for example </strong>or
              any similar expression shall be construed as illustrative and
              shall not limit the sense of the words, description, definition,
              phrase or term preceding those terms.
            </li>
            <li>
              <strong>Third party rights</strong>: No third party has the right
              to any benefit under or to enforce any The Contract (Rights of
              Third Parties) Act 1999 shall not apply to the agreement.
            </li>
            <li>
              <strong>Relationship</strong>: Nothing in these Terms and no
              Contract will create a partnership, joint venture or agency
              relationship between the parties.
            </li>
            <li>
              <strong>Continuance after termination</strong>: Clauses <a href="#tc15">15</a> (Our
              Liability to You), <a href="#tc16">16</a> (Your Liability to Us), <a href="#tc18">18</a> (Payment Services
              Regulations 2009) and <a href="#tc21">21</a> (General) will continue to be valid upon
              termination of any Order or Contract.
            </li>
            <li>
              <strong>Entire agreement</strong>: The Deal Confirmation of a
              Contract and these Terms form the entire agreement and
              understanding between us and you concerning that Contract. No
              other discussions, telephone conversations, email communications,
              documents or materials form part of the Contract.
            </li>
            <li>
              <strong>Severance</strong>: Should any of our Terms be deemed
              unenforceable or illegal, the remaining terms and conditions will
              nevertheless continue in full force and effect.
            </li>
            <li>
              <strong>Assignment</strong>: You may not assign or otherwise
              transfer the benefit of any Contract without our express written
              We may assign our rights and obligations under any Contract to any
              third party.
            </li>
            <li>
              <strong>Conflict</strong>: Should any of our Terms conflict with
              the Deal Confirmation, the Deal Confirmation will take precedence
              and apply.
            </li>
            <li>
              <strong>Language</strong>: These Terms, and any Contract between
              us, are only in the English
            </li>
            <li>
              <strong>Governing law</strong>: These Terms and the Contract will
              be governed and construed in accordance with English Law and the
              courts of England and Wales will have exclusive jurisdiction to
              determine any dispute arising in relation to them.
            </li>
          </ol>
          <p id="tc22">
            <strong>22. DEFINITIONS</strong>
          </p>
          <p>
            <strong>Authorised Person </strong>means an individual who is
            authorised by you and accepted by us to place Orders and provide
            instructions on your behalf.
          </p>
          <p>
            <strong>Business Day </strong>means 8am to 6pm Monday to Friday
            excluding Bank Holidays and Public Holidays in England (please note
            that this is different to our office hours, details of which are
            published on our Website).
          </p>
          <p>
            <strong>Client </strong>means the customer, being the private
            individual or company, which registers for our Services and/or with
            whom we enter a Contract.
          </p>
          <p>
            <strong>Client Profile </strong>means the personal and other
            information provided by you when registering for an account with us,
            including your contact details which may be updated by logging in to
            your account through our Website.
          </p>
          <p>
            Commercial Card means any card-based payment instrument issued to
            undertakings or public sector entities or self-employed natural
            persons which is limited in use for business expenses where the
            payments made with such cards are charged directly to the account of
            the undertaking or public sector entity or self-employed natural
            person;
          </p>
          <p>
            <strong>Contract </strong>means the contract between the Client and
            RationalFX for the performance of an Order in relation to an
            Unregulated Foreign Exchange Contract and which will either be a
            Single Payment Service Transaction or part of a Regular Payments
            Service.
          </p>
          <p>
            <strong>Deal Confirmation </strong>means a written document which
            sets out the details of the contract between RationalFX and the
            Client.
          </p>
          <p>
            <strong>Disruption Event </strong>means any circumstances outside of
            a party&rsquo;s control including any interruptions or failures
            relating to Service Providers or other third parties, internet
            service providers, internet signal, connections, electricity
            providers, failure of banks or banking systems, configurations of
            computers, any acts of god, flood, drought, earthquake or other
            natural disaster, any collapse of buildings, fire, explosion or
            accident, any act of terrorism, civil war or commotion, riots or any
            law or any action taken by a government or public authority,
            including failing to grant a necessary licence or consent.
          </p>
          <p>
            <strong>Forward Contract </strong>means a Contract for a currency
            transaction where the Value Date is later than two Business Days
            after the Order date.
          </p>
          <p>
            <strong>Joint Account </strong>means a registration made by two
            private individuals jointly.
          </p>
          <p>
            <strong>Limit Order </strong>means a Contract comprising the buying
            or selling of a currency at a predetermined exchange rate which is
            above or below the current currency exchange rate.
          </p>
          <p>
            <strong>Major Currency </strong>means the US dollar, Euro, Japanese
            yen, Pound sterling, Australian dollar, Swiss franc, Canadian
            dollar, Hong Kong dollar, Swedish krona, New Zealand dollar,
            Singapore dollar, Norwegian krone, Mexican peso, Croatian kuna,
            Bulgarian lev, Czech koruna, Danish krone, Hungarian forint, Polish
            złoty and Romanian leu.
          </p>
          <p>
            <strong>Margin </strong>has the meaning given to it at clause <a href="#tc11">11.2</a>.
          </p>
          <p>
            <strong>Margin Call </strong>has the meaning given to it at clause
            <a href="#tc11">11.3</a>.
          </p>
          <p>
            <strong>Order </strong>means your verbal or written request for us
            to perform Services on your behalf.
          </p>
          <p>
            <strong>Our Account </strong>means the bank account specified in the
            Deal Confirmation into which you must pay any sums due to us under a
            Contract<strong>.</strong>
          </p>
          <p>
            <strong>Payment Services Regulations </strong>means the Payment
            Services Regulations 2009 (SI 2009/209) and from 13 January 2018,
            means the Payment Services Regulations 2017 (SI 2017/252), which
            repeals and replaces the Payment Services Regulations 2009.
          </p>
          <p>
            <strong>Purchase Price </strong>means the sums payable by you to us
            for the currency purchased under a Contract together with any fees
            and costs payable under the Contract.
          </p>
          <p>
            <strong>Recipient </strong>means the beneficiary of the money
            transfer specified in the Deal Confirmation, which may be the Client
            or a third party.
          </p>
          <p>
            <strong>Regular Payments Service </strong>means an arrangement where
            the Client instructs us to carry out a series of separate Spot
            Contracts or Forward Contracts on their behalf, for example where
            the Client wishes to set up regular monthly payments
            <strong>.</strong>
          </p>
          <p>
            <strong>Services </strong>means our services which comprise of (i)
            entering into contracts for the purchase and sale of currency on
            behalf of our Clients; and (ii) our money transmission service and
            which will be either a Single Payment Service or a Regular Payments
            Service.
          </p>
          <p>
            <strong>Service Provider </strong>means a bank, cash pick up office,
            money exchange house or other third party providing cash or
            electronic funds transfer or electronic payment to a Recipient.
          </p>
          <p>
            <strong>Single Payment Service Transaction </strong>means a single
            Spot Contract or Forward Contract which is not part of a Regular
            Payments Service
          </p>
          <p>
            <strong>Spot Contract </strong>means a Contract for a currency
            transaction where the Value Date is one of the following:
          </p>
          <ul>
            <li>
              two Business Days after the date of the Deal Confirmation for a
              Major Currency
            </li>
            <li>
              where one of the currencies involved in a transaction is not a
              Major Currency, the longer of 2 Business Days and the period
              generally accepted in the market for that currency pair as the
              standard delivery period.
            </li>
          </ul>
          <p>
            <strong>Terms </strong>means these terms and conditions which set
            out the framework for a Regular Payments Service and which also set
            out the terms and conditions for a Single Payment Service
            Transaction. Unless a
          </p>
          <p>
            particular clause or sub-clause provides otherwise, the terms and
            conditions apply to both a Regular Payments Service and a Single
            Payment Service transaction.
          </p>
          <p>
            <strong>Unregulated Foreign Exchange Contract </strong>means a
            contract for a foreign exchange product offered by RationalFX from
            time to time which is either a Spot Contract or foreign exchange
            contract that:
          </p>
          <ul>
            <li>
              is settled physically otherwise than by reason of a default or
              other termination event; and
            </li>
          </ul>
          <ul>
            <li>
              is entered into in order to facilitate payment for identifiable
              goods, services or direct <strong>Value Date </strong>means the
              date on which the currency is due to be transferred to the
              Recipient. <strong>Website </strong>means XeOPAR remittance
              platform website at{" "}
              <a href="http://www.xmonies.com">www.xmonies.com</a>.
            </li>
          </ul>
          <p>
            <strong>XeOPAR, we, us, our </strong>means XeOPAR Fintech Private
            Limited, a company registered in India under The Companies Act 2013
            [CIN U67100UP2018PTC107164] and whose registered and head office is
            at H -187, Sector 63, Noida, Gautam Buddha Nagar, U.P., India.
          </p>
          <p>
            <strong>Your Nominated Account </strong>means the Recipient&rsquo;s
            bank account details as specified in your Order and confirmed in the
            Deal Confirmation.
          </p>
        </div>
      )}
      <button
        className="showmore-button"
        onClick={() => setShowMore(!showMore)}
      >
        {showMore ? "View Less" : "View More"}
      </button>
    </div>
  );
}
