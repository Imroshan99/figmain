import axios from "axios";
import { config } from "../config";
// import { AuthService } from "../services/AuthService";

export const BankAccountAPI = {
    checkDuplicateBankAccount: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/check-duplicate-send-account`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    addBankAccount: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/add-send-bank-accounts`, 
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    bankAccountList: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/send-bank-account-lists`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    validateBankCode: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/validate-bank-codes`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    viewBankAccountDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/send-bank-accounts`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
    deleteBankAccountDetails: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/usr/acc/delete-send-bank-account`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    }


}