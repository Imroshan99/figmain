import axios from "axios";
import { config } from "../../config";
// import { AuthService } from "../services/AuthService";

export const VIAmericaTransactionAPI = {
  rate: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  ViaPriceQuote: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-price-quote`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  ViaCalculateCost: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-calculate-cost`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viAmericaSenderBalanceCheck: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-sender-balance-chcek`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  cancelTransactions: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/cancel-transactions`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viAmericaTransactionValidate: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/viAmericaTransactionValidate`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viAmericaBestRates: async (data) => {
    return await axios.post(`${config.API_URL}/services/txn/vi-america-best-rates`, data);
  },
};
