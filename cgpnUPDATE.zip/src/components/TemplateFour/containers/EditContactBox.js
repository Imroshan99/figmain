import React, { useState, useEffect } from "react";
import { Form, Input, Select, Modal, notification } from "antd";
import { Row, Col } from "react-bootstrap";
import Spinner from "../../../reusable/Spinner";
import InputOTPBox from "../../../containers/InputOTPBox";
import CustomInput from "../../../reusable/CustomInput";
const { Option } = Select;

export default function EditContactBox(props) {
  const [form] = Form.useForm();

  useEffect(() => {
    form.setFieldsValue({
      mobilePhoneCode: props.state.mobilePhoneCode,
      mobileNo: props.state.mobileNo,
      communicationEmailID: props.state.emailId,
    });
    props.setState({
      editablemobilePhoneCode: props.state.mobilePhoneCode,
      editableMobileNo: props.state.mobileNo,
    });
  }, []);

  useEffect(() => {
    if (props.state.senderContactDetailsErrors) {
      let errors = [];
      props.state.senderContactDetailsErrors.forEach((error, i) => {
        let errorData = {
          name: error.field,
          errors: [error.error],
        };
        errors.push(errorData);
      });
      form.setFields(errors);
    } else {
      form.setFields([{ name: "mobileNo", errors: [] }]);
    }
  }, [props.state.senderContactDetailsErrors]);

  const onFinish = (value) => {
    if (props.state.editContactTab === "3") {
      // props.setState({twofa:"Y"})

      if (!props.state.OTPVerifed) {
        // props.editSenderContactdtls(props.state.otpVerfiedToken);
        // props.setState({ otpVerfiedToken: "" });
        if (props.state.emailId1==="") {
          notification.error({ message: "Your Email is same as before" });
         }else{          
           props.sendOTP("CU", "Edit_Contact");
           props.setState({ twofaAuth: "Y" });
         }
      }
    } else {
      props.setState({ twofaAuth: "N" });
    }
    if (props.state.twofa === "Y") {
      props.sendOTP("CU", "Edit_Contact");
    }
  };

  return (
    <>
      <Modal centered className="primary" width={500} visible={props.state._isShowContactEditModel} onCancel={() => props.setState({ _isShowContactEditModel: false })} footer={null}>
        <Form
          className="contact_details_form"
          form={form}
          onFinish={onFinish}
          initialValues={{
            mobileNo: props.state.mobileNo,
            phoneNo: props.state.phoneNo,
          }}
        >
          <Spinner spinning={props.loader}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Row>
                  <div className="p-0 mb-4">
                    <h4>Contact details</h4>
                  </div>
                </Row>

                {props.state.editContactTab == 1 && (
                  <>
                    <Col md={4}>
                      <label className="form-label">Country Code</label>
                      <CustomInput className="form-item w-100" name="mobilePhoneCode" label="Country Code" showLabel={false} required type="select" size="large" placeholder="Select Country Code" showSearch optionFilterProp="children" onSelect={(v) => props.setState({ editablemobilePhoneCode: v })}>
                        {props.state.phoneCodes.map((list, i) => {
                          return (
                            <Option key={i} value={list.countryPhoneCode}>
                              +{list.countryPhoneCode} ( {list.countryName})
                            </Option>
                          );
                        })}
                      </CustomInput>
                      
                    </Col>
                    <Col md={8}>
                      <label className="form-label">Mobile</label>
                      <CustomInput
                        className="form-item"
                        name="mobileNo"
                        label="Mobile"
                        showLabel={false}
                        min={10}
                        max={10}
                        onChange={(e) => props.setState({ editableMobileNo: e.target.value })}
                        size="large"
                        placeholder="Enter your Mobile"
                        required
                        validationRules={[
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      />
                      
                    </Col>
                  </>
                )}
                 
                {props.state.editContactTab == 3 && (
                  <Col md={12}>
                    <label className="form-label">Communication Email ID</label>
                    <CustomInput className="form-item" name="communicationEmailID" type="email" label="Communication Email ID" showLabel={false} onChange={(e) => props.setState({ emailId1: e.target.value })} disabled={props.state.disabled} size="large" placeholder="Enter your Communication Email ID" required />
                    
                    {props.state.otpBoxEmail && (
                      <>
                        <InputOTPBox state={props.state} setState={props.setState} otpType="UL" useFor="signup" appState={props.appState} setCurrent={props.setCurrent} setLoader={props.setLoader} editSenderContactdtls={props.editSenderContactdtls} />
                      </>
                    )}
                  </Col>
                )}
                {!props.state.otpBoxEmail && (
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button className="btn btn-danger btn-block px-4" onClick={() => props.setState({ _isShowContactEditModel: false })} type="button">
                      Cancel
                    </button>
                    <button disabled={props.state.OTPVerifed ? false : props.state.disabled} className="btn btn-secondary px-4">
                      {props.state.editContactTab == 3 ? "Update" : "Submit"}
                    </button>
                  </div>
                )}
              </Row>
            </div>
          </Spinner>
        </Form>
      </Modal>
    </>
  );
}
