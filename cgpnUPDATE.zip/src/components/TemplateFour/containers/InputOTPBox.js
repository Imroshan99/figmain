import React, { useState, useEffect, useReducer } from "react";
import { Form, Input, notification } from "antd";
import { config } from "../config";
import moment from "moment";
import { GuestAPI } from "../apis/GuestAPI";
import { useSelector } from "react-redux";
import { encrypt, decrypt, publickey } from "../helpers/makeHash";
import CustomInput from "../../../reusable/CustomInput";

export default function InputOTPBox(props) {
  const [valids, setValids] = useState("");
  const [stateOtp, SetStateOtp] = useState({ otp: "" });
  const [btn, setBtn] = useState(false);

  const ConfigReducer = useSelector((state) => state.user);
  const [form] = Form.useForm();
  const [intervalID, setInterID] = useState(); // created a useState for intervalID

  const [reverseTimer, setReverseTimer] = useState("5m 00s");
  const [otpVerificationToken, setVerificationToken] = useState("");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
    }
  );

  useEffect(() => {
    reverseTimerOnLoad();
  }, []);

  useEffect(() => {
    setVerificationToken(props.state.verificationToken);
  }, [props.state.verificationToken]);

  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(5, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID); // took letintervalID and stored it in useState intervalID
  };
  const onFinish = (e) => {
    e.preventDefault();
    form.setFields([{ name: "otp", errors: [] }]);

    const optData = {
      requestId: config.requestId,
      requestType: "VERIFYOTP",
      channelId: config.channelId,
      clientId: state.clientId,
      groupId: state.groupId,
      sessionId: state.sessionId,
      ipAddress: "127.0.0.1",
      otpType: props.otpType,
      verificationToken: otpVerificationToken,
      otp: stateOtp.otp,
    };

    if (props.useFor == "addRecipient") {
      optData.accountNo = props.state.formData.accountNo;
    }

    if (config.IS_ENC) {
      var key = config.key;
      var iv = config.iv;
      var body = encrypt(optData, key, iv);
      var pubValue = iv.concat(key);
      var identifier = publickey(props.appState.publicKey, pubValue);

      var postData = {
        body: body,
        identifier: identifier,
      };
    } else {
      var postData = optData;
    }

    GuestAPI.verifyOTP(postData)
      .then((res) => {
        setValids(res.data.errorMessage);
        if (config.IS_ENC) {
          var decode = decrypt(res.data.body, key, iv);
          var decodeData = JSON.parse(decode);
        } else {
          var decodeData = res.data;
        }
        clearInterval(intervalID);
        if (decodeData.status == "S") {
          props.setState({ isModalVisible: false });

          if (props.useFor == "signup") {
            props.setState({
              verifiedToken: decodeData.verifiedToken,
            });
            props.checkDedupe(decodeData.verifiedToken);
          } else if (props.useFor == "login") {
            props.setState({ verifiedToken: decodeData.verifiedToken });
            props.storeLoginData(props.state.loginData);
          } else if (props.useFor == "addRecipient") {
            props.saveReceiver(decodeData.verifiedToken);
          } else if (props.useFor == "Edit_Address") {
            props.editProfile(decodeData.verifiedToken);
          } else if (props.useFor == "Edit_Contact") {
            setTimeout(() => {
              props.editSenderContactdtls(decodeData.verifiedToken);
            }, 1000);
          } else if (props.useFor == "Edit_Marketing") {
            props.editProfile(decodeData.verifiedToken);
          } else if (props.useFor == "forgot_password") {
            props.setState({
              verifiedToken: decodeData.verifiedToken,
              _isShowSuccessMessage: true,
            });
          } else if (props.useFor == "unlock_account") {
            props.onUnlockAccountHandler();
          }
          props.setCurrent((prev) => prev + 1);
        } else {
          notification.error({ message: res.data.errorMessage });

          props.validOtp(res.data.errorMessage);
          let errors = [];
          res.data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {});
  };

  return (
    <div visible={props.state.isModalVisible}>
      <Form form={form} onFinish={(values) => {}}>
        <>
          <div className="mb-3">
            <label className="step-label mb-1">Enter OTP</label>
            <CustomInput
              className="form-item text-start"
              name="otp"
              label="Enter OTP"
              showLabel={false}
              required
              validationRules={[
                {
                  pattern: /^[0-9\b]+$/,
                  message: "Only Numbers allowed",
                },
              ]}
              size="large"
              onChange={(e) => {
                SetStateOtp({ otp: e.target.value });
                e.target.value.length == 6 ? setBtn(true) : setBtn(false);
              }}
              onPaste={(e) => {
                e.preventDefault();
                return false;
              }}
              onCopy={(e) => {
                e.preventDefault();
                return false;
              }}
              onCut={(e) => {
                e.preventDefault();
                return false;
              }}
            />
             
            <span id="invalid-otp">{valids}</span>
          </div>

          <button className={`btn btn-primary text-white my-1 w-100`} disabled={!btn} onClick={onFinish}>
            Next
          </button>
        </>
      </Form>
    </div>
  );
}
