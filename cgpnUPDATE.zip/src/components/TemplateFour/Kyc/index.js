import { useSelector } from "react-redux";
import Dashboard from "../Layouts/Dashboard";
import KycFlowOne from "./KycFlowOne/index";
import KycFlowTwo from "./KycFlowTwo/index";
import KycFlowThree from "./KycFlowThree/Kyc";
import { useOutletContext } from "react-router-dom";
import { useEffect } from "react";

const Kyc = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.kyc?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Complete Your KYC");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <KycFlowOne appState={props.appState} manageAuth={props.manageAuth} />
      )}
      {templateFlow === "FLOW2" && (
        <KycFlowTwo appState={props.appState} manageAuth={props.manageAuth} />
      )}
      {templateFlow === "FLOW3" && (
        <KycFlowThree appState={props.appState} manageAuth={props.manageAuth} />
      )}
    </>
  );
};

export default Kyc;
