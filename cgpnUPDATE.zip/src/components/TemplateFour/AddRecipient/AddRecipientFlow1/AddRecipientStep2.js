import React, { useEffect, useReducer } from "react";
import { Form, Input, Select, notification, AutoComplete } from "antd";
import { useLocation } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { Row, Col } from "react-bootstrap";
import { inputValidations } from "../../../../services/validations/validations";
import CustomInput from "../../../../reusable/CustomInput";

const { Option } = Select;
const { TextArea } = Input;

export default function AddRecipientStep2(props) {
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const AddRecipientFormConfig =
    ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
  const location = useLocation();

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      twofa: AddRecipientFormConfig?.twoFA
        ? AddRecipientFormConfig.twoFA
        : AuthReducer.twofa,
      // twofa:   AuthReducer.twofa,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      nationalities: [],
      stateCities: [],
      _showOTPBOX: false,
      showConfirmAddRecipient: false,
      isConfirmAddRecipient: false,
      formData: {},
      verificationToken: "",
      isOTPVerfied: false,
      isModalVisible: false,
      otpType: "RA",
      branchCode: "",
      bankBranch: "",
      bankAddress: "",
      bankState: "",
      bankCity: "",
      bankName: "",
      isSameBank: "N",
      bankCode: "",
      bankId: "",
      bankCountry: "",
      isSelectedIFSC: false,
      bankLists: [],
      cityLists: [],
      branchLists: [],
      phoneCodes: [],
      occupationLists: [],
      relationshipLists: [],
      deliveryOptionsList: [],
      deliveryOption: "",
      stateLists: [],
      dob: "",
      redirectPage: "",
      redirectPageState: [],
      receiverCountryLists: [],
      receiverCountry: "",
      receiverCountryCode: "",
    }
  );

  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetRelationshipLists = useHttp(GuestAPI.relationshipLists);
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookGetReceiverCountryLists = useHttp(GuestAPI.receiverCountryList);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);

  useEffect(async () => {
    getDeliveryOptions();
    getCoutryCodes();
    getRelationshipLists();
    getStateLists();
    getReceiverCountryLists();
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
  }, []);

  useEffect(async () => {
    if (!state.isSelectedIFSC) {
      getBankList();
    }
  }, [state.isSelectedIFSC]);

  const getReceiverCountryLists = () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: "GB",
      sendCurrency: "GBP",
    };

    hookGetReceiverCountryLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          receiverCountryLists: data.responseData,
        });
        props.newForm1.setFieldsValue({
          country: data.responseData[0].countryName,
        });
      }
    });
  };

  const getStateCityList = async (stateCode) => {
    const payload = {
      requestType: "CITILIST",
      keyword: "",
      stateCode: stateCode,
      countryCode: AuthReducer.recvCountryCode,
    };

    props.setLoader(true);
    hookGetStateCities.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ stateCities: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
        setState({ stateCities: [] });
      }
      props.setLoader(false);
    });
  };
  const handleReceivingCountry = (data) => {
    setState({
      receiverCountry: data,
    });
  };
  const onSelectState = (value) => {
    getStateCityList(value);
  };

  const getCoutryCodes = async () => {
    if (AuthReducer.groupId === "XR") {
      setState({
        phoneCodes: [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
        ],
        selectPhoneCodes: true,
      });
    } else {
      const payload = {
        requestType: "COUNTRYPHONECODE",
      };
      props.AddRecipientFormsetLoader(true);
      hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
        if (data.status == "S") {
          let _recvCountryCode = data.responseData.filter(
            (item) => item.countryCode === AuthReducer.recvCountryCode
          );

          setState({
            phoneCodes: data.responseData,
            selectPhoneCodes: false,
            // mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
          });
          props.newForm1.setFieldsValue({
            mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
          });
          props.setLoader(false);
        }
      });
    }
  };

  const getRelationshipLists = async () => {
    let payload = {
      requestType: "RELAIONSHIPLISTS",
    };

    props.setLoader(true);
    hookGetRelationshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ relationshipLists: data.responseData });
      }
      props.setLoader(false);
    });
  };

  const getDeliveryOptions = async () => {
    let payload = {
      requestType: "RECVMODE",
      countryCode: AuthReducer.recvCountryCode,
    };
    props.setLoader(true);
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ deliveryOptionsList: data.responseData });
        props.setLoader(false);
      }
    });
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.recvCountryCode,
      keyword: "",
    };
    props.setLoader(true);
    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        props.setLoader(false);
      }
    });
  };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.recvCountryCode,
      userId: state.userID,
    };

    props.setLoader(true);
    hookGetBankLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
        props.setLoader(false);
      }
    });
  };

  let onFinish = (values) => {
    let finalValue = { ...values };
    finalValue.relationship = JSON.parse(finalValue.relationship);
    props.onFinish(finalValue);
  };

  return (
    <div>
      <Form form={props.newForm1} autoComplete="none" onFinish={onFinish}>
        <div className="addRecipentModalSetp2">
          <div className="addRecipentModalSetp2-inside-container">
            <Row>
              <Col sm={12} md={4}>
                <Row>
                  <div className="Container">
                    <CustomInput name="firstName" label="First Name" min={2} max={30} required autoComplete="none" />
                    {/* <label>First Name</label>
                    <Form.Item
                      name="firstName"
                      rules={[
                        {
                          required: true,
                          message: "Please input your First Name.",
                        },
                        {
                          min: 2,
                          message:
                            "First Name should be between 2 and 30 characters",
                        },
                        {
                          max: 30,
                          message:
                            "First Name should be between 2 and 30 characters",
                        },
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput name="middleName" label="Middle Name" min={1} max={30} autoComplete="none" required />
                    {/* <label>Middle Name</label>
                    <Form.Item
                      name="middleName"
                      rules={[
                        {
                          min: 1,
                          max: 30,
                          message: "Middle Name should be between 1 and 30 characters",
                        },
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput name="lastName" label="Last Name" min={2} max={30} required autoComplete="none" />
                    {/* <label>Last Name</label>
                    <Form.Item
                      name="lastName"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Last Name.",
                        },
                        {
                          min: 2,
                          message: "Last Name should be between 2 and 30 characters",
                        },
                        {
                          max: 30,
                          message: "Last Name should be between 2 and 30 characters",
                        },
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput
                      name="nickName"
                      min={2}
                      max={30}
                      autoComplete="none"
                      required
                      label="Nick Name"
                      validationRules={[
                        {
                          pattern: /^[a-zA-Z0-9]+$/,
                          message: "No Special Chars",
                        },
                      ]}
                    />
                    {/* <label>Nick Name</label>
                    <Form.Item
                      name="nickName"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Nick Name.",
                        },
                        {
                          min: 2,
                          message: "Nick Name should be between 2 and 30 characters",
                        },
                        {
                          max: 30,
                          message: "Nick Name should be between 2 and 30 characters",
                        },
                        {
                          pattern: /^[a-zA-Z0-9]+$/,
                          message: "No Special Chars",
                        },
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput
                      name="relationship"
                      placeholder="Select Relationship"
                      showSearch
                      label="Relationship"
                      required
                      type="select"
                      onChange={(v) => {
                        let value = JSON.parse(v);
                        setState({
                          relationshipValue: value.relationshipValue,
                          relationshipDesc: value.relationshipDesc,
                        });
                      }}
                    >
                      {state.relationshipLists.map((list, i) => {
                        return (
                          <Option key={i} value={JSON.stringify(list)}>
                            {list.relationshipDesc}
                          </Option>
                        );
                      })}
                    </CustomInput>
                    {/* <label>Relationship</label>
                    <Form.Item
                      name="relationship"
                      rules={[
                        {
                          required: true,
                          message: "Please select Relationship.",
                        },
                      ]}
                    >
                      <Select
                        placeholder="Select Relationship"
                        showSearch
                        onChange={(v) => {
                          let value = JSON.parse(v);
                          setState({
                            relationshipValue: value.relationshipValue,
                            relationshipDesc: value.relationshipDesc,
                          });
                        }}
                      >
                        {state.relationshipLists.map((list, i) => {
                          return (
                            <Option key={i} value={JSON.stringify(list)}>
                              {list.relationshipDesc}
                            </Option>
                          );
                        })}
                      </Select>
                    </Form.Item> */}
                  </div>
                </Row>
              </Col>
              <Col sm={12} md={4}>
                <Row>
                  <div className="Container">
                    <CustomInput name="address1" label="Address" required min={10} max={300}>
                      <TextArea autoComplete="none" />
                    </CustomInput>
                    {/* <label>Address</label>
                    <Form.Item
                      name="address1"
                      rules={[
                        {
                          required: true,
                          message: "Please Enter your Address",
                        },
                        {
                          min: 10,
                          message: "Address should be between 10 and 300 characters",
                        },
                        {
                          max: 300,
                          message: "Address should be between 10 and 300 characters",
                        },
                      ]}
                    >
                      <TextArea autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item" name="state" label="State" required>
                      <AutoComplete className="w-100" placeholder="Select State" onSelect={onSelectState} filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1} autoComplete="none">
                        {state.stateLists.map((state, i) => {
                          return (
                            <Option key={i} value={state.stateCode}>
                              {state.state}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </CustomInput>
                    {/* <label>State</label>
                    <Form.Item
                      className="form-item"
                      name="state"
                      rules={[
                        {
                          required: true,
                          message: "Please select your State.",
                        },
                      ]}
                    >
                      <AutoComplete className="w-100" placeholder="Select State" onSelect={onSelectState} filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1} autoComplete="none">
                        {state.stateLists.map((state, i) => {
                          return (
                            <Option key={i} value={state.stateCode}>
                              {state.state}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item" name="city" label="City" required>
                      <AutoComplete autoComplete="none" className="w-100" placeholder="Select City" filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}>
                        {state.stateCities.map((city, i) => {
                          return (
                            <Option key={i} value={city.city}>
                              {city.city}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </CustomInput>
                    {/* <label>City</label>
                    <Form.Item
                      className="form-item"
                      name="city"
                      rules={[
                        {
                          required: true,
                          message: "Please select your City.",
                        },
                      ]}
                    >
                      <AutoComplete autoComplete="none" className="w-100" placeholder="Select City" filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}>
                        {state.stateCities.map((city, i) => {
                          return (
                            <Option key={i} value={city.city}>
                              {city.city}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </Form.Item> */}
                  </div>
                </Row>
              </Col>
              <Col>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item w-100" name="country" type="select" label="Country" placeholder="Select Country" onChange={handleReceivingCountry} required>
                      {state.receiverCountryLists.map((clist, i) => {
                        return <Option key={i} value={clist.countryName}>{`${clist.countryName}`}</Option>;
                      })}
                    </CustomInput>
                    {/* <label>Country</label>
                    <Form.Item
                      className="form-item"
                      name="country"
                      rules={[
                        {
                          required: true,
                          message: "Please select Country.",
                        },
                      ]}
                    >
                      <Select className="w-100" placeholder="Select Country" onChange={handleReceivingCountry}>
                        {state.receiverCountryLists.map((clist, i) => {
                          return <Option key={i} value={clist.countryName}>{`${clist.countryName}`}</Option>;
                        })}
                      </Select>
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput name="zipCode" label="Pincode" required autoComplete="none" validationRules={[...inputValidations.zipCode(AuthReducer.recvCountryCode)]} />
                    {/* <label>Pincode</label> */}
                    {/* <Form.Item
                      name="zipCode"
                      rules={[
                        {
                          required: true,
                          message: "Please input your Pincode.",
                        },
                        ...inputValidations.zipCode(AuthReducer.recvCountryCode),
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item" name="emailId" type="email" required label="Email ID" autoComplete="none" />
                    {/* <label>Email ID</label>
                    <Form.Item
                      className="form-item"
                      name="emailId"
                      rules={[
                        {
                          type: "email",
                          message: "Please input valid Email ID.",
                        },
                      ]}
                    >
                      <Input autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    {/* <label>Mobile Number</label> */}
                    <div className="row g-2">
                      <div className="col-md-4">
                        <CustomInput name="mobileCountryCode" autoComplete="none" label="Mobile Number" showSearch placeholder="Select Phone Code" type="select" required>
                          {state.phoneCodes.map((phoneCode, i) => {
                            return <Option key={i} value={phoneCode.countryPhoneCode}>{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>;
                          })}
                        </CustomInput>
                        {/* <Form.Item
                          name="mobileCountryCode"
                          rules={[
                            {
                              required: true,
                              message: "Please select your Country Code.",
                            },
                          ]}
                        >
                          <Select autoComplete="none" showSearch placeholder="Select Phone Code">
                            {state.phoneCodes.map((phoneCode, i) => {
                              return <Option key={i} value={phoneCode.countryPhoneCode}>{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>;
                            })}
                          </Select>
                        </Form.Item> */}
                      </div>
                      <div className="col-md-8">
                        <CustomInput
                          name="mobileNo"
                          label="Mobile Number"
                          showLabel={false}
                          min={10}
                          max={10}
                          maxLength={10}
                          autoComplete="none"
                          required
                          validationRules={[
                            {
                              pattern: /^[0-9\b]+$/,
                              message: "Only Numbers allowed",
                            },
                          ]}
                        />
                        {/* <Form.Item
                          name="mobileNo"
                          rules={[
                            {
                              required: true,
                              message: "Please input your Mobile Number.",
                            },
                            {
                              min: 10,
                              max: 10,
                              message: "Mobile number must be 10 digit.",
                            },
                            {
                              pattern: /^[0-9\b]+$/,
                              message: "Only Numbers allowed",
                            },
                            // { pattern: new RegExp("^[6]{1}[0-9]*$"), message: "Mobile number must start with 6" }
                          ]}
                        >
                          <Input maxLength={10} autoComplete="none" />
                        </Form.Item> */}
                      </div>
                    </div>

                    <div className="d-flex justify-content-between"></div>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput
                      name="phoneNo"
                      min={1}
                      max={14}
                      maxLength={10}
                      label="Phone Number"
                      autoComplete="none"
                      validationRules={[
                        {
                          pattern: /^[0-9\b]+$/,
                          message: "Only Numbers allowed",
                        },
                      ]}
                    />
                    {/* <label>Phone Number</label>
                    <Form.Item
                      name="phoneNo"
                      rules={[
                        {
                          min: 1,
                          max: 14,
                          message: "Phone number must be between 1 to 14 digits.",
                        },
                        {
                          pattern: /^[0-9\b]+$/,
                          message: "Only Numbers allowed",
                        },
                      ]}
                    >
                      <Input maxLength={10} autoComplete="none" />
                    </Form.Item> */}
                  </div>
                </Row>
              </Col>
            </Row>
          </div>
          <div className="d-flex justify-content-between">
            <button
              className="Back-Button"
              onClick={() => {
                props.setAddRecipentModalSetp2(true);
              }}
            >
              Back
            </button>
            <button className="btn btn-light text-primary" type="submit">
              Submit
            </button>
          </div>
        </div>
      </Form>
    </div>
  );
}
