import { Stepper, Step, StepLabel } from "@mui/material";
import React, { useEffect, useReducer, useState } from "react";
import { useLocation } from "react-router-dom";
import { useSelector } from "react-redux";
import { TransactionAPI } from "../../../../apis/TransactionAPI";
import useHttp from "../../../../hooks/useHttp";
import SubHeader from "../../layout/SubHeader";
import Spinner from "../../../../reusable/Spinner";

const steps = [
  "Transaction Booked",
  "Payment Done",
  "Payment Processed",
  "Transfer Made",
  "Payment Recieved",
];

function TrackMoneyTransfer(props) {
  const location = useLocation();
  const AuthReducer = useSelector((state) => state.user);
  const [loader, setLoader] = useState(false);
  //   const { pathData } = props.location;
  //   console.log(location.rgtn);
  //   console.log(props);

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      trackingDetails: [],
      clientId: AuthReducer.clientId,
      groupId: AuthReducer.groupId,
      sessionId: AuthReducer.sessionId,
      userID: AuthReducer.userID,
      rgtn: location.state.rgtn,
    }
  );

  const hookTrackTranscation = useHttp(TransactionAPI.trackTranscation);

  useEffect(() => {
    trackTranscation();
  }, []);

  const trackTranscation = () => {
    let transactiondata = {
      requestType: "TRACKMYTRANSFER",
      rgtn: state.rgtn,
      userId: state.userID,
    };
    setLoader(true);
    hookTrackTranscation.sendRequest(transactiondata, function (data) {
      setLoader(false);
      setState({ trackingDetails: data });
    });
  };

  return (
    <>
      <SubHeader title="Track Money Transfer " />
      <div className="template2__main">
        <div className="container trackmytransfer_page py-5">
          <Spinner spinning={loader}>
            <section className="my-5 text-center ">
              <h5 className="text-light">
                Tracking ID - {state.trackingDetails.txnRefNo}{" "}
              </h5>
            </section>

            <section>
              <Stepper
                activeStep={state.trackingDetails.pictograph}
                alternativeLabel
              >
                {steps.map((label) => (
                  <Step key={label}>
                    <StepLabel>{label}</StepLabel>
                  </Step>
                ))}
              </Stepper>
            </section>
          </Spinner>
          <ht />

          <section>
            <div className="row text-center  text-light my-5">
              <div className="col-md-4">
                <strong>Current Status</strong>
                <br />
                {state.trackingDetails.statusDescription}
              </div>
              <div className="col-md-4">
                <strong>Estimate Date of Delivery</strong>
                <br />
                {state.trackingDetails.expectedDeliveryDate}
              </div>
              <div className="col-md-4">
                <strong>Call us for Assistance</strong>
                <br />
              </div>
            </div>
          </section>
        </div>
      </div>
    </>
  );
}

export default TrackMoneyTransfer;
