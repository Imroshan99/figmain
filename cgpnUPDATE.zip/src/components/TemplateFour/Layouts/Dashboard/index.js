import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import DashboardBody from "./Dashboard";
import Header from "./Header";
import { Outlet, useLocation } from "react-router-dom";
import Footer from "./Footer";

const Dashboard = (props) => {
  // const { pageTitle } = props;
  const [title, setTitle] = useState("");
  const groupConfig = useSelector((state) => state.user);
  // const location = useLocation();
  // const temp = AuthReducer.groupIdSettings?.theme?.Header;

  // const [dt, setDt] = useState(new Date());
  // useEffect(() => {
  //   // setDt(new Date());
  //   setTitle(location.pathname);
  // }, [location.pathname]);
  // useEffect(() => {
  //   setDt(new Date());
  // }, []);
  return (
    <div className={`__dashboard1 __groupId_${groupConfig.groupId}`}>
      {/* {dt.toUTCString()} */}
      <Header />

      <DashboardBody pageTitle={title}>
        <Outlet context={{ title, setTitle }} />
      </DashboardBody>
      <Footer />
    </div>
  );
};

export default Dashboard;
