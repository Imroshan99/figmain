import React from "react";
import { Link } from "react-router-dom";
import { useSelector } from "react-redux";
// import mobileImage from "../../../../assets/images/banners/mobileImage-signIn.svg";
import mobileImage from "../../../../assets/images/banners/money-transfer2.svg";

const AuthTemplateOne = (props) => {
  const AuthReducer = useSelector((state) => state.user);

  return (
    <div className="container-fluid h-100 p-0 m-0 auth_temp1">
      {/* {state._isShowOTPBOX && <OTPBox state={state} setState={setState} storeLoginData={storeLoginData} otpType={state.otpType} useFor="login" appState={props.appState} />} */}

      <div className="row w-100 h-100 m-0">
        <div className="col-md-6 h-100 col-sm-24 order-sm-2 order-sm-2 order-md-1">
          {/* bg-light text-dark shadow-md rounded   */}
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-8 col-xxl-6 ">
              <div className="my-5">
                <div className="text-center mb-3">
                  <Link className="logo" to="/">
                    <img
                      src={`images/${AuthReducer.groupId}/logo.png`}
                      height="48px"
                      alt="Logo"
                    />
                  </Link>
                </div>
                {props.children}
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-sm-24 h-100 bg-gradient-blue-violet order-xs-2 order-sm-1 order-md-2 auth-right-box">
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-8 col-lg-8 col-xl-6">
              <div className="w-100 h-100 text-center">
                <img src={mobileImage} className="w-100" alt="Mobile Banner" />
              </div>
              <div className="mt-5">
                <h2 className="w-100 mx-auto text-center text-white">
                  Experience Super Fast Money Transfer
                </h2>
                <div className="w-100 text-center text-white">
                  We provide fast and simple steps to send money to your loved
                  one. With just a few steps, and you are done!
                </div>
              </div>
            </div>
          </div>

          {/* <ExchangeRate /> */}
        </div>
      </div>
    </div>
  );
};

export default AuthTemplateOne;
