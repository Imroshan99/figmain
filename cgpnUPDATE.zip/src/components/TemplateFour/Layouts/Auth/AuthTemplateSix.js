import React from "react";
import { useSelector } from "react-redux";
import { Link } from "react-router-dom";
import mobileImage from "../../../../assets/images/banners/money-transfer2.svg";
const AuthTemplateSix = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  return (
    <div className="auth_temp6">
      <header className="navbar navbar-expand-md navbar-dark bd-navbar">
        <nav
          className="container-xxl flex-wrap flex-md-nowrap"
          aria-label="Main navigation"
        >
          <Link className="logo" to="/">
            <img
              src={`images/${AuthReducer.groupId}/logo.png`}
              height="48px"
              alt="Logo"
            />
          </Link>

          <button
            className="navbar-toggler"
            type="button"
            data-bs-toggle="collapse"
            data-bs-target="#bdNavbar"
            aria-controls="bdNavbar"
            aria-expanded="false"
            aria-label="Toggle navigation"
          >
            <svg
              xmlns="http://www.w3.org/2000/svg"
              width="32"
              height="32"
              className="bi"
              fill="currentColor"
              viewBox="0 0 16 16"
            >
              <path
                fill-rule="evenodd"
                d="M2.5 11.5A.5.5 0 0 1 3 11h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 7h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5zm0-4A.5.5 0 0 1 3 3h10a.5.5 0 0 1 0 1H3a.5.5 0 0 1-.5-.5z"
              />
            </svg>
          </button>
        </nav>
      </header>
      <div className="container-fluid p-0 m-0  d-flex bg-signIn-image-1 main_wrapper">
        <div className="row m-auto h-100  d-sm-flex">
          <div className="col-md-5 col-sm-24 h-100 ">
            <div className="row h-100 justify-content-center align-items-center">
              <div className="col-12 col-md-8 col-lg-8 col-xl-8 py-5">
                <div className="w-100 h-100 text-center">
                  <img
                    src={mobileImage}
                    className="w-100"
                    alt="Mobile Banner"
                  />
                </div>
                <div className="mt-5">
                  <h2 className="w-100 mx-auto text-center">
                    Experience Super Fast Money Transfer
                  </h2>
                  <div className="w-100 text-center">
                    We provide fast and simple steps to send money to your loved
                    one. With just a few steps, and you are done!
                  </div>
                </div>
              </div>
            </div>
          </div>
          <div className=" col-md-7 h-100 col-xs-24 ">
            <div className="row h-100 justify-content-center align-items-center">
              <div className="col-12 col-md-10 col-xxl-8 py-5">
                <div className="card">
                  <div className="card-body">{props.children}</div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default AuthTemplateSix;
