import React, { useState, useEffect, useReducer } from "react";
import { Form, Input, Modal, notification, Spin } from "antd";
import moment from "moment";
import { GuestAPI } from "../apis/GuestAPI";
import { useSelector } from "react-redux";
import useHttp from "../hooks/useHttp";

export default function OTPBox(props) {
  var x;
  const ConfigReducer = useSelector((state) => state.user);
  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [intervalID, setInterID] = useState(); // created a useState for intervalID

  const [reverseTimer, setReverseTimer] = useState("4m 00s");
  const [otpVerificationToken, setVerificationToken] = useState("");

  const hookVerifyOTP = useHttp(GuestAPI.verifyOTP);
  const hookReSendOTP = useHttp(GuestAPI.reSendOTP);

  useEffect(() => {
    //      console.log("OTP payload Token : ", props.state.verificationToken)
    // console.log("OTP payload Token 2 : ", otpVerificationToken)

    reverseTimerOnLoad();
  }, []);

  useEffect(() => {
    setVerificationToken(props.state.verificationToken);
  }, [props.state.verificationToken]);

  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(4, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID); // took letintervalID and stored it in useState intervalID
  };

  const onFinish = (value) => {
    form.setFields([{ name: "otp", errors: [] }]);

    const optPayloadData = {
      requestType: "VERIFYOTP",
      otpType: props.otpType,
      verificationToken: otpVerificationToken,
      otp: value.otp,
    };

    if (props.useFor === "addRecipient") {
      optPayloadData.accountNo = props.state.formData.accountNo;
    }

    setLoader(true);

    hookVerifyOTP
      .sendRequest(optPayloadData, function (res) {
        clearInterval(intervalID);
        setLoader(false);

        if (res.status === "S") {
          props.setState({ isModalVisible: false });

          if (props.useFor === "signup") {
            props.setState({
              verifiedToken: res.verifiedToken,
            });
            props.checkDedupe(res.verifiedToken);
          } else if (props.useFor === "login") {
            props.setState({ verifiedToken: res.verifiedToken });
            props.storeLoginData(props.state.loginData);
          } else if (props.useFor === "addRecipient") {
            props.saveReceiver(res.verifiedToken);
          } else if (props.useFor === "Edit_Address") {
            props.editProfile(res.verifiedToken);
          } else if (props.useFor === "Edit_Contact") {
            setTimeout(() => {
              props.editSenderContactdtls(res.verifiedToken);
            }, 1000);
          } else if (props.useFor === "Edit_Marketing") {
            props.editProfile(res.verifiedToken);
          } else if (props.useFor === "forgot_password") {
            props.setState({
              verifiedToken: res.verifiedToken,
              _isShowSuccessMessage: true,
            });
          } else if (props.useFor === "unlock_account") {
            props.onUnlockAccountHandler();
          }
        } else {
          notification.error({ message: res.errorMessage });

          let errors = [];
          res.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {
        setLoader(false);
      });
  };

  const onClickResedOTP = async () => {
    const resendOtpPayload = {
      requestType: "RESENDOTP",
      verificationToken: otpVerificationToken,
      otpOption: "SM",
    };

    if (props.useFor === "addRecipient") {
      resendOtpPayload.accountNo = props.state.formData.accountNo;
    }

    hookReSendOTP
      .sendRequest(resendOtpPayload, function (res) {
        setLoader(false);
        if (res.status === "S") {
          notification.success({ message: res.message });
          props.setState({ verificationToken: res.verificationToken });
          setVerificationToken(res.verificationToken);
          clearInterval(intervalID);
          setTimeout(() => {
            reverseTimerOnLoad();
          }, 200);
        } else {
          notification.error({ message: res.errorMessage });

          let errors = [];
          res.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {
        setLoader(false);
      });
  };

  return (
    <div>
      <Modal
        centered
        title="Verify With OTP"
        visible={props.state.isModalVisible}
        onCancel={() => props.setState({ isModalVisible: false })}
        footer={null}
      >
        <Form form={form} onFinish={onFinish}>
          <div className="d-flex justify-content-center align-items-center">
            <div className="position-relative">
              <div className="verify-otp-box border-0 p-2 text-center">
                <h6>
                  Please enter the 6-digit OTP sent to your registered email id
                </h6>
                {/* <h6>A 6 digit OTP is sent to <br /> your registered mobile number and email id</h6>
                                <div>
                                    <span>A code has been sent to</span>
                                    <small>*******{props.state.formData.mobileNo.slice(props.state.formData.mobileNo.length - 4)}</small>
                                </div> */}

                <div className="my-3">
                  <Form.Item
                    className="form-item text-start"
                    name="otp"
                    rules={[
                      { required: true, message: "Please input your otp." },
                      {
                        pattern: /^[0-9\b]+$/,
                        message: "Only Numbers allowed",
                      },
                    ]}
                  >
                    <Input
                      size="large"
                      placeholder="OTP Number Ex. 784546"
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCut={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item>
                </div>

                <div className="my-3 text-start">
                  <p className="small">OTP will expire in {reverseTimer}</p>
                </div>
                <Spin spinning={loading} delay={500}>
                  <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                    <button
                      className="btn btn-danger btn-sm px-4"
                      onClick={onClickResedOTP}
                      type="button"
                    >
                      Resend OTP
                    </button>
                    <button className="btn btn-primary btn-sm text-white px-4 btn-sm">
                      Submit
                    </button>
                  </div>
                </Spin>
              </div>
            </div>
          </div>
        </Form>
      </Modal>
    </div>
  );
}
