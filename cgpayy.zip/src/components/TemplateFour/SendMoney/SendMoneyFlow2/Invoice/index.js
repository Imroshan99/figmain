import React, { forwardRef } from "react";
import { useSelector } from "react-redux";
import XRInvoice from "./XR";
// import HomeKcb from "./KCB"

const Invoice = (props, ref) => {
  const AuthReducer = useSelector((state) => state.user);
  switch (AuthReducer.groupId) {
    case "MF":
      return <XRInvoice ref={ref} _invoiceTxnRefNumber={props._invoiceTxnRefNumber} />;
      break;
      
    case "KCB":
      return <XRInvoice ref={ref} _invoiceTxnRefNumber={props._invoiceTxnRefNumber} />;
      break;

    case "XR":
      return <XRInvoice ref={ref} _invoiceTxnRefNumber={props._invoiceTxnRefNumber} />;
      break;

    default:
      break;
  }
};

export default forwardRef(Invoice);
