import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import LoginForm from "../Login/LoginForm";
import AuthTemplateOne from "../Layouts/Auth/AuthTemplateOne";
import AuthTemplateTwo from "../Layouts/Auth/AuthTemplateTwo";
import TransactionAction1 from "./SendMoneyFlow1/TranctionAction";
import TransactionAction2 from "./SendMoneyFlow2/TranctionAction";
import TransactionAction3 from "./SendMoneyFlow3/TranctionAction";
import Dashboard from "../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const SendMoney = (props) => {
  const { setTitle } = useOutletContext();
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.sendMoneyModule?.flow;

  useEffect(() => {
    setTitle("Send Money");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <TransactionAction1
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
      {templateFlow === "FLOW2" && (
        <TransactionAction2
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}

      {templateFlow === "FLOW3" && (
        <TransactionAction3
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default SendMoney;
