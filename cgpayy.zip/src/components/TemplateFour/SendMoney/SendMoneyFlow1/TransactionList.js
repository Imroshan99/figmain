import React, {
  useState,
  useEffect,
  useReducer,
  Fragment,
  useRef,
} from "react";
import {
  Form,
  Table,
  Spin,
  Select,
  DatePicker,
  Input,
  Button,
  notification,
  Tabs,
} from "antd";
import DefaultLayout from "../../layout/DefaultLayout";
import TransactionTable from "./TransactionTable";
import ScheduleReminder from "./ScheduleReminder";
import ExchangeRate from "./ExchangeRate";
import SubHeader from "../../layout/SubHeader";

const { TabPane } = Tabs;

export default function TransactionList(props) {
  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      isTransactionBook: false,
    }
  );

  const callback = (key) => {
    console.log(key);
  };

  return (
    <React.Fragment>
      <SubHeader title="Transactions List" />
      <div className="template2__main">
        <div className="container my_transcations_page py-5">
          <Tabs defaultActiveKey="1" onChange={callback}>
            <TabPane tab="My Transactions" key="1">
              <TransactionTable />
            </TabPane>
            <TabPane tab="Schedule a Reminder" key="2">
              <ScheduleReminder />
            </TabPane>
            <TabPane tab="Exchange Rate" key="3">
              <ExchangeRate />
            </TabPane>
          </Tabs>
        </div>
      </div>
    </React.Fragment>
  );
}
