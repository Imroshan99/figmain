import UnlockAccountFlowOne from "./UnlockAccountFlowOne";

const UnlockAccount = (props) => {
  return <UnlockAccountFlowOne />;
};

export default UnlockAccount;
