import React, { useState } from 'react';
import { Form, Checkbox } from 'antd';
import { Row, Col } from 'react-bootstrap';
import moment from 'moment';
import Spinner from '../../../reusable/Spinner';
import CustomInput from '../../../reusable/CustomInput';

function ReviewProfile(props) {

    const [form] = Form.useForm();
    const [loading, setLoader] = useState(false);

    const onFinish = (value) => {
        console.log(value)
        props.editProfile();
    }

    return (
      <div className="mt-4">
        <div class="alert bg-primary text-white" role="alert">
          Review
        </div>
        <div className="bg-white shadow-sm rounded p-4 mb-4">
          <Form form={form} onFinish={onFinish}>
            <div className="d-flex justify-content-center align-items-center">
              <Row className="justify-content-center">
                <Col md={6}>
                  <h5>About Me</h5>
                  <Row>
                    <Col md={6}>
                      <p className="w-600">Age</p>
                      <p>{props.state.age}</p>
                    </Col>
                    <Col md={6}>
                      <p>Date Of Birth</p>
                      <p>{props.state.dob}</p>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <p>Gender</p>
                      <p>{props.state.gender}</p>
                    </Col>
                    <Col md={6}>
                      <p>Citizenship</p>
                      <p>{props.state.citizenshipDesc}</p>
                    </Col>
                  </Row>

                  <Row>
                    <Col md={6}>
                      <p>Name Of Profesion</p>
                      <p>{props.state.professionDesc}</p>
                    </Col>
                    <Col md={6}>
                      <p>Income</p>
                      <p>{props.state.incomeDesc}</p>
                    </Col>
                  </Row>
                  <Row>
                    <Col md={12}>
                      <p>Occupation</p>
                      <p>{props.state.occupationDesc}</p>
                    </Col>
                  </Row>
                </Col>

                <Col md={6}>
                  <h5>Current Address</h5>
                  {/* <p>Amethyst Lane, Tamar Court Reoding Berkshire, UK, RG30 2EZ</p> */}
                  <p>{props.state.mainAddress}</p>
                </Col>
                <Col md={12}>
                  <CustomInput
                    className="form-item"
                    name="readTermsConditions"
                    valuePropName="checked"
                    validationRules={[
                      {
                        validator: (_, value) => (value ? Promise.resolve() : Promise.reject(new Error("Please confirm terms and conditions."))),
                      },
                    ]}
                  >
                    <Checkbox>
                      I agree to the <b>Terms and Conditions</b> and authorized bank ICICI Bank Money2India to verify details provided by me.
                    </Checkbox>
                  </CustomInput>
                   
                </Col>

                <Spinner spinning={loading} delay={500}>
                  <div className="d-grid gap-2 d-flex mt-4">
                    <button className="btn btn-primary text-white px-4">Register</button>
                  </div>
                </Spinner>
              </Row>
            </div>
          </Form>
        </div>
      </div>
    );
}

export default ReviewProfile;
