import React, { useEffect } from "react";
import { Form, Select, Input, Radio, DatePicker, Spin } from "antd";
import { Row, Col } from "react-bootstrap";
import moment from "moment";
import CustomInput from "../../../reusable/CustomInput";

const { Option } = Select;

function AboutMe(props) {
  const [form] = Form.useForm();

  useEffect(() => {
    form.setFieldsValue({
      age: props.state.age,
      // dob: props.state.dob,
      gender: props.state.gender,
      citizenship: props.state.citizenshipDesc,
      annualIncome: props.state.incomeDesc,
      employmentStatus: props.state.professionDesc,
      occupation: props.state.occupationDesc,
    });
  }, []);

  const onFinish = (value) => {
    console.log(value);
    props.setState({
      gender: value.gender,
      // citizenship: value.citizenship,
      // income_id: value.annualIncome,
      // profession_id: value.employmentStatus,
      // occupation_id: value.occupation,
      isStep: 2,
    });
  };

  const onChangeDOB = (value, dateString) => {
    value !== null
      ? props.setState({
          dob: dateString,
          age: moment().diff(dateString, "years", false),
        })
      : props.setState({ dob: "" });

    form.setFieldsValue({
      age: moment().diff(dateString, "years", false),
    });
  };

  return (
    <div className="mt-4">
      <div class="alert bg-primary text-white" role="alert">
        About Me
      </div>
      <div className="bg-white shadow-sm rounded p-4 mb-4">
        <Form form={form} onFinish={onFinish}>
          <div className="d-flex justify-content-center align-items-center">
            <Row className="justify-content-center">
              <Col md={6}>
                <p>Age</p>
                <CustomInput className="form-item" name="age" readOnly placeholder="age" />
                
              </Col>

              <Col md={6}>
                <div className="">
                  <p>Date Of Birth</p>
                  <CustomInput className="form-item" name="dob" label="Date of Birth" showLabel={false}>
                    <DatePicker size="large" className="w-100" defaultValue={moment(props.state.dob, "YYYY-MM-DD")} defaultPickerValue={moment().subtract(18, "years")} disabledDate={(d) => !d || d.isAfter(moment().subtract(18, "years")) || d.isSameOrBefore("1900-01-01")} onChange={(value, dateString) => onChangeDOB(value, dateString)} />
                  </CustomInput>
                   
                </div>
              </Col>

              <Col md={12}>
                <div className="">
                  <p>Gender</p>
                  <CustomInput className="form-item" name="gender" label="Gender" showLabel={false} required onChange={(e) => props.setState({ gender: e.target.value })}>
                    <Radio.Group>
                      <Radio value={"M"}>Male</Radio>
                      <Radio value={"F"}>Female</Radio>
                      <Radio value={"P"}>Prefer not to tell</Radio>
                    </Radio.Group>
                  </CustomInput>
                  
                </div>
              </Col>

              <Col md={12}>
                <label className="form-label">Citizenship</label>
                <CustomInput
                  className="form-item w-100"
                  size="large"
                  name="citizenship"
                  type="select"
                  label="Citizenship"
                  showLabel={false}
                  placeholder="Select citizenship"
                  showSearch
                  onChange={(v) => {
                    let value = JSON.parse(v);
                    props.setState({
                      citizenship: value.countryCode,
                      citizenshipDesc: value.citizenship,
                    });
                  }}
                  required
                >
                  {props.state.citizenshipLists.map((list, i) => {
                    return (
                      <Option
                        key={i}
                        value={JSON.stringify(list)}
                        // value={list.countryCode}
                      >
                        {list.citizenship}
                      </Option>
                    );
                  })}
                </CustomInput>
                 
              </Col>

              <Col md={12}>
                <label className="form-label">Annual Income</label>
                <CustomInput
                  className="form-item w-100"
                  size="large"
                  name="annualIncome"
                  type="select"
                  label="Annual Income"
                  showLabel={false}
                  placeholder="Select Annual Income"
                  showSearch
                  required
                  onChange={(v) => {
                    let value = JSON.parse(v);
                    console.log(value);
                    props.setState({
                      income_id: value.incmId,
                      incomeDesc: value.incomeDesc,
                    });
                  }}
                >
                  {props.state.incomeLists.map((list, i) => {
                    return (
                      <Option key={i} value={JSON.stringify(list)}>
                        {list.incomeDesc}
                      </Option>
                    );
                  })}
                </CustomInput>
                 
              </Col>

              <Col md={12}>
                <label className="form-label">Employment Status</label>
                <CustomInput
                  className="form-item w-100"
                  size="large"
                  type="select"
                  name="employmentStatus"
                  label="Employment Status"
                  showLabel={false}
                  required
                  placeholder="Select Employment Status"
                  showSearch
                  onChange={(v) => {
                    let value = JSON.parse(v);
                    props.setState({
                      profession_id: value.professionId,
                      professionDesc: value.professionDesc,
                    });
                  }}
                >
                  {props.state.professionLists.map((list, i) => {
                    return (
                      <Option key={i} value={JSON.stringify(list)}>
                        {list.professionDesc}
                      </Option>
                    );
                  })}
                </CustomInput>
                 
              </Col>

              <Col md={12}>
                <label className="form-label">Occupation</label>
                <CustomInput
                  className="form-item w-100"
                  size="large"
                  name="occupation"
                  type="select"
                  label="Occupation"
                  showLabel={false}
                  placeholder="Select Occupation"
                  showSearch
                  onChange={(v) => {
                    let value = JSON.parse(v);
                    props.setState({
                      occupation_id: value.occupationId,
                      occupationDesc: value.occupationDesc,
                    });
                  }}
                >
                  {props.state.occupationLists.map((list, i) => {
                    return (
                      <Option key={i} value={JSON.stringify(list)}>
                        {list.occupationDesc}
                      </Option>
                    );
                  })}
                </CustomInput>
                 
              </Col>

              <div className="d-grid gap-2 d-flex mt-4">
                <button className="btn px-4" type="button" onClick={() => props.setState({ isStep: 2 })}>
                  Save For Later
                </button>
                <button className="btn btn-primary text-white px-4">Procced</button>
              </div>
            </Row>
          </div>
        </Form>
      </div>
    </div>
  );
}

export default AboutMe;
