import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Tabs, Select, notification, Spin } from "antd";
import { Link, useNavigate } from "react-router-dom";
import Swal from "sweetalert2";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { ProfileAPI } from "../../../../apis/ProfileAPI";
import CustomInput from "../../../../reusable/CustomInput";

const { TabPane } = Tabs;
const { Option } = Select;

export default function ChangePasswordFlowTwo(props) {
  const [form] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  // console.log(AuthReducer);
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState("STEP1");
  const [isICICI, setIsICICI] = useState(true);
  let navigate = useNavigate();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    twofa: AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    userFullName: AuthReducer.userFullName,
  });

  const hookChangePassword = useHttp(ProfileAPI.changePassword);

  useEffect(async () => {
    window.scrollTo({ top: 0, behavior: "smooth" });
  }, []);

  const onFinish = (value) => {
    let changePasswordPayload = {
      requestType: "CHANGEPASSWORD",
      userId: AuthReducer.userID,
      oldPassword: value.oldPassword,
      newPassword: value.newPassword,
      twofa: "N",
    };

    hookChangePassword.sendRequest(changePasswordPayload, function (data) {
      if (data.status == "S") {
        console.log(data.responseData);
        Swal.fire({
          title: "Success",
          text: data.message,
          icon: "success",
          confirmButtonColor: "#2dbe60",
        }).then((result) => {
          if (result.isConfirmed) {
            // navigate('/signin');
            window.location.href = "/signin";
          }
        });
        // setBankListData(decodeData.responseData);
        // setState({ transactionLists: decodeData.responseData });
      } else {
        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        } else {
          notification.error({ message: data.errorMessage });
        }
      }
    });
  };

  return (
    <div>
      {/* <div className="p-2 inner_title_wrapper">
        <div className="container">
          <h2 className="mb-0 inner_title">Change Password</h2>
        </div>
      </div> */}

      <Spin spinning={loading} delay={500}>
        {!state.showConfirmBankAccountDetails && (
          <Row className="justify-content-center ">
            <Col lg={8} md={10}>
              <div className="card p-3 mb-4">
                <Form form={form} onFinish={onFinish}>
                  <Row className="justify-content-center">
                    <Col md={12}>
                      <div className="">
                        <CustomInput className="form-item" name="oldPassword" label="Current Password" required>
                          <Input.Password placeholder="Current Password" />{" "}
                        </CustomInput>
                      </div>
                    </Col>

                    <Col md={12}>
                      <div className="">
                        <CustomInput className="form-item" name="newPassword" label="New Password" min={10} required>
                          <Input.Password placeholder="Enter your New Password" maxLength={12} />
                        </CustomInput>
                      </div>
                    </Col>
                    <Col md={12}>
                      <div className="">
                        <CustomInput
                          className="form-item"
                          name="ConfirmNewPassword"
                          label="Confirm New Password"
                          validationRules={[
                            ({ getFieldValue }) => ({
                              validator(rule, value) {
                                if (!value || getFieldValue("newPassword") === value) {
                                  return Promise.resolve();
                                }
                                return Promise.reject("Confirm password does not match with set password. Please enter correct values in the fields.");
                              },
                            }),
                          ]}
                          required
                        >
                          <Input.Password placeholder="Confirm New Password" maxLength={12} />
                        </CustomInput>
                      </div>
                    </Col>

                    <Col md={12}>
                      <div className="d-flex justify-content-end">
                        <Link to={"/"} className="btn btn-primary-light me-3 my-3">
                          Back
                        </Link>
                        <button
                          className="btn btn-primary my-3"
                          type="submit"
                          // onClick={() => setIsICICI(true)}
                        >
                          Submit
                        </button>
                      </div>
                    </Col>
                  </Row>
                </Form>
              </div>
            </Col>
          </Row>
        )}
      </Spin>
    </div>
  );
}
