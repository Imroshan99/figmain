import React, { useState, useEffect, useReducer } from "react";
import { Row, Col } from "react-bootstrap";
import { Form, Input, Radio, Select, notification, AutoComplete, Tabs } from "antd";
import { useLocation } from "react-router-dom";
import { ReceiverAPI } from "../../../../apis/ReceiverAPI";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { inputValidations } from "../../../../services/validations/validations";
import Spinner from "../../../../reusable/Spinner";
import CustomInput from "../../../../reusable/CustomInput";
import { getProcessingPartner } from "../../../../services/utility/group";
import { LuluGuestAPI } from "../../../../apis/LuluApi/GuestApi";

const { Option } = Select;
const { TabPane } = Tabs;
const { TextArea } = Input;

export default function EditRecipient(props) {
  const [form] = Form.useForm();
  const [form1] = Form.useForm();
  const AuthReducer = useSelector((state) => state.user);
  const ConfigReducer = useSelector((state) => state.user);
  const AddRecipientFormConfig = ConfigReducer.groupIdSettings.recipientModule.AddRecipientForm;
  const [loading, setLoader] = useState(false);
  const [activeStep, setActiveStep] = useState(true);
  const [currentTab, setCurrentTab] = useState(1);
  const [form1Data, setForm1Data] = useState({});

  const location = useLocation();

  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    clientId: AuthReducer.clientId,
    groupId: AuthReducer.groupId,
    twofa: AddRecipientFormConfig?.twoFA ? AddRecipientFormConfig.twoFA : AuthReducer.twofa,
    // twofa:   AuthReducer.twofa,
    sessionId: AuthReducer.sessionId,
    userID: AuthReducer.userID,
    nationalities: [],
    stateCities: [],
    _showOTPBOX: false,
    showConfirmAddRecipient: false,
    isConfirmAddRecipient: false,
    formData: {},
    editData: {},
    verificationToken: "",
    isOTPVerfied: false,
    isModalVisible: false,
    otpType: "RA",
    branchCode: "",
    bankBranch: "",
    bankAddress: "",
    bankState: "",
    bankCity: "",
    bankName: "",
    isSameBank: "N",
    bankCode: "",
    bankId: "",
    bankCountry: "",
    bankLists: [],
    cityLists: [],
    branchLists: [],
    phoneCodes: [],
    occupationLists: [],
    relationshipLists: [],
    deliveryOptionsList: [],
    deliveryOption: "",
    stateLists: [],
    dob: "",
    redirectPage: "",
    redirectPageState: [],
    receiverCountryLists: [],
  });

  const hookGetNationality = useHttp(GuestAPI.getNationality);
  const hookGetCountryPhoneCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetRelationshipLists = useHttp(GuestAPI.relationshipLists);
  const hookGetDeliveryOptions = useHttp(GuestAPI.deliveryOptions);
  const hookGetCountryStates = useHttp(GuestAPI.countryStates);
  const hookGetBankBranchData = useHttp(GuestAPI.bankBranchData);
  const hookGetStateCities = useHttp(GuestAPI.stateCities);
  const hookGetReceiverCountryLists = useHttp(GuestAPI.receiverCountryList);
  const hookGetBankLists = useHttp(ReceiverAPI.bankLists);
  const hookGetBankStateCities = useHttp(ReceiverAPI.bankStateCities);
  const hookGebankBranches = useHttp(ReceiverAPI.bankBranches);
  const hookCheckDuplicateReceiver = useHttp(ReceiverAPI.checkDuplicateReceiver);
  const hookEditReceiver = useHttp(ReceiverAPI.editReceiver);
  const hookEditReceiver2 = useHttp(ReceiverAPI.editReceiver2);
  const hookGetCodes = useHttp(LuluGuestAPI.codesLists);
  const editRecipientData = props.editRecipientData;

  useEffect(() => {
    if (editRecipientData) {
      setActiveStep(true);
      setState({
        deliveryOption: editRecipientData.recvMode,
      });
      setState({
        bankName: editRecipientData.bankName,
        bankBranch: editRecipientData.bankBranch,
        bankState: editRecipientData.bankState,
        bankCity: editRecipientData.bankCity,
        branchCode: editRecipientData.branchCode,
        bankAddress: editRecipientData.bankAddress,
        relationshipValue: editRecipientData.recvRefNo,
        relationshipDesc: editRecipientData.relationshipValue,
      });
      form.setFieldsValue({
        mobileCountryCode: editRecipientData.mobileCountryCode,
        firstName: editRecipientData.firstName,
        middleName: editRecipientData.middleName,
        lastName: editRecipientData.lastName,
        nickName: editRecipientData.nickName,
        mobileNo: editRecipientData.mobileNo,
        phoneNo: editRecipientData.offPhone,
        relationship: getProcessingPartner(AuthReducer.sendCountryCode) === "LULU" ? editRecipientData.recvRefNo : editRecipientData.relationship,
        address1: editRecipientData.address1,
        address2: editRecipientData.address2,
        zipCode: editRecipientData.zipcode,
        nationality: editRecipientData.recvCountryName,
        city: editRecipientData.city,
        state: editRecipientData.state,
        country: editRecipientData.recvCountryName,
      });
      form1.setFieldsValue({
        deliveryOptions: editRecipientData.recvMode,
        accountNo: editRecipientData.accountNo,
        accConNum: editRecipientData.accountNo,
        bankName: editRecipientData.bankName,
        bankCity: editRecipientData.bankCity,
        branch: editRecipientData.bankBranch,
        accountType: editRecipientData.accountType,
        IFSCCode: editRecipientData.branchCode,
        bankState: editRecipientData.bankState,
      });
    }
  }, [editRecipientData]);

  useEffect(() => {
    getDeliveryOptions();
    getNationality();
    getCoutryCodes();
    getBankList();
    getReceiverCountryLists();
    // getOccupationLists();
    if (getProcessingPartner(AuthReducer.sendCountryCode) === "LULU") {
      getCodesList();
    } else {
      getRelationshipLists();
    }
    getStateLists();
    form1.setFieldsValue({
      country: editRecipientData.recvCountryName,
    });
    setState({
      redirectPage: location.state?.fromPage,
      redirectPageState: location.state?.fromPageState,
    });
  }, []);

  const getNationality = async () => {
    const payload = {
      requestType: "NATIONALITYLIST",
      keyword: "",
    };

    setLoader(true);
    hookGetNationality.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ nationalities: data.responseData });
      } else {
        notification.error({ message: data.data.errorMessage });
      }
      setLoader(false);
    });
  };

  const getReceiverCountryLists = () => {
    const payload = {
      requestType: "RECVCOUNTRYLIST",
      sendCountry: "GB",
      sendCurrency: "GBP",
    };

    hookGetReceiverCountryLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({
          receiverCountryLists: data.responseData,
        });
        props.newForm1.setFieldsValue({
          country: data.responseData[0].countryName,
        });
      }
    });
  };

  const getCoutryCodes = async () => {
    if (AuthReducer.groupId === "XR") {
      setState({
        phoneCodes: [
          { countryPhoneCode: 44, countryName: "United Kingdom" },
          { countryPhoneCode: 91, countryName: "India" },
        ],
        selectPhoneCodes: true,
      });
    } else {
      const payload = {
        requestType: "COUNTRYPHONECODE",
      };
      props.AddRecipientFormsetLoader(true);
      hookGetCountryPhoneCodes.sendRequest(payload, function (data) {
        if (data.status == "S") {
          let _recvCountryCode = data.responseData.filter((item) => item.countryCode === AuthReducer.recvCountryCode);

          setState({
            phoneCodes: data.responseData,
            selectPhoneCodes: false,
            // mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
          });
          props.newForm1.setFieldsValue({
            mobileCountryCode: _recvCountryCode[0].countryPhoneCode,
          });
          props.setLoader(false);
        }
      });
    }
  };

  const getCodesList = async () => {
    let payload = {
      requestType: "LULUGETCODES",
      userId: AuthReducer.userID,
    };
    hookGetCodes.sendRequest(payload, function (data) {
      if (data.status === "S") {
        let resultData = JSON.parse(data?.resultData?.data);
        setState({ relationshipLists: resultData?.relationships });
      }
    });
  };

  const getRelationshipLists = async () => {
    let payload = {
      requestType: "RELAIONSHIPLISTS",
    };

    setLoader(true);
    hookGetRelationshipLists.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ relationshipLists: data.responseData });
      }
      setLoader(false);
    });
  };

  const getDeliveryOptions = async () => {
    let payload = {
      requestType: "RECVMODE",
      countryCode: AuthReducer.recvCountryCode,
    };
    setLoader(true);
    hookGetDeliveryOptions.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ deliveryOptionsList: data.responseData });
        setLoader(false);
      }
    });
  };
  const getStateCityList = async (stateCode) => {
    const payload = {
      requestType: "CITILIST",
      keyword: "",
      stateCode: stateCode,
      countryCode: AuthReducer.recvCountryCode,
    };

    setLoader(true);
    hookGetStateCities.sendRequest(payload, function (data) {
      if (data.status == "S") {
        setState({ stateCities: data.responseData });
      } else {
        notification.error({ message: data.errorMessage });
        setState({ stateCities: [] });
      }
      setLoader(false);
    });
  };
  const onSelectState = (value) => {
    getStateCityList(value);
  };

  const getStateLists = async () => {
    let payload = {
      requestType: "STATELIST",
      countryCode: AuthReducer.recvCountryCode,
      keyword: "",
    };
    setLoader(true);
    hookGetCountryStates.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({ stateLists: data.responseData });
        setLoader(false);
      }
    });
  };

  const onChangeIFSCCode = async (e) => {
    if (e.target.value.length == 11) {
      const payload = {
        requestType: "BANKBRANCHDATA",
        branchCode: e.target.value,
      };
      setLoader(true);
      hookGetBankBranchData.sendRequest(payload, function (data) {
        if (data.status == "S") {
          notification.success({ message: data.message });
          setState({
            branchCode: data.branchCode,
            bankBranch: data.branchName,
            bankAddress: data.bankAddress,
            bankState: data.bankState,
            bankCity: data.bankCity,
            bankName: data.bankName,
            bankId: data.bankId,
            bankCountry: data.bankCountry,
          });
          form1.setFieldsValue({
            bankName: data.bankName,
            bankState: data.bankState,
            bankCity: data.bankCity,
            branch: data.branchName,
          });
          setLoader(false);
        } else {
          // notification.error({ message: res.data.errorMessage });
          form1.setFields([{ name: "IFSCCode", errors: [data.data.errorMessage] }]);
          setState({
            branchCode: "",
            bankBranch: "",
            bankAddress: "",
            bankState: "",
            bankCity: "",
            bankName: "",
            bankId: "",
            bankCountry: "",
          });
        }
        setLoader(false);
      });
    } else {
      setState({
        branchCode: "",
        bankBranch: "",
        bankAddress: "",
        bankState: "",
        bankCity: "",
        bankName: "",
        bankId: "",
        bankCountry: "",
      });
    }
  };

  const getBankList = async (e) => {
    const payload = {
      requestType: "BANKLIST",
      countryCode: AuthReducer.recvCountryCode,
      userId: state.userID,
    };

    setLoader(true);
    hookGetBankLists.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          bankLists: data.responseData,
        });
        setLoader(false);
      }
    });
  };

  const onSetectBank = async (row) => {
    const bankName = row.value;
    let bankCode = row.label.props.bankCode;
    let isSameBank = row.label.props.isSameBank;
    setState({
      bankName: bankName,
      bankCode: bankCode,
      isSameBank: isSameBank,
    });
    form1.setFieldsValue({
      bankName: bankName,
      cityName: undefined,
      branch: undefined,
      bankCity: undefined,
      branchCode: undefined,
    });
    const payload = {
      requestType: "BankStateCities",
      countryCode: AuthReducer.recvCountryCode,
      state: "",
      bankName: bankName,
      search: "",
    };

    setLoader(true);
    hookGetBankStateCities.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          cityLists: data.responseData,
        });
        setLoader(false);
      }
    });
  };

  const onSetectCity = async (cityName) => {
    setState({ bankCity: cityName });
    const payload = {
      requestType: "BANKBRANCHES",
      countryCode: AuthReducer.recvCountryCode,
      bankCode: state.bankCode,
      bankName: state.bankName,
      cityCode: "",
      stateCode: "",
      city: cityName,
      keyword: "",
    };

    setLoader(true);
    hookGebankBranches.sendRequest(payload, function (data) {
      if (data.status === "S") {
        setState({
          branchLists: data.responseData,
        });
        setLoader(false);
      }
    });
  };

  const onSetectBranch = async (value) => {
    let branch = JSON.parse(value);
    setState({
      branchCode: branch.branchCode,
      bankBranch: branch.branchName,
      bankAddress: branch.bankAddress,
      bankState: branch.bankState,
      bankCity: branch.bankCity,
      bankName: branch.bankName,
      bankId: branch.bankId,
      bankCountry: branch.bankCountry,

      // bankCode: bankCode,
      // branchName: branchName
    });

    form1.setFieldsValue({
      IFSCCode: branch.branchCode,
      branch: branch.branchName,
      bankState: branch.bankState,
    });
  };

  const editReceiver = async (value) => {
    let editPostData = value.editData;
    hookEditReceiver.sendRequest(editPostData, function (data) {
      if (data.status == "S") {
        setLoader(false);
        props.getReceiverLists();
        notification.success({ message: data.message });
        props.setEditRecipientModal(false);
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form1.setFields(errors);
        if (errors.length > 0) form.setFields(errors);
        setLoader(false);
      }
    });
  };
  const editReceiver2 = async (value) => {
    let editPostData = { ...value.editData, relationship: state?.relationshipValue, recvRefNo: state?.relationshipValue };
    hookEditReceiver2.sendRequest(editPostData, function (data) {
      setLoader(false);
      if (data.status == "S") {
        props.getReceiverLists();
        notification.success({ message: data.message });
        props.setEditRecipientModal(false);
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });
        if (errors.length > 0) form1.setFields(errors);
        if (errors.length > 0) form.setFields(errors);
        setLoader(false);
      }
    });
  };

  const activeTab = (key) => {
    if (currentTab !== key) {
      setCurrentTab(key);
    }
  };
  const onFinish1 = async (value) => {
    setForm1Data(value);
    setActiveStep(!activeStep);
  };

  const onFinish2 = async (val) => {
    let value = { ...val, ...form1Data };
    let formData = {
      requestType: "RECEIVERADD",
      receiverType: "INDIVIDUAL",
      firstName: value.firstName.trim(),
      middleName: value.middleName ? value.middleName : "",
      lastName: value.lastName.trim(),
      nickName: value.nickName.trim(),
      accountNo: value.accountNo,
      relationship: value.relationship,
      dob: state.dob ? state.dob : "",

      address1: value.address1.trim(),
      address2: value.address2 ? value.address2 : state.address2,
      zipcode: value.zipCode,
      // zipCode: value.zipCode,
      state: value.state.trim(),
      stateOther: "",
      city: value.city.trim(),
      nationality: value.nationality,
      cityOther: "",
      emailId: value.emailId ? value.emailId : "",

      mobileCountryCode: value.mobileCountryCode ? value.mobileCountryCode : "",
      mobileNo: value.mobileNo ? value.mobileNo : "",
      phoneNo: value.phoneNo ? value.phoneNo : "",

      altPhone: "",
      fax: "",

      recvMode: form1Data.deliveryOptions,
      accountHolderName: `${value.firstName.trim()} ${value.lastName.trim()}`,

      accountType: value.accountType,
      bankCode: value.bankCode,
      bankName: value.bankName ? value.bankName : state.bankName,
      branchCode: value.IFSCCode ? value.IFSCCode : state.branchCode,
      bankBranch: value.branch ? value.branch : state.bankBranch,
      bankAddress: value.bankAddress ? value.bankAddress : state.bankAddress,
      bankState: value.bankState ? value.bankState : state.bankState,
      bankCity: value.bankCity ? value.bankCity : state.bankCity,
      isSameBank: "N",

      nearestBranchCode: "",
      nearestBranch: "",
      recvUniqueIdType: "",
      recvUniqueIdValue: "",

      interBankCode: "",
      interBank: "",
      interAccountNo: "",
      interAccountType: "",
      interBranchCode: "",
      interBankBranch: "",
      interBankAddress: "",
      interBankCountry: "",

      recvCountry: AuthReducer.recvCountryCode,
      recvCurrency: AuthReducer.recvCurrencyCode,
      purpose: "",
      purposeCode: "",
      remark: "",
      twofa: state.twofa,
      userId: state.userID,
      recordToken: editRecipientData.recordToken,
    };
    setLoader(true);
    await hookCheckDuplicateReceiver.sendRequest(formData, function (data) {
      if (data.status == "S") {
        if (getProcessingPartner(AuthReducer.sendCountryCode) === "LULU") {
          editReceiver2({ editData: formData });
        } else {
          editReceiver({ editData: formData });
        }
      } else {
        notification.error({ message: data.errorMessage });
        setLoader(false);
      }
    });
  };

  const onChangeDeliveryOptionHandler = (value) => {
    setState({
      deliveryOption: value,
    });
  };

  return (
    <div className="EditReceiver">
      <Spinner spinning={loading}>
        <div className="d-flex justify-content-between mb-32">
          <h2 className="mb-4">Edit Receiver</h2>
          {activeStep ? <h2>Step 1</h2> : <h2>Step 2</h2>}
        </div>
        {activeStep && (
          <Form onFinish={onFinish1} form={form1}>
            <Row>
              <Col className="Modal-Delivery-Options-Container">
                <label className="form-label">Delivery Options</label>

                <CustomInput className="form-item" name="deliveryOptions" placeholder="Select Delivery Options" label="Delivery Options" showLabel={false} required type="select" onChange={onChangeDeliveryOptionHandler}>
                  {state.deliveryOptionsList.map((value, i) => {
                    return (
                      <Option key={i} value={value.recvModeCode}>
                        {value.recvMode}
                      </Option>
                    );
                  })}
                </CustomInput>
              </Col>
            </Row>
            <label>Do you know the IFSC of beneficiary bank?</label>
            <Tabs defaultActiveKey={currentTab} onChange={activeTab}>
              <TabPane tab="Yes" key="1">
                <Row>
                  <Col md={6}>
                    <CustomInput className="mb-0" name="IFSCCode" label="Receivers IFSC Code" min={11} max={12} onChange={onChangeIFSCCode} autoComplete="none" required />
                  </Col>
                </Row>
                <Row>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="bankName" label="Bank Name">
                        <AutoComplete disabled showSearch labelInValue placeholder="Bank Name"></AutoComplete>
                      </CustomInput>
                    </div>
                  </Col>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="bankState" label="Bank Branch State">
                        <AutoComplete disabled showSearch placeholder="Bank Branch State"></AutoComplete>
                      </CustomInput>
                    </div>
                  </Col>
                </Row>
                <Row>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="bankCity" label="City">
                        <AutoComplete disabled showSearch onSelect={onSetectCity} placeholder="City"></AutoComplete>
                      </CustomInput>
                    </div>
                  </Col>
                  <Col sm={12} md={6}>
                    <div>
                      <CustomInput name="branch" label="Branch">
                        <AutoComplete disabled autoComplete="off" showSearch onSelect={onSetectBranch} placeholder="Branch"></AutoComplete>
                      </CustomInput>
                    </div>
                  </Col>
                </Row>
                <div className="row">
                  <div className="col-12 col-md-6">
                    <div>
                      <CustomInput
                        name="accountNo"
                        label="Account Number"
                        autoComplete="off"
                        type="password"
                        className="input_account_no"
                        placeholder="Enter your Account Number"
                        required
                        validationRules={[...inputValidations.accountNumber(AuthReducer.recvCountryCode)]}
                        onPaste={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        onCopy={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        visibilityToggle={false}
                      />
                    </div>
                  </div>
                  <div className="col-12 col-md-6">
                    <div>
                      <CustomInput
                        name="accConNum"
                        className="input_account_no"
                        label="Confirm Account Number"
                        placeholder="Enter your Confirm Account Number"
                        validationRules={[
                          ...inputValidations.accountNumber(AuthReducer.recvCountryCode),
                          ({ getFieldValue }) => ({
                            validator(rule, value) {
                              if (!value || getFieldValue("accountNo") === value) {
                                return Promise.resolve();
                              }
                              return Promise.reject("The two account number that you entered do not match!");
                            },
                          }),
                        ]}
                        onPaste={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        onCopy={(e) => {
                          e.preventDefault();
                          return false;
                        }}
                        required
                      />
                    </div>
                  </div>
                </div>

                <Row>
                  <Col>
                    <CustomInput name="accountType" label="Account Type" required>
                      <Radio.Group className="d-flex">
                        <Radio value={"S"}>Savings Account</Radio>
                        <Radio value={"NE"}>NRE</Radio>
                        <Radio value={"NO"}>NRO</Radio>
                      </Radio.Group>
                    </CustomInput>
                  </Col>
                  <Col className="d-flex justify-content-end align-items-center">
                    <button className="btn btn-light text-primary" type="submit">
                      Next
                    </button>
                  </Col>
                </Row>
              </TabPane>
              <TabPane tab="No" key="2">
                <Row>
                  <Col>
                    <label className="form-label">Bank Name</label>
                    <CustomInput className="form-item w-100" name="bankName" showSearch labelInValue placeholder="Select Bank" label="Bank Name" type="select" showLabel={false} required onChange={onSetectBank}>
                      {state.bankLists.map((bank, i) => {
                        return (
                          <Option key={i} value={bank.bankName}>
                            <span bankCode={bank.bankCode} isSameBank={bank.isSameBank}>
                              {bank.bankName}
                            </span>
                          </Option>
                        );
                      })}
                    </CustomInput>
                  </Col>
                  <Col>
                    <CustomInput name="bankState" label="Bank Branch State" howSearch placeholder="Select State" type="select" required>
                      {state.stateLists.map((state, i) => {
                        return (
                          <Option key={i} value={state.stateCode}>
                            {state.state}
                          </Option>
                        );
                      })}
                    </CustomInput>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <label className="form-label">City</label>
                    <CustomInput className="form-item w-100" name="bankCity" placeholder="Select City" showSearch onChange={onSetectCity} type="select" label="City" showLabel={false} required>
                      {state.cityLists.map((city, i) => {
                        return (
                          <Option key={i} value={city.city}>
                            {city.city}
                          </Option>
                        );
                      })}
                    </CustomInput>
                  </Col>
                  <Col>
                    <label className="form-label">Branch</label>

                    <CustomInput className="form-item" name="branch" placeholder="Select Branch" showSearch onChange={onSetectBranch} label="branch" type="select" showLabel={false} required>
                      {state.branchLists.map((branch, i) => {
                        return (
                          <Option key={i} value={JSON.stringify(branch)}>
                            {branch.branchName}
                          </Option>
                        );
                      })}
                    </CustomInput>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <label className="form-label">Account Number</label>
                    <CustomInput
                      className="form-item"
                      name="accountNo"
                      label="Account Number"
                      showLabel={false}
                      placeholder="Enter your Account Number"
                      maxLength={12}
                      type="password"
                      required
                      validationRules={[...inputValidations.accountNumber(AuthReducer.recvCountryCode)]}
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      visibilityToggle={false}
                    />
                  </Col>
                  <Col>
                    <CustomInput name="accountType" label="Account Type" required>
                      <Radio.Group
                        // onChange={onChangeAccountTypeHandler}
                        className="d-flex"
                      >
                        <Radio value={"S"}>Savings Account</Radio>
                        <Radio value={"NE"}>NRE</Radio>
                        <Radio value={"NO"}>NRO</Radio>
                      </Radio.Group>
                    </CustomInput>
                  </Col>
                </Row>
                <Row>
                  <Col>
                    <label className="form-label">Confirm Account Number</label>
                    <CustomInput
                      className="form-item"
                      name="accConNum"
                      label="Confirm Account Number"
                      showLabel={false}
                      required
                      placeholder="Enter your Confirm Account Number"
                      maxLength={12}
                      validationRules={[
                        ...inputValidations.accountNumber(AuthReducer.recvCountryCode),
                        ({ getFieldValue }) => ({
                          validator(rule, value) {
                            if (!value || getFieldValue("accountNo") === value) {
                              return Promise.resolve();
                            }
                            return Promise.reject("The two account number that you entered do not match!");
                          },
                        }),
                      ]}
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Col>
                  <Col className="d-flex justify-content-end align-items-center">
                    <button className="btn btn-light text-primary" type="submit">
                      Next
                    </button>
                  </Col>
                </Row>
              </TabPane>
            </Tabs>
            <Row></Row>
          </Form>
        )}
        {!activeStep && (
          <Form form={form} onFinish={onFinish2}>
            <Row>
              <Col>
                <Row>
                  <div className="Container">
                    <CustomInput name="firstName" label="First Name" min={2} max={30} placeholder="Enter your First Name" autoComplete="none" required />
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput name="middleName" label="Middle Name" min={2} max={30} placeholder="Enter your Middle Name" autoComplete="none" />
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput name="lastName" label="Last Name" min={2} max={30} required placeholder="Enter your Last Name" autoComplete="none" />
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput
                      name="nickName"
                      label="Nick Name"
                      min={2}
                      max={30}
                      required
                      placeholder="Enter your Nick Name"
                      autoComplete="none"
                      validationRules={[
                        {
                          pattern: /^[a-zA-Z0-9]+$/,
                          message: "No Special Chars",
                        },
                      ]}
                    />
                  </div>
                </Row>
                <Row>
                  {getProcessingPartner(AuthReducer.sendCountryCode) === "LULU" ? (
                    <div className="Container">
                      <CustomInput
                        name="relationship"
                        label="Relationship"
                        type="select"
                        placeholder="Select Relationship"
                        showSearch
                        required
                        onChange={(v) => {
                          let value = JSON.parse(v);
                          setState({
                            relationshipValue: value.code,
                            relationshipDesc: value.name,
                          });
                        }}
                      >
                        {state.relationshipLists.map((list, i) => {
                          return (
                            <Option key={i} value={JSON.stringify(list)}>
                              {list.name}
                            </Option>
                          );
                        })}
                      </CustomInput>
                    </div>
                  ) : (
                    <div className="Container">
                      <CustomInput
                        name="relationship"
                        label="Relationship"
                        type="select"
                        placeholder="Select Relationship"
                        showSearch
                        required
                        onChange={(value) => {
                          setState({
                            relationshipValue: value.relationshipValue,
                            relationshipDesc: value.relationshipDesc,
                          });
                        }}
                      >
                        {state.relationshipLists.map((list, i) => {
                          return (
                            <Option key={i} value={list.relationshipDesc}>
                              {list.relationshipDesc}
                            </Option>
                          );
                        })}
                      </CustomInput>
                    </div>
                  )}
                </Row>
              </Col>
              <Col>
                <Row>
                  <div className="Container">
                    <CustomInput name="address1" label="Address" min={3} max={300} required>
                      <TextArea autoComplete="none" />
                    </CustomInput>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item" name="state" label="State" required>
                      <AutoComplete className="w-100" placeholder="Select State" onSelect={onSelectState} filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1} autoComplete="none">
                        {state.stateLists.map((state, i) => {
                          return (
                            <Option key={i} value={state.stateCode}>
                              {state.state}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </CustomInput>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item" name="city" label="City" required>
                      <AutoComplete autoComplete="none" className="w-100" placeholder="Select City" filterOption={(inputValue, option) => option.value.toUpperCase().indexOf(inputValue.toUpperCase()) !== -1}>
                        {state.stateCities.map((city, i) => {
                          return (
                            <Option key={i} value={city.city}>
                              {city.city}
                            </Option>
                          );
                        })}
                      </AutoComplete>
                    </CustomInput>
                  </div>
                </Row>
              </Col>
              <Col>
                <Row>
                  <div className="Container">
                    <CustomInput className="form-item w-100" name="country" label="Country" placeholder="Select Country" type="select" required>
                      {state.receiverCountryLists.map((clist, i) => {
                        return <Option key={i} value={clist.countryName}>{`${clist.countryName}`}</Option>;
                      })}
                    </CustomInput>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput name="zipCode" placeholder="Enter Zipcode" autoComplete="none" label="Pincode" required validationRules={[...inputValidations.zipCode(AuthReducer.recvCountryCode)]} />
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <label>Mobile Number</label>
                    <div className="d-flex justify-content-between">
                      <CustomInput name="mobileCountryCode" label="Mobile Number" showLabel={false} type="select" required autoComplete="none" showSearch placeholder="Select Phone Code">
                        {state.phoneCodes.map((phoneCode, i) => {
                          return <Option key={i} value={phoneCode.countryPhoneCode}>{`(${phoneCode.countryPhoneCode}) ${phoneCode.countryName}`}</Option>;
                        })}
                      </CustomInput>

                      <CustomInput
                        name="mobileNo"
                        label="Mobile Number"
                        showLabel={false}
                        min={10}
                        max={10}
                        placeholder="123456789"
                        maxLength={10}
                        autoComplete="none"
                        validationRules={[
                          {
                            pattern: /^[0-9\b]+$/,
                            message: "Only Numbers allowed",
                          },
                        ]}
                      />
                    </div>
                  </div>
                </Row>
                <Row>
                  <div className="Container">
                    <CustomInput
                      name="phoneNo"
                      label="Phone Number"
                      placeholder="123456789"
                      min={0}
                      max={14}
                      maxLength={10}
                      autoComplete="none"
                      validationRules={[
                        {
                          pattern: /^[0-9\b]+$/,
                          message: "Only Numbers allowed",
                        },
                      ]}
                    />
                  </div>
                </Row>
              </Col>
            </Row>
            <div className="d-flex justify-content-between">
              <button className="Back-Button" onClick={() => setActiveStep(!activeStep)}>
                Back
              </button>
              <button className="btn btn-light text-primary" type="submit">
                Confirm Recipient
              </button>
            </div>
          </Form>
        )}
      </Spinner>
    </div>
  );
}