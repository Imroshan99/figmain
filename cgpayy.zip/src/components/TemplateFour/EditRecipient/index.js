import React, { useEffect } from "react";
import { useSelector } from "react-redux";
import EditRecipient2 from "./EditRecipientFlow2/EditRecipient";
import Dashboard from "../Layouts/Dashboard";
import { useOutletContext } from "react-router-dom";
// import DashboardTemplate1 from "../Layouts/Dashboard/DashboardTemplate1";

const EditRecipient = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const temp = AuthReducer.groupIdSettings?.theme?.SIGN;
  const templateFlow = AuthReducer.groupIdSettings?.AddRecipientForm?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Edit Recipient");
  }, []);
  return (
    <>
      {templateFlow === "FLOW2" && (
        <EditRecipient2
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default EditRecipient;
