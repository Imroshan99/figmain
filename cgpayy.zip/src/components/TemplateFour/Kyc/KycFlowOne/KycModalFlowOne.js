import { Modal } from "antd";
import Kyc from "./Kyc";

export default function KycModalFlowOne(props) {
  return (
    <>
      <Modal
        className="light kyc"
        centered
        visible={props.isModalVisible}
        onCancel={() => {
          props.setIsModalVisible(false);
        }}
        footer={null}
        width={1000}
      >
        <Kyc
          getProfile={props.getProfile}
          setIsModalVisible={props.setIsModalVisible}
        />
      </Modal>
    </>
  );
}
