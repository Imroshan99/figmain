import { useSelector } from "react-redux";
import AuthTemplateOne from "./AuthTemplateOne";
import AuthTemplateTwo from "./AuthTemplateTwo";
import AuthTemplateThree from "./AuthTemplateThree";
import AuthTemplateFour from "./AuthTemplateFour";
import AuthTemplateFive from "./AuthTemplateFive";
import AuthTemplateSix from "./AuthTemplateSix";
import AuthTemplateSeven from "./AuthTemplateSeven";
import { Outlet } from "react-router-dom";

export default function AuthTemplate(props) {
  const groupConfig = useSelector((state) => state.user);
  const authTemplate = groupConfig.groupIdSettings?.theme?.Auth;
  return (
    <>
      {authTemplate === "AuthTemp1" && (
        <AuthTemplateOne>
          <Outlet />
        </AuthTemplateOne>
      )}
      {authTemplate === "AuthTemp2" && (
        <AuthTemplateTwo>
          <Outlet />
        </AuthTemplateTwo>
      )}
      {authTemplate === "AuthTemp3" && (
        <AuthTemplateThree>
          <Outlet />
        </AuthTemplateThree>
      )}
      {authTemplate === "AuthTemp4" && (
        <AuthTemplateFour>
          <Outlet />
        </AuthTemplateFour>
      )}
      {authTemplate === "AuthTemp5" && (
        <AuthTemplateFive>
          <Outlet />
        </AuthTemplateFive>
      )}
      {authTemplate === "AuthTemp6" && (
        <AuthTemplateSix>
          <Outlet />
        </AuthTemplateSix>
      )}
      {authTemplate === "AuthTemp7" && (
        <AuthTemplateSeven>
          <Outlet />
        </AuthTemplateSeven>
      )}
    </>
  );
}
