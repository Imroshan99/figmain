import React, { useEffect, useState } from "react";
import { useSelector } from "react-redux";
import { Link, Outlet, useLocation, useNavigate } from "react-router-dom";

const AuthTemplateSeven = (props) => {
  const [title, setTitle] = useState("");
  const AuthReducer = useSelector((state) => state.user);

  //  const [dt, setDt] =  useState(new Date())
  //   useEffect(()=>{
  //     setDt(new Date())
  //   }, [])

  return (
    <div className="container authpage">
      {/* {dt.toUTCString()} */}

      <div className="row justify-content-center">
        <div className="col-12 col-md-6">
          <header className="mb-5 pt-5 pb-3">
            <div className="row">
              <div className="col-12">
                <div class="d-flex">
                  <div class="p-2 align-self-center">
                    <div className="nav-wrapper">
                      <div className="brand-logo">
                        <Link to="/">
                          <img
                            src={`images/group/${AuthReducer.groupId}/logo.png`}
                            alt={`${AuthReducer.groupId} Logo`}
                          />
                        </Link>
                      </div>
                    </div>
                  </div>
                  <div class="p-2 flex-fill">
                    <span className="pagetitle text-secondary">{title}</span>
                  </div>
                </div>
              </div>
            </div>
          </header>
          {props.children}
          {/* <Outlet context={[title, setTitle]} /> */}
        </div>
      </div>
    </div>
  );
};

export default AuthTemplateSeven;
