import React from "react";

const AuthTemplateThree = (props) => {
  return (
    <div className="container-fluid p-0 m-0  h-100 auth_temp3">
  
      {/* {state._isShowOTPBOX && <OTPBox state={state} setState={setState} storeLoginData={storeLoginData} otpType={state.otpType} useFor="login" appState={props.appState} />} */}

      <div className="row m-auto h-100 bg-signIn-image-1  d-sm-flex">
        <div className=" col-md-6 h-100 col-xs-24 order-sm-2 order-md-1">
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-8 col-xxl-6 ">
              <div className="card">
                <div class="card-body">{props.children}</div>
              </div>
            </div>
          </div>
        </div>
        <div className="col-md-6 col-sm-24 h-100  order-xs-2 order-sm-1 order-md-2">
          <div className="row h-100 justify-content-center align-items-center">
            <div className="col-12 col-md-8 col-lg-8 col-xl-8">
              <div className="w-100 h-100 text-center">
              <img
                src={require("../../../../assets/images/banners/remittence2.png")}
                alt="Mobile Banner"
              />
              </div>
              <div className="mt-5">
                <h2 className="w-100 mx-auto text-center">
                  Fast, Efficient and Productive
                </h2>
                <div className="w-100 text-center">
                  In this kind of post, the bloggerintroduces a person they’ve
                  interviewed and provides some background information about the
                  intervieweeand their work following this is a transcript of
                  the interview.
                </div>
              </div>
            </div>
          </div>

          {/* <ExchangeRate /> */}
        </div>
        
      </div>
    </div>
  );
};

export default AuthTemplateThree;
