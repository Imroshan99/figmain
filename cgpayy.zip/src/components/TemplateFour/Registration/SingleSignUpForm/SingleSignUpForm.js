import React, { useState, useEffect, useReducer } from "react";
import { Link, useNavigate } from "react-router-dom";
import {
  Form,
  Input,
  Checkbox,
  Select,
  Radio,
  DatePicker,
  notification,
  Spin,
} from "antd";
import moment from "moment";
import OTPBox from "../../../../containers/OTPBox";
import { config } from "../../../../config";
import { useSelector } from "react-redux";
import useHttp from "../../../../hooks/useHttp";
import { GuestAPI } from "../../../../apis/GuestAPI";
import { AuthAPI } from "../../../../apis/AuthAPI";
import TCModal from "../../../../containers/ModalBox/TCModal";
import CustomInput from "../../../../reusable/CustomInput";
import { getProcessingPartner } from "../../../../services/utility/group";
import { ViAmericaAuthAPI } from "../../../../apis/ViAmericaApi/Auth";

const { Option } = Select;
const salutationList = [
  { value: "Mr", label: "Mr" },
  { value: "Mrs", label: "Mrs" },
  { value: "Ms", label: "Ms" },
];
export default function SingleSignUpForm(props) {
  const ConfigReducer = useSelector((state) => state.user);
  const AuthReducer = useSelector((state) => state.user);
  let navigate = useNavigate();

  const [form] = Form.useForm();
  const [loading, setLoader] = useState(false);
  const [submitFormFlag, setSubmitFormFlag] = useState(false);
  const [isSelectMarketingCommunication, setisSelectMarketingCommunication] =
    useState("N");

  const [state, setState] = useReducer(
    (state, newState) => ({ ...state, ...newState }),
    {
      phoneCodes: [],
      sendCountryList: [],
      isModalVisible: false,
      tcModalVisible: false,
      verificationToken: "",
      verifiedToken: "",
      clientId: ConfigReducer.clientId,
      groupId: ConfigReducer.groupId,
      twofa: ConfigReducer.twofa,
      sessionId: ConfigReducer.sessionId,
      dob: "",
      formData: {},
      _isShowOTPBOX: false,
    }
  );

  // API HOOKS
  const hookGetCountryPhoenCodes = useHttp(GuestAPI.getCountryPhoneCodes);
  const hookGetSendingCountryList = useHttp(GuestAPI.sendingCountryList);
  const hookSaveLeads = useHttp(AuthAPI.saveLeads);
  const hookCheckDedupe = useHttp(AuthAPI.checkDedupe);
  const hookSignUp = useHttp(AuthAPI.signUp);
  const hookGetUserCountryList = useHttp(GuestAPI.countryList);
  const hookSignUpViAmerica = useHttp(ViAmericaAuthAPI.signUp);

  useEffect(() => {
    if (submitFormFlag) {
      checkDedupe("");
    }
  }, [submitFormFlag]);

  useEffect(() => {
    window.scrollTo({ top: 0, behavior: "smooth" });
    getCountryList();
    getCounryPhoneCode();
  }, []);

  const getCountryList = () => {
    const countryPayload = {
      requestType: "COUNTRYLIST",
    };
    setLoader(true);
    hookGetUserCountryList.sendRequest(countryPayload, function (data) {
      setLoader(false);

      if (data.status === "S") {
        setState({ sendCountryList: data.responseData });
      }
    });
  };

  const getCounryPhoneCode = () => {
    const countryPayload = {
      requestType: "COUNTRYPHONECODE",
    };
    setLoader(true);
    hookGetCountryPhoenCodes.sendRequest(countryPayload, function (data) {
      setLoader(false);
      if (data.status === "S") {
        const phoneCodesData = data.responseData;
        // setState({ phoneCodes: phoneCodesData });
        const phoneCodeForSendCountry = phoneCodesData.filter((item) => {
          return item.countryCode === AuthReducer.sendCountryCode;
        });
        setState({ phoneCodes: phoneCodesData });
      }
    });
  };

  const onCreateLead = (value) => {
    form.setFields([
      { name: "country", errors: [] },
      { name: "salutation", errors: [] },
      { name: "firstName", errors: [] },
      { name: "middleName", errors: [] },
      { name: "lastName", errors: [] },
      { name: "mobilePhoneCode", errors: [] },
      { name: "mobileNo", errors: [] },
      { name: "dob", errors: [] },
      { name: "emailId", errors: [] },
    ]);

    var marketingCommunication = "";
    if (value.isSameCommAddressFlag == "Y") {
      value.marketingCommunicationMedia.forEach((data) => {
        marketingCommunication = marketingCommunication + "~" + data;
      });

      marketingCommunication = marketingCommunication + "~";
    }

    let leadData = {
      requestType: "LEAD",
      salutation: value.salutation,
      firstName: value.firstName,
      middleName: value.middleName === undefined ? "" : value.middleName,
      lastName: value.lastName,
      gender: state.gender,
      loginId: value.emailId,
      emailId: value.emailId,
      sendCountry: value.country,
      mobilePhoneCode: value.mobilePhoneCode,
      mobileNo: value.mobileNo,
      dob: state.dob,
      lpID: "",
      pageReferer: "savsa",
      custType: "INDIVITUAL",
      periodicUpdate: "N", //if yes then marketingCommunication pass
      marketingCommunication: marketingCommunication,
      otpFlag: state.twofa,
    };

    setLoader(true);
    hookSaveLeads.sendRequest(leadData, function (data) {
      value.leadId = data.leadId;
      if (data.status === "S") {
        setState({ verificationToken: data.verificationToken });
        if (state.twofa === "N") {
          setState({
            formData: value,
          });
          setSubmitFormFlag(true);
          // checkDedupe("", value);
        } else {
          setState({
            _isShowOTPBOX: true,
            isModalVisible: true,
            formData: value,
          });
        }
      } else {
        notification.error({ message: data.errorMessage });
        if (data.errorList) {
          let errors = [];
          data.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });

          if (errors.length > 0) form.setFields(errors);
        }
      }
      setLoader(false);
    });
  };

  const checkDedupe = (verifiedToken) => {
    setSubmitFormFlag(false);
    let payload = {
      requestType: "DEDUPECHECK",
      salutation: state.formData.salutation,
      firstName: state.formData.firstName,
      lastName: state.formData.lastName,
      emailId: state.formData.emailId,
      mobilePhoneCode: state.formData.mobilePhoneCode,
      mobileNo: state.formData.mobileNo,
      dob: state.dob,
      countryCode: AuthReducer.sendCountryCode,
    };
    setLoader(true);
    hookCheckDedupe.sendRequest(payload, function (data) {
      saveSignUpData(verifiedToken);
      // setState({ _isShowSetPassword: true });
      // if (res.data.status == "S") {
      //     console.log('suceess')
      //     setState({_isShowSetPassword: true})
      // } else {
      //     console.log('failed')
      //     notification.error({ message: res.data.errorMessage })
      // }
      setLoader(false);
    });
  };

  const saveSignUpData = (verifiedToken) => {
    form.setFields([{ name: "password", errors: [] }]);
    let _luluExtraParams;
    if (getProcessingPartner(state.formData.country) === "LULU") {
      _luluExtraParams = {
        consentPrimary: "Y",
        tnc: "Y",
      };
    }
    const signUPData = {
      ..._luluExtraParams,
      requestType: "SIGNUP",
      sendCountry: state.formData.country,
      salutation: state.formData.salutation,
      firstName: state.formData.firstName,
      middleName: state.formData.middleName ? state.formData.middleName : "",
      lastName: state.formData.lastName,
      loginId: state.formData.emailId,
      emailId: state.formData.emailId,
      password: state.formData.password,
      passwordType: "PASSWORD",
      dob: state.dob,
      leadId: state.formData.leadId,
      mobilePhoneCode: state.formData.mobilePhoneCode,
      mobileNo: state.formData.mobileNo,
      recvCountry:
        AuthReducer.recvCountryCode === "" ? "IN" : AuthReducer.recvCountryCode,
      gender: state.formData.gender,
      altMobilePhoneCode: "",
      altMobileNo: "",
      marketingRef: "NA", //website~google
      address1:
        getProcessingPartner(state.formData.country) === "LULU" ? "NA" : "",
      address2: "",
      state:
        getProcessingPartner(state.formData.country) === "LULU" ? "NA" : "",
      city: "",
      zip:
        getProcessingPartner(state.formData.country) === "LULU" ? "00000" : "",
      euroCountry: "",
      pageReferer: "",
      lpId: "",
      custType: "INDIVIDUAL",
      sameBankCust: "Y",
      bankCustID: "",
      accountNo: "",
      nationality: "",
      uniqueIdentifierType: "",
      uniqueIdentifierValue: "",
      tnc: "",
      isMobileVerified: "N",
      periodicUpdate: "N", //if yes then marketingCommunication pass
      marketingCommunication: state.formData.marketingCommunication,
      twofa: state.twofa,
      verifiedToken: verifiedToken,
    };

    setLoader(true);
    hookSignUp.sendRequest(signUPData, function (data) {
      setLoader(false);
      if (data.status == "S") {
        const userId = data.userId;
        if (getProcessingPartner(signUPData.sendCountry) === "VIAMERICAS") {
          signUpViAmerica(userId);
        } else {
          // notification.success({ message: data.message });
          notification.success({
            message: "Thank you. You are successfully registered.",
          });
          navigate("/signin");
        }
      } else {
        notification.error({ message: data.errorMessage });
        let errors = [];
        data.errorList.forEach((error, i) => {
          if (error.field != "password") {
            notification.error({ message: error.error });
          }
          let errorData = {
            name: error.field,
            errors: [error.error],
          };
          errors.push(errorData);
        });

        if (errors.length > 0) form.setFields(errors);
      }
    });
  };

  const signUpViAmerica = (userId) => {
    const payload = {
      requestType: "SIGNUP",
      userId: userId,
    };
    setLoader(true);
    hookSignUpViAmerica.sendRequest(payload, function (dataVia) {
      setLoader(false);
      if (dataVia.status === "S") {
        notification.success({
          message: "Thank you. You are successfully registered.",
        });
        navigate("/signin");
      } else {
        notification.error({ message: dataVia.errorMessage });
      }
    });
  };
  const handleRecvCountry = (value) => {
    // alert(value)
    const arcountryPhoneCode = state.phoneCodes.filter(
      (v, i) => v.countryCode === value
    );
    // console.log(arcountryPhoneCode[0].countryPhoneCode);
    form.setFieldsValue({
      mobilePhoneCode: arcountryPhoneCode[0].countryPhoneCode,
    });
  };

  const handleTcModal = () => {
    setState({ tcModalVisible: true });
  };

  return (
    <div className="d-flex w-100 h-100 singlesignup_form scroll">
      <div>
        {/* {state.verificationToken} */}
        {/* <KycPage /> */}
        {state._isShowOTPBOX && (
          <OTPBox
            state={state}
            setState={setState}
            checkDedupe={checkDedupe}
            otpType="UL"
            useFor="signup"
            appState={props.appState}
          />
        )}
        {state.tcModalVisible && <TCModal state={state} setState={setState} />}

        <h1 className="title mb-4">Sign Up</h1>
        <Spin spinning={loading} delay={500}>
          <Form
            form={form}
            onFinish={onCreateLead}
            initialValues={{
              country: AuthReducer.sendCountryCode,
              // mobilePhoneCode: state.phoneCodes.filter(
              //   (item) =>
              //     item.countryCode === AuthReducer.sendCountryCode
              // ).countryPhoneCode,
              // AuthReducer.sendCountryCode === "US" ? "1" : "44",
            }}
          >
            <div className="">
              <div>
                <CustomInput
                  label="Sending money from"
                  className="form-item"
                  type="select"
                  name="country"
                  required
                >
                  {state.sendCountryList.map((clist, i) => {
                    return (
                      <Option
                        key={i}
                        value={clist.sendCountry}
                      >{`${clist.countryName}`}</Option>
                    );
                  })}
                </CustomInput>
              </div>
            </div>
            <div className="">
              <div>
                <CustomInput
                  label="Salutation"
                  className="form-item"
                  type="select"
                  name="salutation"
                  required
                >
                  {salutationList.map((clist, i) => {
                    return (
                      <Option
                        key={i}
                        value={clist.value}
                      >{`${clist.label}`}</Option>
                    );
                  })}
                </CustomInput>
              </div>
            </div>
            <div className="row">
              <div className="col">
                <div className="">
                  <CustomInput
                    className="form-item"
                    name="firstName"
                    placeholder="Enter your First Name"
                    label="First Name"
                    min={3}
                    type="text"
                    max={40}
                    required
                  />
                </div>
              </div>
              <div className="col-5">
                <div className="">
                  <CustomInput
                    className="form-item"
                    name="MiddleName"
                    placeholder="Enter your Middle Name"
                    label="Middle Name"
                    min={3}
                    type="text"
                    max={40}
                  />
                </div>
              </div>
              <div className="col">
                <div className="">
                  <CustomInput
                    className="form-item"
                    name="lastName"
                    placeholder="Enter your Last Name"
                    label="Last Name"
                    min={3}
                    type="text"
                    max={40}
                    required
                  />
                </div>
              </div>
            </div>
            <div className="">
              <CustomInput label="Gender" name="gender" required>
                <Radio.Group>
                  <Radio value="M">Male</Radio>
                  <Radio value="F">Female</Radio>
                  <Radio value="T">Other</Radio>
                </Radio.Group>
              </CustomInput>
            </div>
            <div className="row">
              <div className="col-5">
                <div className="">
                  <div>
                    <CustomInput
                      label="Country Code"
                      name="mobilePhoneCode"
                      type="select"
                      placeholder="Please select mobile"
                      showSearch
                      dropdownMatchSelectWidth={200}
                      filterOption={(input, option) =>
                        (option?.children ?? "")
                          .toLowerCase()
                          .includes(input.toLowerCase())
                      }
                      required
                    >
                      {state.phoneCodes.map((phoneCode, i) => {
                        return (
                          <Option
                            key={i}
                            value={phoneCode.countryPhoneCode}
                          >{`${phoneCode.countryPhoneCode} (${phoneCode.countryName})`}</Option>
                        );
                      })}
                    </CustomInput>
                  </div>
                </div>
              </div>
              <div className="col-7">
                <div className="">
                  <CustomInput
                    className="form-item"
                    name="mobileNo"
                    placeholder="123456789"
                    label="Mobile Number"
                    len={10}
                    maxLength={10}
                    validationRules={[
                      {
                        pattern: /^[0-9\b]+$/,
                        message: "Only numbers allowed",
                      },
                    ]}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="">
              <label className="form-label">Date Of Birth</label>
              <div>
                <Form.Item
                  className="form-item"
                  name="dob"
                  rules={[
                    {
                      required: true,
                      message: "Please input your Date Of Birth.",
                    },
                  ]}
                >
                  <DatePicker
                    size="large"
                    className="w-100"
                    defaultPickerValue={moment().subtract(18, "years")}
                    disabledDate={(d) =>
                      !d ||
                      d.isAfter(moment().subtract(18, "years")) ||
                      d.isSameOrBefore("1900-01-01")
                    }
                    onChange={(value, dateString) => {
                      value !== null
                        ? setState({ dob: dateString })
                        : setState({ dob: "" });
                    }}
                  />
                </Form.Item>
              </div>
            </div>
            <div className="">
              <CustomInput
                className=""
                name="emailId"
                type="email"
                placeholder="Enter Email ID"
                label="Email Address"
                onPaste={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCopy={(e) => {
                  e.preventDefault();
                  return false;
                }}
                onCut={(e) => {
                  e.preventDefault();
                  return false;
                }}
                required
              />
            </div>

            <div className="row">
              <div className="col-md-6">
                <div className="mb-3">
                  <CustomInput
                    className=""
                    name="password"
                    type="password"
                    placeholder="Enter your Password"
                    label="Password"
                    min={10}
                    max={20}
                    autoComplete="new-password"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    validationRules={[
                      {
                        pattern:
                          /^(?=.*?[A-Z])(?=.*?[a-z])(?=.*?[0-9])(?=.*?[#?!@$%^&*-]).{10,20}$/,
                        message:
                          "Password should be alphanumeric value with one upper case and have atleast one special character",
                      },
                    ]}
                    required
                  />
                </div>
              </div>
              <div className="col-md-6">
                <div className="mb-3">
                  <CustomInput
                    className=""
                    name="confirmPassword"
                    type="password"
                    placeholder="Enter your Confirm Password"
                    label="Confirm Password"
                    onPaste={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCopy={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    onCut={(e) => {
                      e.preventDefault();
                      return false;
                    }}
                    validationRules={[
                      ({ getFieldValue }) => ({
                        validator(rule, value) {
                          if (!value || getFieldValue("password") === value) {
                            return Promise.resolve();
                          }
                          return Promise.reject(
                            "The two password that you entered do not match!"
                          );
                        },
                      }),
                    ]}
                    required
                  />
                </div>
              </div>
            </div>

            <div className="">
              <CustomInput
                className=""
                name="hear_about_us"
                type="select"
                placeholder="select"
                label="How did you hear about us"
              >
                <Option key="ive_1" value="Internet">
                  Internet
                </Option>
                <Option key="ive_2" value="Newspaper">
                  Newspaper
                </Option>
                <Option key="ive_3" value="Other">
                  Other
                </Option>
              </CustomInput>
            </div>
            <div className="">
              <Form.Item
                className="form-item"
                name="readTermsConditions"
                valuePropName="checked"
                rules={[
                  {
                    validator: (_, value) =>
                      value
                        ? Promise.resolve()
                        : Promise.reject(
                            new Error("Please confirm terms and conditions.")
                          ),
                  },
                ]}
              >
                <Checkbox>
                  I agree to the Terms &amp; Conditions of{" "}
                  {ConfigReducer.groupIdSettings.title}.
                </Checkbox>
              </Form.Item>
              <div className="mb-3">
                <a onClick={handleTcModal} href="#!">
                  Read Terms and Conditions
                </a>
              </div>
            </div>

            <div className="d-grid">
              <button className="btn btn-primary text-white">
                {state.twofa === "Y" ? "Verify With OTP" : "Register"}
              </button>
            </div>
            <div className="d-flex justify-content-lg-center mt-3">
              <p className="text-muted text-center mb-0 me-2">
                Already have an account?
              </p>
              <Link to={"/signin"} className="btn-link text-primary">
                Log In
              </Link>
            </div>
          </Form>
        </Spin>
      </div>
    </div>
  );
}
