import React, { useEffect } from "react";
import { useSelector } from "react-redux";

import Dashboard from "../Layouts/Dashboard";

import RepeatTranscationFlow1 from "./Flow1/RepeatTranscationFlow1";
import { useOutletContext } from "react-router-dom";

const RepeatTranscation = (props) => {
  const AuthReducer = useSelector((state) => state.user);
  const templateFlow =
    AuthReducer.groupIdSettings?.sendMoneyModule?.repeatTranscation?.flow;
  const { setTitle } = useOutletContext();
  useEffect(() => {
    setTitle("Repeat Transcation");
  }, []);
  return (
    <>
      {templateFlow === "FLOW1" && (
        <RepeatTranscationFlow1
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      )}
    </>
  );
};

export default RepeatTranscation;
