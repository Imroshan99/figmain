import React from "react";
import { useSelector } from "react-redux";
import AddBankAccountFlow1 from "./AddBankAccountFlow1/AddBankAccount";
import AddBankAccountFlow2 from "./AddBankAccountFlow2/AddBankAccount";
import { Modal } from "antd";
import { getProcessingPartner } from "../../../../services/utility/group";
import Plaid from "./Plaid";

const AddBankAccountModal = (props) => {
  const groupConfig = useSelector((state) => state.user);
  const templateFlow =
    groupConfig.groupIdSettings?.bankAccount?.addBankAccount?.flow;

  const getAddBankComponent = () => {
    if (getProcessingPartner(groupConfig.sendCountryCode) === "VIAMERICAS") {
      return <Plaid {...props} />;
    }
    if (templateFlow === "FLOW1") {
      return (
        <AddBankAccountFlow1
          appState={props.appState}
          manageAuth={props.manageAuth}
          accountsList={props.accountsList}
          setVisible={props.setVisible}
          visible={props.visible}
        />
      );
    }

    if (templateFlow === "FLOW2") {
      return (
        <AddBankAccountFlow2
          appState={props.appState}
          manageAuth={props.manageAuth}
        />
      );
    }
  };

  return (
    <Modal
      centered
      visible={props.visible}
      onCancel={() => props.setVisible(false)}
      forceRender={true}
      footer={null}
      width={500}
    >
      {getAddBankComponent()}
    </Modal>
  );
};

export default AddBankAccountModal;
