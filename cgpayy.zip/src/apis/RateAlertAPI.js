import axios from "axios";
import { config } from "../config";

export const RateAlertAPI = {
    addRateAlert: async (data, token) => {
        var axosConfig = {
            method: 'post',
            url: `${config.API_URL}/services/txn/add-rate-alert`,
            headers: {
                'Authorization': `AuthToken ${token}`,
                'Content-Type': 'application/json'
            },
            data: data
        };

        return await axios(axosConfig);
    },
}