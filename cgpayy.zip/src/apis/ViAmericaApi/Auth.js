import axios from "axios";
import { config } from "../../config";

export const ViAmericaAuthAPI = {
  login: async (data) => {
    return await axios.post(`${config.API_URL}/services/txn/vi-america-signin`, data);
  },
  signUp: async (data) => {
    return await axios.post(`${config.API_URL}/services/txn/vi-america-signup`, data);
  },
  userDocUpload: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/verification/user-doc-upload-via`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viaSendOTP: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-send-otp`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
  viaVeirfyOTP: async (data, token) => {
    var axosConfig = {
      method: "post",
      url: `${config.API_URL}/services/txn/vi-america-verify-otp`,
      headers: {
        Authorization: `AuthToken ${token}`,
        "Content-Type": "application/json",
      },
      data: data,
    };

    return await axios(axosConfig);
  },
};
