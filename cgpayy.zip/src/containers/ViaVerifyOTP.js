import CustomInput from "../reusable/CustomInput";
import FloatInput from "../reusable/FloatInput";
import { config } from "../config";
import { Form, Input, Modal, notification } from "antd";
import { useEffect, useReducer, useRef, useState } from "react";
import moment from "moment";
import { useDispatch, useSelector } from "react-redux";
import { decrypt, encrypt, publickey } from "../helpers/makeHash";
import { GuestAPI } from "../apis/GuestAPI";
import useHttp from "../hooks/useHttp";
import { AuthAPI } from "../apis/AuthAPI";
import Spinner from "../reusable/Spinner";
import { ViAmericaAuthAPI } from "../apis/ViAmericaApi/Auth";
import { useLocation, useNavigate } from "react-router-dom";
import { ProfileAPI } from "../apis/ProfileAPI";
import { login, setAdditionalAuthRequired, setIsLoginDone } from "../reducers/userReducer";

export default function ViaVerifyOTP(props) {
  const OtpInputFocus = useRef(null);
  const AuthReducer = useSelector((state) => state.user);
  const dispatch = useDispatch();

  const [form] = Form.useForm();
  const navigate = useNavigate();
  const location = useLocation();
  const hookViaVerifyOTP = useHttp(ViAmericaAuthAPI.viaVeirfyOTP);
  const hookReSendOTP = useHttp(GuestAPI.reSendOTP);
  const hookUpdateKycStatus = useHttp(ProfileAPI.updateKycStatus);
  const hookCrnDetails = useHttp(AuthAPI.crnDetails);
  const hookViaSendOTP = useHttp(ViAmericaAuthAPI.viaSendOTP);

  const [loader, setLoader] = useState(false);
  const [reverseTimer, setReverseTimer] = useState("2m 00s");
  const [intervalID, setInterID] = useState();
  const [state, setState] = useReducer((state, newState) => ({ ...state, ...newState }), {
    isModalVisible: false,
    OTPErrorMsg: "",

    OTPValue: "",
    _otpErrMsg: false,
    _showOtpErrMsg: false,
    _OTPErrMessage: "Please Enter Complete OTP",
    otpType: "",
    accountNo: "",
  });
  const otpInputStyle = {
    height: "56px",
    gap: "11px",
    width: "47px",
    borderRadius: "8px",
    backgroundColor: "#f0f8ff",
    border: "1px solid #d3dfeb",
    fontSize: "1.5rem",
    fontColor: "black",
    fontWeight: "700",
    textAlign: "center",
  };
  const onlyNumberKey = (val) => {
    var rgx = /^[0-9]*$/;
    return val.match(rgx);
  };

  useEffect(() => {
    reverseTimerOnLoad();
  }, []);
  useEffect(() => {
    if (state._showOtpErrMsg) {
      if (state.OTPValue.length === 6) {
        setState({ _otpErrMsg: false });
      } else if (state.OTPValue.length !== 0) {
        setState({ _otpErrMsg: true });
      }
    }
  }, [state.OTPValue]);
  // useEffect(() => {
  //   if (state.box1 || state.box2 || state.box3 || state.box4 || state.box5 || state.box6) {
  //     let OTPValue = `${state.box1}${state.box2}${state.box3}${state.box4}${state.box5}${state.box6}`;
  //     setState({
  //       OTPValue: OTPValue,
  //     });
  //   }
  // }, [state.box1, state.box2, state.box3, state.box4, state.box5, state.box6]);
  // useEffect(() => {
  //   if (props?.saveReceiver) {
  //     props.saveReceiver();
  //   }
  // }, [props?.state?.verificationToken]);
  const reverseTimerOnLoad = () => {
    clearInterval(intervalID);

    let validityAuctionEndTime = moment().add(2, "minutes");
    const second = 1000,
      minute = second * 60,
      hour = minute * 60,
      day = hour * 24;

    let countDown = new Date(`${validityAuctionEndTime}`).getTime();

    let letintervalID = setInterval(function () {
      let now = new Date().getTime(),
        distance = countDown - now;

      var getDay = Math.floor(distance / day);

      var getHour = Math.floor((distance % day) / hour);

      var getMinute = Math.floor((distance % hour) / minute);

      var secound = Math.floor((distance % minute) / second);
      let getSecound = secound > 9 ? secound : 0 + secound;

      let cDay = getDay !== 0 ? `${getDay}d` : "";
      let cHour = getHour !== 0 ? `${getHour}h` : "";
      let cMinute = getMinute !== 0 ? `${getMinute}m` : "";
      let cSecound = getSecound !== 0 ? `${getSecound}s` : "";
      let timer = `${cDay} ${cHour} ${cMinute} ${cSecound}`;

      if (distance <= 0) {
        clearInterval(intervalID);
      } else {
        setReverseTimer(timer);
      }
    }, second);
    setInterID(letintervalID);
  };
  const submitHandler = (value) => {
    form.setFields([{ name: "otp", errors: [] }]);
    const optData = {
      requestType: "VIAVERIFYOTP",
      userId: AuthReducer.userID
        ? AuthReducer.userID
        : props?.state?.userId
        ? props?.state?.userId
        : props?.state?.loginData?.userId,
      otp: state.OTPValue,
      otpType: "SEND",
      eventId: props.state.eventId,
    };

    // const optData = {
    //   requestType: "VIAVERIFYOTP",
    //   userId: props.state.loginData.userId,
    //   otp: state.OTPValue,
    //   otpType: props.otpType, //MAIL, LOGINMFA, SMS
    // };

    setLoader(true);
    hookViaVerifyOTP
      .sendRequest(optData, function (res) {
        // clearInterval(intervalID);
        setLoader(false);
        // clearInterval(intervalID);
        if (res.status == "S") {
          notification.success({
            message: res.message,
          });
          if (props.state._isViaSendOTP) {
            props.submitHandler(props.state.onFinishData);
          } else if (props?.useFor == "receiver") {
            props.setReviewPage(true);
            props.saveReceiver();
          } else if (props.useFor === "edit_receiver") {
            props.setState({ _isShowOTPBOX: false });
            if (props?.checkUiduserLoginId) {
              props?.ViaAddReceiver();
            } else {
              props.editReceiver();
            }
          } else {
            updateKycStatus();
          }
          clearInterval(intervalID);
        } else {
          setState({
            isModalVisible: true,
            OTPErrorMsg: res.errorMessage,
            _OTPErrMessage: res.errorMessage,
            _otpErrMsg: true,
            _showOtpErrMsg: true,
          });
          notification.error({
            message: res.errorMessage ? res.errorMessage : "Via verify OTP failed.",
          });
          form.setFields([{ name: "otp", errors: [res.errorMessage] }]);
          let errors = [];
          res.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {
        setLoader(false);
      });
  };
  const updateKycStatus = () => {
    let payload = {
      requestType: "UPDATEKYCSTATUS",
      userId: props.state.loginData.userId,
      isMobileVerified: "Y",
      isEmailVerified: "",
    };
    hookUpdateKycStatus.sendRequest(payload, function (data) {
      if (data.status == "S") {
        // getCRNDetails();
        // netverifyCallbackResponse(decodeData);
        dispatch(setAdditionalAuthRequired(false));
        notification.success({
          message: `WELCOME ${props.state.loginData.firstName} ${props.state.loginData.lastName}`,
        });
        // navigate("/new-transaction");
      } else {
        notification.error({
          message: data.errorMessage ? data.errorMessage : "Update kyc status failed",
        });
      }
    });
  };
  //   const getCRNDetails = () => {
  //     let payload = {
  //       requestType: "CRNDETAILS",
  //       crnNumber: props.state.emailId, //"dummy crnNumber": "100881179",LOGINID
  //       bankAcctStatusCode: "Y",
  //       apiType: "LOGIN",
  //     };
  //     setLoader((prevState) => prevState + 1);
  //     hookCrnDetails.sendRequest(payload, function (data) {
  //       setLoader((prevState) => prevState - 1);
  //       if (data.status === "S") {
  //         // dispatch(setIsLoginDone(false));
  //         notification.success({
  //           message: `WELCOME ${props.state.loginData.firstName} ${props.state.loginData.lastName}`,
  //         });
  //         navigate("/new-transaction");
  //       } else {
  //         notification.error({
  //           message: data.errorMessage
  //             ? data.errorMessage
  //             : "Access restricted. Please reach us at click2remit@kotak.com or 02266053825 for more information ",
  //         });
  //       }
  //     });
  //   };
  const onClickResedOTP = (data) => {
    const payload = {
      requestType: "VIASENDOTP",
      userId: AuthReducer.userID
        ? AuthReducer.userID
        : props?.state?.userId
        ? props?.state?.userId
        : props?.state?.loginData?.userId,
      otpType: "SEND",
      optionID: props?.useFor == "login" ? "phone" : "email", //pass email or phone
    };

    setLoader(true);
    hookViaSendOTP
      .sendRequest(payload, function (dataV) {
        setLoader(false);
        if (dataV.status == "S") {
          notification.success({ message: dataV.message });
          props.setState({ eventId: dataV.eventId });
          setState({ _showOtpErrMsg: "", OTPValue: "" });
          // props.setState({ verificationToken: dataV.verificationToken });
          // setVerificationToken(decodeData.verificationToken);
          clearInterval(intervalID);
          setTimeout(() => {
            reverseTimerOnLoad();
          }, 200);
        } else {
          notification.error({
            message: dataV.errorMessage ? dataV.errorMessage : "Via send OTP failed",
          });

          let errors = [];
          dataV.errorList.forEach((error, i) => {
            let errorData = {
              name: error.field,
              errors: [error.error],
            };
            errors.push(errorData);
          });
          if (errors.length > 0) form.setFields(errors);
        }
      })
      .catch((error) => {});
  };
  return (
    <Modal
      centered
      title="Verify With OTP"
      visible={true}
      // onCancel={() => props.setState({ isModalVisible: false })}
      footer={null}
    >
      <Form
        form={form}
        onFinish={(values) => {
          if (state.OTPValue.length === 6) {
            submitHandler(values);
          } else {
            setState({ _otpErrMsg: true });
            setState({ _showOtpErrMsg: true });
          }
        }}
      >
        <Spinner spinning={loader}>
          <div className="d-flex justify-content-center align-items-center">
            <div className="position-relative">
              <div className="verify-otp-box border-0 p-2 text-center">
                <h6>
                  {props?.useFor == "login" ? (
                    <>
                      <p className="text-center">
                        A 6 digit OTP will be sent to your registered mobile number.
                      </p>
                    </>
                  ) : (
                    <>
                      <p className="text-center">
                        Enter the one time password (OTP) sent to <br />
                        your registered Email ID.
                        <br />
                        {/* {props.saveReceiver &&
                          `+${props?.state?.beneficiaryDetails?.mobileCountryCode} ${props?.state?.beneficiaryDetails?.mobileNo}.`}
                        {props.editProfile &&
                          `+${props.state.profileValues.mobileCountryCode} ${props.state.profileValues.mobileNo}.`}
                        {props?.state?.personalDetails?.mobileCountryCode &&
                          `+${props?.state?.personalDetails?.mobileCountryCode} ${props?.state?.personalDetails?.mobileNo}.`} */}
                      </p>
                    </>
                  )}
                </h6>
                {/* <h6>A 6 digit OTP is sent to <br /> your registered mobile number and email id</h6>
                                <div>
                                    <span>A code has been sent to</span>
                                    <small>*******{props.state.formData.mobileNo.slice(props.state.formData.mobileNo.length - 4)}</small>
                                </div> */}

                <div className="my-3">
                  <Form.Item
                    className="form-item text-start"
                    name="otp"
                    rules={[
                      { required: true, message: "Please input your otp." },
                      {
                        min: 6,
                        max: 6,
                        message: "OTP should be 6 digits",
                      },
                      {
                        pattern: /^[0-9\b]+$/,
                        message: "Only Numbers allowed",
                      },
                    ]}
                  >
                    <Input
                      size="large"
                      value={state.OTPValue}
                      placeholder="Enter OTP"
                      onChange={(e) => {
                        setState({ OTPValue: e.target.value });
                        if (e.target.value.length == 6) {
                          setState({ _showOtpErrMsg: "" });
                        }
                      }}
                      onPaste={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCopy={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                      onCut={(e) => {
                        e.preventDefault();
                        return false;
                      }}
                    />
                  </Form.Item>
                </div>

                <div className="my-3 text-start">
                  <p className="small">
                    {reverseTimer.trim() == "" ? (
                      <small>OTP expired.</small>
                    ) : (
                      <small>OTP will expire in {reverseTimer}</small>
                    )}
                  </p>
                </div>
                <div className="d-grid gap-2 d-flex justify-content-between mt-4">
                  <button
                    className="btn btn-danger btn-sm px-4"
                    onClick={onClickResedOTP}
                    type="button"
                  >
                    Resend OTP
                  </button>
                  <button className="btn btn-primary btn-sm text-white px-4 btn-sm">Submit</button>
                </div>
              </div>
            </div>
          </div>
        </Spinner>
      </Form>
    </Modal>
  );
}
