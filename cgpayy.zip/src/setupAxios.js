import { setToken } from "./reducers/userReducer";

export default function setupAxios(axios, store) {
  // axios.interceptors.request.use(
  //   (config) => {
  //     console.log("Success ===> ", config);
  //     // const { accessToken } = store.getState();

  //     // if (accessToken) {
  //     //   config.headers.Authorization = `Bearer ${accessToken}`;
  //     // }

  //     return config;
  //   },
  //   (err) => {
  //     console.log("Error ===> ", err);
  //     return Promise.reject(err);
  //   }
  // );

  // for multiple requests

  let isRefreshing = false;
  let failedQueue = [];
  const processQueue = (error, token = null) => {
    failedQueue.forEach((prom) => {
      if (error) {
        prom.reject(error);
      } else {
        prom.resolve(token);
      }
    });

    failedQueue = [];
  };

  axios.interceptors.response.use(
    (config) => {
      console.log("Success ===> ", config);
      // const { accessToken } = store.getState();

      // if (accessToken) {
      //   config.headers.Authorization = `Bearer ${accessToken}`;
      // }

      return config;
    },
    (error) => {
      console.log("Error ===> ", error.config);
      console.log("Error Stauts ===> ", error.response.status);
      const originalRequest = error.config;
      if (error.response.status === 401 && !originalRequest._retry) {
        if (isRefreshing) {
          return new Promise(function (resolve, reject) {
            failedQueue.push({ resolve, reject });
          })
            .then((token) => {
              originalRequest.headers["Authorization"] = "Bearer " + token;
              return axios(originalRequest);
            })
            .catch((err) => {
              return Promise.reject(err);
            });
        }

        originalRequest._retry = true;
        isRefreshing = true;

        const reduxStore = store.getState();
        let refreshTokenData = {
          requestId: "565665652",
          requestType: "RefreshToken",
          channelId: "WEB",
          clientId: reduxStore.clientId,
          groupId: reduxStore.groupId,
          sessionId: "665626fasd6as5d6as5d6as5d6as5d6",
          userId: reduxStore.userID,
          ipAddress: "127.0.0.1",
          token: reduxStore.accessToken,
        };

        return new Promise(function (resolve, reject) {
          axios
            .post(
              "https://qaone.remit.in/services/usr/refresh-token",
              refreshTokenData,
              {
                headers: {
                  Authorization: `AuthToken ${reduxStore.accessToken}`,
                  "Content-Type": "application/json",
                },
              }
            )
            .then(({ data }) => {
              // store.dispatch({ type: "SET_USER_TOKEN", payload: data.token });
              store.dispatch(setToken(data.token));

              // window.localStorage.setItem("token", data.token);
              // window.localStorage.setItem("refreshToken", data.refreshToken);
              axios.defaults.headers.common["Authorization"] =
                "Bearer " + data.token;
              originalRequest.headers["Authorization"] = "Bearer " + data.token;
              processQueue(null, data.token);
              resolve(axios(originalRequest));
            })
            .catch((err) => {
              processQueue(err, null);
              reject(err);
            })
            .finally(() => {
              isRefreshing = false;
            });
        });
      }
      return Promise.reject(error);
    }
  );
}
