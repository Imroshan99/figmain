import React from "react";
import { Input } from "antd";

const FloatInput = (props) => {
  let { label, value, placeholder, type, required } = props;

  if (!placeholder) placeholder = label;

  //   const isOccupied = focus || (value && value.length !== 0);
  //   const labelClass = isOccupied ? "label as-label" : "label as-placeholder";
  //   const requiredMark = required ? <span className="text-danger">*</span> : null;

  return (
    <div className="form-floating">
      <Input
        onChange={props.onChange}
        type={type}
        defaultValue={value}
        className="form-control"
        placeholder={placeholder}
      />
      <label for="floatingInput">Email address</label>
    </div>
  );
};

export default FloatInput;
